document.addEventListener("DOMContentLoaded", () => {
  const WEBSOCKET_URL = CONFIG.websocket_url;
  const tickerContainer = document.getElementById("alert-ticker");

  // --- State Management ---
  let activeAlerts = [];
  let sponsors = [];
  let currentAlertIndex = 0;
  let currentSponsorIndex = 0;
  let rotationSpeed = 10000;
  let noAlertsMessage = CONFIG.ticker_no_alerts_message || "No Active Alerts";
  let currentTheme = 'classic'; // Track current theme

  // NEW: Separate timers for alerts and sponsors
  let alertTimeoutId = null;
  let sponsorIntervalId = null;
  let allActiveAlerts = [];
   let lastAlertsJSON = null;

  let tickerFilters = {
    states: [], // Empty array means allow all
    phenomena: [] // Empty array means allow all
};

  // --- Theme Management ---
  function applyTheme(themeName) {
    if (!themeName || themeName === currentTheme) return;

    const themes = ['classic', 'atmospheric', 'storm-chaser', 'meteorologist', 'winter'];
    const body = document.body;
    const html = document.documentElement;

    // Remove all theme classes from body and html
    themes.forEach(theme => {
      body.classList.remove(`ticker-theme-${theme}`);
      html.classList.remove(`ticker-theme-${theme}`);
    });

    // Add new theme class
    body.classList.add(`ticker-theme-${themeName}`);
    html.classList.add(`ticker-theme-${themeName}`);

    // Enable/disable theme stylesheets
    themes.forEach(theme => {
      const linkElement = document.getElementById(`ticker-theme-${theme}`);
      if (linkElement) {
        linkElement.disabled = (theme !== themeName);
      }
    });

    currentTheme = themeName;
    console.log(`🎨 Sponsored ticker theme applied: ${themeName}`);
  }

  // Alert type and state maps are now in widget-common.js

  function connect() {
    const socket = new WebSocket(WEBSOCKET_URL);
    socket.onopen = () => console.log("Alert Ticker connected.");
    socket.onclose = () => {
      clearTimeout(alertTimeoutId);
      clearInterval(sponsorIntervalId);
      sponsorIntervalId = null;
      setTimeout(connect, 5000);
    };
    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      if (data.type === "update") {
        const newAlertsJSON = JSON.stringify(data.alerts || []);

        // --- NEW LOGIC ---
        // If it's not the first load AND the alert data is identical to what we already have,
        // we'll skip the visual refresh to avoid interrupting the scroll animation.
        if (lastAlertsJSON !== null && newAlertsJSON === lastAlertsJSON) {
          return; // Exit the function, leaving the animation untouched.
        }

        // --- IF DATA IS NEW OR DIFFERENT ---
        // Store the new data snapshot for the next comparison.
        lastAlertsJSON = newAlertsJSON;

        // Update the master list of alerts and other settings.
        allActiveAlerts = data.alerts || [];
        sponsors = data.ticker_sponsor || [];
        rotationSpeed = data.ticker_rotation_speed_ms || 10000;
        noAlertsMessage = data.ticker_no_alerts_message || "No Active Alerts";

        // Apply theme if received
        if (data.ticker_theme) {
          applyTheme(data.ticker_theme);
        }

        // Now, trigger the visual refresh because the data has changed.
        applyFiltersAndRestart();

        // (Re)start the sponsor rotation if there are sponsors.
        if (sponsors.length > 0) {
          startSponsorRotation();
        }

      } else if (data.type === 'ticker_settings_update') {
        console.log('Received new ticker settings:', data.settings);
        tickerFilters = data.settings;

        // Apply theme if included in settings update
        if (data.settings && data.settings.theme) {
          applyTheme(data.settings.theme);
        }

        // A settings update should always trigger a visual refresh.
        applyFiltersAndRestart();
      }
    }
  };

  function applyFiltersAndRestart() {
    let filtered = allActiveAlerts;

    // Apply state filter if any are set
    if (tickerFilters.states && tickerFilters.states.length > 0) {
        filtered = filtered.filter(alert => {
            if (!alert.affected_areas || alert.affected_areas.length === 0) return false;
            // Check if any of the alert's areas match a state in our filter
            return alert.affected_areas.some(area => tickerFilters.states.includes(area.substring(0, 2)));
        });
    }

    // Apply phenomenon (alert type) filter if any are set
    if (tickerFilters.phenomena && tickerFilters.phenomena.length > 0) {
        filtered = filtered.filter(alert => tickerFilters.phenomena.includes(alert.phenomenon));
    }

    // Update the list of alerts that will be displayed
    activeAlerts = filtered;

    // --- THIS IS THE KEY FIX ---
    // Always clear the previous rotation and start a new one. This ensures the
    // ticker immediately reflects the current state (either showing the new
    // alerts or the "No Active Alerts" message).
    clearTimeout(alertTimeoutId);
    currentAlertIndex = 0; // Reset index to start from the beginning of the new list
    rotateAlerts();
}

  // Using shared getAlertDisplayInfo from widget-common.js
  
  
  // NEW: A dedicated, independent loop for sponsors
  function startSponsorRotation() {
    if (sponsorIntervalId) clearInterval(sponsorIntervalId);
    
    const rotate = () => {
        const sponsorContainer = document.querySelector(".sponsor-container");
        if (!sponsorContainer || !Array.isArray(sponsors) || sponsors.length === 0) return;
        
        const sponsorText = sponsorContainer.querySelector(".sponsor-text");
        const sponsorLogo = sponsorContainer.querySelector(".sponsor-logo");
        const sponsor = sponsors[currentSponsorIndex];

        sponsorLogo.classList.add("fading");
        setTimeout(() => {
            if (sponsor.logo_url) {
                sponsorLogo.src = sponsor.logo_url;
                sponsorLogo.style.display = "block";
                sponsorText.style.display = "none";
            } else if (sponsor.text) {
                sponsorText.textContent = sponsor.text;
                sponsorText.style.display = "block";
                sponsorLogo.style.display = "none";
            }
            sponsorLogo.classList.remove("fading");
        }, 200);

        currentSponsorIndex = (currentSponsorIndex + 1) % sponsors.length;
    };
    
    rotate(); // Rotate immediately
    sponsorIntervalId = setInterval(rotate, rotationSpeed); // Then rotate on a fixed interval
  }

  // REFACTORED: This function now ONLY handles alerts
function rotateAlerts() {
    clearTimeout(alertTimeoutId);
    const locationsContainer = document.getElementById("ticker-locations");
    const locationsSpan = locationsContainer.querySelector("span");

    // Handle the "No Alerts" case
    if (activeAlerts.length === 0) {
      tickerContainer.classList.add("no-alerts-active");

      // 1. Clear all text fields to prevent stale data
      document.getElementById("ticker-title").textContent = "";
      document.getElementById("ticker-state").textContent = "";
      document.getElementById("ticker-expires-time").textContent = "";
      
      // 2. Put the "No Alerts" message in the bottom row's span
      locationsContainer.classList.remove("scrolling");
      locationsSpan.style.animationDuration = "";
      locationsSpan.textContent = noAlertsMessage;
      
      // 3. NEW: Check if the message needs to scroll
      setTimeout(() => {
        const containerWidth = locationsContainer.clientWidth;
        const textWidth = locationsSpan.scrollWidth;

        if (textWidth > containerWidth) {
          locationsContainer.classList.add("scrolling");
          const durationInSeconds = textWidth / 75; // Adjust speed here if needed
          locationsSpan.style.animationDuration = `${durationInSeconds}s`;
        }
      }, 100); // Delay to allow browser to calculate widths
      
      return; // Stop here until new alerts arrive
    }

    // --- Handle the "Has Alerts" case ---
    tickerContainer.classList.remove("no-alerts-active");

    if (currentAlertIndex >= activeAlerts.length) {
      currentAlertIndex = 0;
    }
    
    const alert = activeAlerts[currentAlertIndex];
    const alertInfo = getAlertDisplayInfo(alert);
    
    // Set up the new alert's content
    tickerContainer.className = `ticker-container ${alert.phenomenon}`;
    document.querySelector(".ticker-icon i").className = `fas ${alertInfo.icon}`;
    document.getElementById("ticker-title").textContent = alertInfo.name;
    document.getElementById("ticker-state").textContent = alertInfo.stateName || "";
    document.getElementById("ticker-expires-time").textContent = formatExpirationTime(alert.expiration_time);
    
    locationsContainer.classList.remove("scrolling");
    locationsSpan.style.animationDuration = "";
    locationsSpan.textContent = alert.display_locations;
    
    // Calculate display time for this alert
    let displayTime = rotationSpeed;
    setTimeout(() => {
      const containerWidth = locationsContainer.clientWidth;
      const textWidth = locationsSpan.scrollWidth;
      if (textWidth > containerWidth) {
        const durationInSeconds = textWidth / 60;
        displayTime = (durationInSeconds * 1000) + 1500;
        locationsSpan.style.animationDuration = `${durationInSeconds}s`;
        locationsContainer.classList.add("scrolling");
      }
      
      currentAlertIndex++;
      alertTimeoutId = setTimeout(rotateAlerts, displayTime);
    }, 100);
}

  connect();
});