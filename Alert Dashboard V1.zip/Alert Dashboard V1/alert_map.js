/**
 * alert_map.js
 * Displays a map widget centered on newly issued warnings
 * Shows the warning polygon with city labels visible for context
 */

document.addEventListener('DOMContentLoaded', () => {
    const WEBSOCKET_URL = CONFIG.websocket_url;
    const DISPLAY_DURATION_MS = 25000; // Show for 25 seconds
    const MAP_ZOOM_LEVEL = 9; // Zoom level that makes city labels readable

    // DOM Elements
    const container = document.getElementById('alert-map-container');
    const mapDiv = document.getElementById('alert-map');
    const alertTitle = document.getElementById('alert-title');
    const alertIcon = document.getElementById('alert-icon');
    const alertLocation = document.getElementById('alert-location');
    const expiresTime = document.getElementById('expires-time');
    const closeButton = document.getElementById('close-map-btn');

    // State
    let map = null;
    let polygonLayer = null;
    let hideTimeout = null;
    let currentAlert = null;

    // Warnings that should trigger the map display
    const DISPLAY_WARNINGS = new Set(['TO', 'SV', 'SVR', 'FF', 'FFW', 'WSW', 'SQW']);

    /**
     * Initialize the Leaflet map
     */
    function initializeMap() {
        if (map) return; // Already initialized

        map = L.map('alert-map', {
            zoomControl: true,
            attributionControl: true
        }).setView([40.0, -83.0], 7);

        // Dark base layer with city labels
        L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
            subdomains: 'abcd',
            maxZoom: 20
        }).addTo(map);

        // Layer for alert polygons
        polygonLayer = L.layerGroup().addTo(map);

        console.log('Alert Map widget initialized');
    }

    /**
     * Connect to WebSocket for new alert notifications
     */
    function connect() {
        createWebSocketConnection(WEBSOCKET_URL, {
            onMessage: (data) => {
                // Apply theme from ANY message that contains it
                if (data.ticker_theme || data.widget_theme || data.theme) {
                    applyWidgetTheme(data.ticker_theme || data.widget_theme || data.theme, 'widget');
                }

                if (data.type === 'new_alert' && data.alert_data) {
                    handleNewAlert(data.alert_data);
                }
            }
        });
    }

    /**
     * Handle incoming new alert
     */
    function handleNewAlert(alert) {
        // Only show map for specific warning types
        if (!DISPLAY_WARNINGS.has(alert.phenomenon)) {
            return;
        }

        // Must have a polygon to display on map
        if (!alert.polygon || alert.polygon.length === 0) {
            console.log('Alert has no polygon, skipping map display');
            return;
        }

        console.log('Displaying map for new alert:', alert.phenomenon, alert.display_locations);
        displayAlertOnMap(alert);
    }

    /**
     * Display the alert on the map
     */
    function displayAlertOnMap(alert) {
        // Initialize map if needed
        if (!map) {
            initializeMap();
        }

        // Store current alert
        currentAlert = alert;

        // Clear any existing timeout
        clearTimeout(hideTimeout);

        // Clear existing polygons
        if (polygonLayer) {
            polygonLayer.clearLayers();
        }

        // Get alert info
        const alertInfo = getAlertDisplayInfo(alert);

        // Update header
        alertTitle.textContent = alertInfo.name;
        alertIcon.className = `fas ${alertInfo.icon}`;

        // Update footer
        alertLocation.textContent = alert.display_locations;
        expiresTime.textContent = formatExpirationTime(alert.expiration_time);

        // Set container class for styling
        container.className = `widget-container ${alert.phenomenon}`;
        if (alert.is_emergency) {
            container.classList.add('EMERGENCY');
        }

        // Draw polygon on map
        drawAlertPolygon(alert);

        // Calculate bounds and center map
        centerMapOnAlert(alert);

        // Show the widget
        container.classList.add('visible');
        container.classList.remove('hidden');

        // Auto-hide after duration
        hideTimeout = setTimeout(hideWidget, DISPLAY_DURATION_MS);
    }

    /**
     * Draw the alert polygon on the map
     */
    function drawAlertPolygon(alert) {
        if (!alert.polygon || alert.polygon.length === 0) return;

        const style = getAlertStyle(alert.phenomenon);

        // Handle case where polygon might be array of arrays (multiple polygons)
        if (Array.isArray(alert.polygon[0])) {
            // Multiple polygons
            alert.polygon.forEach(polyCoords => {
                const polygon = L.polygon(polyCoords, {
                    ...style,
                    weight: style.weight + 1, // Make slightly thicker for visibility
                    fillOpacity: 0.35
                });
                polygon.bindTooltip(alert.display_locations || 'Unknown Location', {
                    permanent: false,
                    direction: 'center'
                });
                polygon.addTo(polygonLayer);
            });
        } else {
            // Single polygon
            const polygon = L.polygon(alert.polygon, {
                ...style,
                weight: style.weight + 1,
                fillOpacity: 0.35
            });
            polygon.bindTooltip(alert.display_locations || 'Unknown Location', {
                permanent: false,
                direction: 'center'
            });
            polygon.addTo(polygonLayer);
        }

        // Add storm motion arrow if available
        if (alert.storm_motion && alert.polygon[0]) {
            const firstPolygon = Array.isArray(alert.polygon[0][0]) ? alert.polygon[0] : alert.polygon;
            const centroid = getPolygonCentroid(firstPolygon);

            if (centroid) {
                const motionData = alert.storm_motion.split(' ');
                const direction = motionData[0];
                const rotationAngle = getRotationAngleForDirection(direction);

                const motionIcon = L.divIcon({
                    className: 'motion-arrow-icon',
                    html: `<i class="fas fa-long-arrow-alt-right" style="transform: rotate(${rotationAngle}deg);"></i>`,
                    iconSize: [32, 32]
                });

                L.marker(centroid, { icon: motionIcon }).addTo(polygonLayer);
            }
        }
    }

    /**
     * Center the map on the alert with appropriate zoom
     */
    function centerMapOnAlert(alert) {
        if (!map || !alert.polygon || alert.polygon.length === 0) return;

        try {
            // Get the first polygon coordinates
            const polyCoords = Array.isArray(alert.polygon[0][0]) ? alert.polygon[0] : alert.polygon;

            // Create a Leaflet polygon to get bounds
            const tempPolygon = L.polygon(polyCoords);
            const bounds = tempPolygon.getBounds();

            // Pad the bounds to show surrounding area
            const paddedBounds = bounds.pad(0.3); // 30% padding

            // Fit map to bounds with max zoom constraint
            map.fitBounds(paddedBounds, {
                maxZoom: MAP_ZOOM_LEVEL,
                animate: true,
                duration: 1.0
            });
        } catch (e) {
            console.error('Error centering map:', e);
            // Fallback: just center on first coordinate
            if (alert.polygon[0]) {
                const coords = Array.isArray(alert.polygon[0][0]) ? alert.polygon[0][0] : alert.polygon[0];
                map.setView(coords, MAP_ZOOM_LEVEL);
            }
        }
    }

    /**
     * Convert compass direction to rotation angle
     */
    function getRotationAngleForDirection(direction) {
        const directionMap = {
            'E': 0, 'ESE': 22.5, 'SE': 45, 'SSE': 67.5,
            'S': 90, 'SSW': 112.5, 'SW': 135, 'WSW': 157.5,
            'W': 180, 'WNW': 202.5, 'NW': 225, 'NNW': 247.5,
            'N': 270, 'NNE': 292.5, 'NE': 315, 'ENE': 337.5
        };
        return directionMap[direction.toUpperCase()] || 0;
    }

    /**
     * Hide the widget
     */
    function hideWidget() {
        clearTimeout(hideTimeout);
        container.classList.remove('visible');

        // Delay hiding to allow fade-out animation
        setTimeout(() => {
            container.classList.add('hidden');

            // Clear the map
            if (polygonLayer) {
                polygonLayer.clearLayers();
            }

            currentAlert = null;
        }, 500);
    }

    // Close button event
    closeButton.addEventListener('click', hideWidget);

    // Start WebSocket connection
    connect();
});
