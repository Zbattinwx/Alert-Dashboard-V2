// camera_widget.js
document.addEventListener('DOMContentLoaded', () => {
    const WEBSOCKET_URL = CONFIG.websocket_url;
    const cameraContainer = document.getElementById('camera-container');
    const cameraImage = document.getElementById('camera-image');
    const cameraTitle = document.getElementById('camera-title');
    const closeButton = document.getElementById('close-widget-btn');

    // --- MODIFICATION: Variable to hold our refresh timer ---
    let refreshIntervalId = null;

    function connect() {
        createWebSocketConnection(WEBSOCKET_URL, {
            onMessage: (data) => {
                // Apply theme from ANY message that contains it
                if (data.ticker_theme || data.widget_theme || data.theme) {
                    applyWidgetTheme(data.ticker_theme || data.widget_theme || data.theme, 'widget');
                }

                if (data.type === 'feature_camera' && data.camera_data) {
                    const { title, imageUrl } = data.camera_data;

                    // Clear any old timer that might be running
                    if (refreshIntervalId) clearInterval(refreshIntervalId);

                    // Update the image and title immediately
                    cameraTitle.textContent = title;
                    cameraImage.src = `${imageUrl}?t=${new Date().getTime()}`;

                    // Start a new 5-second timer to keep the image fresh
                    refreshIntervalId = setInterval(() => {
                        console.log("Refreshing camera image...");
                        cameraImage.src = `${imageUrl}?t=${new Date().getTime()}`;
                    }, 5000);

                    cameraContainer.classList.remove('hidden');

                } else if (data.type === 'hide_camera_widget') {
                    hideWidget();
                }
            },
            onClose: () => {
                // When disconnected, stop any active timer
                if (refreshIntervalId) clearInterval(refreshIntervalId);
            }
        });
    }

    /**
     * Hides the widget and clears the refresh timer.
     */
    function hideWidget() {
        console.log("Hiding camera widget and stopping refresh.");
        cameraContainer.classList.add('hidden');
        if (refreshIntervalId) {
            clearInterval(refreshIntervalId);
            refreshIntervalId = null;
        }
    }

    // The close button on the widget should also use our new hide function
    closeButton.addEventListener('click', hideWidget);

    connect();
});