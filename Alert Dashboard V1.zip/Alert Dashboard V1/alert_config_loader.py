# alert_config_loader.py
# ==================================================================================
# ALERT CONFIGURATION LOADER
# ==================================================================================
# This module loads and manages the centralized alert type configuration from
# alert_types_config.json. All alert type definitions, priorities, colors, and
# display properties are loaded from this single source of truth.
# ==================================================================================

import json
import os
from typing import Dict, Set, List, Any

class AlertConfigLoader:
    """Manages loading and accessing alert type configuration"""

    def __init__(self, config_path: str = "alert_types_config.json"):
        self.config_path = config_path
        self.config_data = {}
        self.alert_types = []

        # Cached lookups for performance
        self._nws_event_to_phenomenon = {}
        self._target_phenomena = set()
        self._high_priority_alerts = set()
        self._alert_priority = {}
        self._alert_display_map = {}
        self._excluded_keywords = []
        self._thunderstorm_keywords = []
        self._watch_detection = {}

        self.load_config()

    def load_config(self):
        """Load the alert configuration from JSON file"""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                self.config_data = json.load(f)

            self.alert_types = self.config_data.get('alert_types', [])

            # Build lookup dictionaries
            self._build_lookups()

            print(f"[OK] Loaded {len(self.alert_types)} alert types from {self.config_path}")

        except FileNotFoundError:
            print(f"ERROR: Alert config file not found: {self.config_path}")
            print("Using empty configuration - alerts will not be processed correctly!")
            self.alert_types = []
        except json.JSONDecodeError as e:
            print(f"ERROR: Invalid JSON in {self.config_path}: {e}")
            print("Using empty configuration - alerts will not be processed correctly!")
            self.alert_types = []

    def _build_lookups(self):
        """Build cached lookup dictionaries from config"""
        self._nws_event_to_phenomenon = {}
        self._target_phenomena = set()
        self._high_priority_alerts = set()
        self._alert_priority = {}
        self._alert_display_map = {}

        for alert in self.alert_types:
            phenom = alert['phenomenon_code']

            # NWS event name mapping
            if 'nws_event_name' in alert:
                self._nws_event_to_phenomenon[alert['nws_event_name']] = phenom

            # All phenomena are tracked
            self._target_phenomena.add(phenom)

            # High priority alerts
            if alert.get('high_priority', False):
                self._high_priority_alerts.add(phenom)

            # Priority mapping
            self._alert_priority[phenom] = alert.get('priority', 99)

            # Display name mapping (for Google Chat, etc.)
            self._alert_display_map[phenom] = alert.get('display_name', phenom)

        # Load special handling config
        special = self.config_data.get('special_handling', {})

        # SPS filtering keywords
        sps_filter = special.get('sps_thunderstorm_filter', {})
        self._excluded_keywords = sps_filter.get('excluded_keywords', [])
        self._thunderstorm_keywords = sps_filter.get('thunderstorm_keywords', [])

        # Watch detection
        self._watch_detection = special.get('watch_detection', {})

    def reload(self):
        """Reload configuration from disk (for live updates)"""
        print(f"Reloading alert configuration from {self.config_path}...")
        self.load_config()

    # ==================================================================================
    # PROPERTY ACCESSORS (compatible with old constants.py interface)
    # ==================================================================================

    @property
    def NWS_EVENT_TO_PHENOMENON(self) -> Dict[str, str]:
        """Maps NWS event names to phenomenon codes"""
        return self._nws_event_to_phenomenon

    @property
    def TARGET_PHENOMENA(self) -> Set[str]:
        """Set of all phenomenon codes to track"""
        return self._target_phenomena

    @property
    def HIGH_PRIORITY_ALERTS(self) -> Set[str]:
        """Set of phenomenon codes that trigger notifications"""
        return self._high_priority_alerts

    @property
    def ALERT_PRIORITY(self) -> Dict[str, int]:
        """Maps phenomenon codes to priority values (lower = higher priority)"""
        return self._alert_priority

    @property
    def ALERT_DISPLAY_MAP(self) -> Dict[str, str]:
        """Maps phenomenon codes to display names"""
        return self._alert_display_map

    @property
    def SPS_EXCLUDED_KEYWORDS(self) -> List[str]:
        """Keywords that exclude an SPS from being thunderstorm-related"""
        return self._excluded_keywords

    @property
    def SPS_THUNDERSTORM_KEYWORDS(self) -> List[str]:
        """Keywords that indicate an SPS is thunderstorm-related"""
        return self._thunderstorm_keywords

    @property
    def WATCH_DETECTION(self) -> Dict[str, Any]:
        """Configuration for detecting watch types"""
        return self._watch_detection

    def get_alert_by_phenomenon(self, phenomenon_code: str) -> Dict[str, Any]:
        """Get full alert configuration by phenomenon code"""
        for alert in self.alert_types:
            if alert['phenomenon_code'] == phenomenon_code:
                return alert
        return {}

    def get_config_for_frontend(self) -> Dict[str, Any]:
        """Get full configuration data (for serving to frontend)"""
        return self.config_data


# ==================================================================================
# GLOBAL INSTANCE
# ==================================================================================
# Create a single global instance that can be imported by other modules
# This maintains backward compatibility with the old constants.py imports

_alert_config = AlertConfigLoader()

# Export properties that match the old constants.py interface
NWS_EVENT_TO_PHENOMENON = _alert_config.NWS_EVENT_TO_PHENOMENON
TARGET_PHENOMENA = _alert_config.TARGET_PHENOMENA
HIGH_PRIORITY_ALERTS = _alert_config.HIGH_PRIORITY_ALERTS
ALERT_PRIORITY = _alert_config.ALERT_PRIORITY

# Additional exports
def get_alert_config() -> AlertConfigLoader:
    """Get the global alert configuration instance"""
    return _alert_config

def reload_alert_config():
    """Reload alert configuration from disk"""
    _alert_config.reload()

    # Update module-level exports
    global NWS_EVENT_TO_PHENOMENON, TARGET_PHENOMENA, HIGH_PRIORITY_ALERTS, ALERT_PRIORITY
    NWS_EVENT_TO_PHENOMENON = _alert_config.NWS_EVENT_TO_PHENOMENON
    TARGET_PHENOMENA = _alert_config.TARGET_PHENOMENA
    HIGH_PRIORITY_ALERTS = _alert_config.HIGH_PRIORITY_ALERTS
    ALERT_PRIORITY = _alert_config.ALERT_PRIORITY
