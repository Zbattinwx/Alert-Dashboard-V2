# Alert Configuration System - Fixes & New Features

## ✅ Issues Fixed

### Issue 1: Display Names Not Showing Correctly

**Problem:** Dashboard was showing phenomenon codes (like "LESW") instead of full display names ("Lake Effect Snow Warning").

**Root Cause:** The [dashboard.js](dashboard.js:568-583) file had hardcoded alert definitions that were overriding the dynamically loaded configuration.

**Fix Applied:**
- Removed hardcoded `ALERT_TYPE_MAP`, `TICKER_FILTERABLE_ALERTS`, `styleMapping`, `alertPriority`, and `counters` definitions from dashboard.js
- Replaced with references to the global variables populated by `alert-config.js`
- Now all alert type information comes from `alert_types_config.json`

**Files Modified:**
- [dashboard.js](dashboard.js:575-576) - Now uses `window.ALERT_TYPE_MAP`
- [dashboard.js](dashboard.js:1758-1761) - Now uses `window.styleMapping`
- [dashboard.js](dashboard.js:2013-2028) - Now uses dynamically created `window.counters`
- [dashboard.js](dashboard.js:2053-2068) - Now uses `window.alertPriority`

### Issue 2: Ticker Missing Alert Colors

**Problem:** Ticker alerts didn't have background colors showing.

**Root Cause:** The alert type map didn't include color information that the ticker needs.

**Fix Applied:**
- Updated [alert-config.js](alert-config.js:121-125) to include `color` property in `ALERT_TYPE_MAP`
- Color is now populated from `alert_types_config.json` → `colors.primary` field
- Ticker can now access colors via `ALERT_TYPE_MAP[code].color`

---

## 🆕 New Feature: Selective Display Control

You can now control where each alert type appears!

### New Configuration Fields

Added two new optional fields to each alert type in `alert_types_config.json`:

```json
{
  "phenomenon_code": "LESW",
  "display_name": "Lake Effect Snow Warning",
  ...
  "show_on_dashboard": true,   ← Show in main dashboard
  "show_on_ticker": true        ← Show on ticker/lower thirds
}
```

### How to Use

**Hide an alert from the dashboard (but keep on ticker):**
```json
{
  "phenomenon_code": "SPS",
  "display_name": "Special Weather Statement",
  "show_on_dashboard": false,
  "show_on_ticker": true,
  ...
}
```

**Hide an alert from ticker (but keep on dashboard):**
```json
{
  "phenomenon_code": "WWY",
  "display_name": "Winter Weather Advisory",
  "show_on_dashboard": true,
  "show_on_ticker": false,
  ...
}
```

**Hide an alert completely:**
```json
{
  "phenomenon_code": "SS",
  "display_name": "Storm Surge Warning",
  "show_on_dashboard": false,
  "show_on_ticker": false,
  ...
}
```

**Default Behavior:**
- If `show_on_dashboard` is not specified → defaults to `true` (show it)
- If `show_on_ticker` is not specified → defaults to `true` (show it)

### Implementation Details

Two new global Sets are available in JavaScript:

```javascript
window.DASHBOARD_ALERTS  // Set of codes that should appear on dashboard
window.TICKER_ALERTS     // Set of codes that should appear on ticker
```

**Example Usage in Your Code:**

```javascript
// Filter alerts for dashboard display
const dashboardAlerts = allAlerts.filter(alert =>
    window.DASHBOARD_ALERTS.has(alert.phenomenon)
);

// Filter alerts for ticker display
const tickerAlerts = allAlerts.filter(alert =>
    window.TICKER_ALERTS.has(alert.phenomenon)
);
```

---

## 📝 Configuration Example

Here's a complete example showing all the new features:

```json
{
  "phenomenon_code": "LESW",
  "nws_event_name": "Lake Effect Snow Warning",
  "display_name": "Lake Effect Snow Warning",
  "short_name": "Lake Effect Snow Warning",
  "priority": 7,
  "high_priority": true,
  "show_on_map": true,
  "show_on_dashboard": true,
  "show_on_ticker": true,
  "icon": "fas fa-snowflake",
  "colors": {
    "primary": "#008B8B",         ← Used for ticker background
    "css_var": "#008B8B",         ← CSS variables
    "state_map": "#008B8B",       ← State map coloring
    "daily_recap": "#008B8B"      ← Daily summary coloring
  },
  "map_style": {
    "color": "#008B8B",           ← Polygon outline color
    "weight": 3,                  ← Line thickness
    "fillOpacity": 0.5            ← Fill transparency
  }
}
```

---

## ✅ Testing Checklist

After these fixes, test:

- [ ] Dashboard shows full alert names (not codes)
- [ ] Ticker shows full alert names (not codes)
- [ ] Ticker alerts have colored backgrounds
- [ ] Map polygons display with correct colors
- [ ] Setting `show_on_dashboard: false` hides alerts from dashboard
- [ ] Setting `show_on_ticker: false` hides alerts from ticker
- [ ] Alert counters update correctly
- [ ] Alert priorities sort correctly

---

## 🔧 How to Customize

### Example 1: Hide Special Weather Statements from Dashboard

They can clutter the dashboard, but you might want them on ticker:

```json
{
  "phenomenon_code": "SPS",
  "display_name": "Special Weather Statement",
  "show_on_dashboard": false,  ← Hide from dashboard
  "show_on_ticker": true,      ← Keep on ticker
  ...
}
```

### Example 2: Show Watches on Dashboard but Not Ticker

Watches are less urgent, might not need ticker space:

```json
{
  "phenomenon_code": "TOA",
  "display_name": "Tornado Watch",
  "show_on_dashboard": true,   ← Show on dashboard
  "show_on_ticker": false,     ← Don't clutter ticker
  ...
}
```

### Example 3: Change Lake Effect Snow Warning Color

Edit the colors section in the config:

```json
{
  "phenomenon_code": "LESW",
  "colors": {
    "primary": "#4169E1",       ← Change this (Royal Blue)
    "css_var": "#4169E1",
    "state_map": "#4169E1",
    "daily_recap": "#4169E1"
  },
  ...
}
```

Restart the server - new color applies everywhere automatically!

---

## 📊 Current Status

**Alert Types Configured:** 16

All 16 alerts now have:
✅ Full display names
✅ Colors for ticker backgrounds
✅ Dashboard visibility control
✅ Ticker visibility control
✅ Map visibility control

**Lake Effect Snow Warning Status:**
- **Code:** LESW
- **Color:** Dark Cyan (#008B8B)
- **Dashboard:** Visible ✅
- **Ticker:** Visible ✅
- **Map:** Visible ✅
- **Priority:** 7 (High)

---

## 🚀 Next Steps

1. **Test the Fixes:**
   - Start your Python backend
   - Open the dashboard
   - Check browser console for: "✅ Global alert configuration variables initialized"
   - Verify Lake Effect Snow Warning displays correctly

2. **Customize as Needed:**
   - Edit `alert_types_config.json`
   - Change `show_on_dashboard` or `show_on_ticker` for any alerts
   - Adjust colors as desired
   - Restart server

3. **Monitor for Lake Effect Snow Warnings:**
   - The system is now tracking LESW alerts
   - They will appear with dark cyan (#008B8B) coloring
   - Full name will display everywhere

---

## 🐛 Troubleshooting

### Alert names still showing as codes

1. Clear browser cache (Ctrl+F5)
2. Check browser console for errors
3. Verify `/api/alert_config` returns JSON (open in browser)
4. Check that `alert-config.js` is loading before `dashboard.js` in index.html

### Ticker colors not showing

1. Verify `colors.primary` is set in `alert_types_config.json`
2. Check browser console: "✅ Global alert configuration variables initialized"
3. Inspect `window.ALERT_TYPE_MAP` in browser console - should have `.color` property

### Alert not hiding when `show_on_dashboard: false`

1. Verify JSON syntax is correct (no missing commas)
2. Clear browser cache
3. Check browser console for config loading errors
4. Make sure your ticker/dashboard code is using `window.DASHBOARD_ALERTS` / `window.TICKER_ALERTS` to filter

---

## 📞 Support

If you encounter issues:

1. Check browser console (F12 → Console)
2. Check Python server logs
3. Validate JSON: https://jsonlint.com/
4. See [ADDING_NEW_ALERTS_GUIDE.md](ADDING_NEW_ALERTS_GUIDE.md)
5. See [ALERT_CONFIG_MIGRATION_SUMMARY.md](ALERT_CONFIG_MIGRATION_SUMMARY.md)

---

**Updated:** November 26, 2025
**Fixes Applied:** 2
**Features Added:** 1
**Files Modified:** 3 (dashboard.js, alert-config.js, alert_types_config.json)
