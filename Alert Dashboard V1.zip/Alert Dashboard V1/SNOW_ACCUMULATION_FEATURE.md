# Snow Accumulation Display Feature

## Overview

Added snow accumulation display to winter weather alerts, similar to how wind gusts and hail sizes are shown for severe thunderstorm warnings.

---

## What Was Added

### 1. Alert Model - New Field

**File:** [alert.py:33](alert.py:33)

Added `snow_amount` field to store parsed snow accumulation:

```python
snow_amount: str = None  # Snow accumulation (e.g., "4 to 13 inches")
```

### 2. Alert Parser - Snow Extraction Logic

**File:** [alert_parser.py](alert_parser.py)

Added parsing logic in two places:

**API Alerts (lines 155-167):**
- Parses from NWS API `description` field
- Handles patterns like:
  - "between 4 and 13 inches"
  - "4 to 13 inches"
  - "4 and 13 inches"
  - "13 inches" (single amount)

**NWWS Text Alerts (lines 570-579):**
- Parses from raw alert text
- Same pattern matching as API alerts
- Works with Lake Effect Snow Warnings, Winter Storm Warnings, etc.

**Pattern Matching:**
```regex
# Range: "between 4 and 13 inches" or "4 to 13 inches"
(?:between\s+)?(\d+)\s+(?:and|to)\s+(\d+)\s+inch(?:es)?

# Single: "13 inches"
(\d+)\s+inch(?:es)?
```

### 3. Dashboard Display - Alert Cards

**File:** [dashboard.js:2142-2144](dashboard.js:2142-2144)

Added snow icon and amount to threat details on alert cards:

```javascript
if (alert.snow_amount) {
  threatDetailsHTML += `<span class="threat-detail"><i class="fas fa-snowflake"></i> ${alert.snow_amount}</span>`;
}
```

Displays alongside:
- Wind gusts (🌬️)
- Hail size (⚪)
- Storm motion (🧭)

### 4. Dashboard Display - Alert Detail View

**File:** [dashboard.js:2265-2271](dashboard.js:2265-2271)

Added snow amount row to detailed alert view:

```javascript
if (alert.snow_amount) {
  infoHTML += `
    <div class="alert-detail-row">
      <span class="label">Snow Amount:</span>
      <span>${alert.snow_amount}</span>
    </div>`;
}
```

---

## Examples

### Alert Card Display

```
❄️ Lake Effect Snow Warning
  ❄️ 4 to 13 inches
  🌬️ Winds gusting to 50 mph
  🕐 Expires: 7:00 PM EST Friday
```

### Alert Detail View

```
Snow Amount: 4 to 13 inches
Max Wind: Winds gusting to 50 mph
Expires: 7:00 PM EST Friday
```

---

## Parsing Examples

### Input Text (from your alert):
```
Total snow accumulations between 4 and 13 inches.
Winds gusting as high as 50 mph.
```

### Parsed Output:
```json
{
  "snow_amount": "4 to 13 inches",
  "max_wind_gust": "Winds gusting to 50 mph"
}
```

### Other Patterns Supported:

| Alert Text | Parsed As |
|------------|-----------|
| "between 4 and 13 inches" | "4 to 13 inches" |
| "4 to 13 inches" | "4 to 13 inches" |
| "4 and 13 inches" | "4 to 13 inches" |
| "13 inches" | "13 inches" |
| "6 to 8 inches" | "6 to 8 inches" |

---

## Files Modified

1. **alert.py** - Added `snow_amount` field
2. **alert_parser.py** - Added snow parsing for API and NWWS alerts
3. **dashboard.js** - Added snow display to cards and detail view

---

## Testing

To test the feature:

1. **Restart your Python backend** - This will re-fetch the Lake Effect Snow Warning
2. **Clear cached alert** - The alert will be parsed with the new logic
3. **Check dashboard** - Should see:
   - ❄️ icon with "4 to 13 inches" on alert card
   - "Snow Amount: 4 to 13 inches" in detail view

### Expected Display for Your Current Alert:

```
❄️ Lake Effect Snow Warning
Cuyahoga; Lake; Geauga; Ashtabula Inland; Ashtabula Lakeshore

❄️ 4 to 13 inches
🌬️ Winds gusting to 50 mph
🕐 Expires: 7:00 PM EST Friday
```

---

## Future Enhancements

Possible improvements:

- Parse wind gust amounts from winter alerts (already done in your alert!)
- Highlight highest accumulation areas from text
- Parse ice accumulation for freezing rain
- Parse visibility in snow squalls
- Parse snow rates (e.g., "1 inch per hour")

---

## Notes

- Snow parsing is **case-insensitive**
- Works for **all winter alerts** (Lake Effect Snow, Winter Storm, etc.)
- Gracefully handles missing snow amounts (field remains `None`)
- Display is **conditional** - only shows if snow amount is present
- Uses **Font Awesome snowflake icon** (fas fa-snowflake)

---

**Added:** November 26, 2025
**Feature:** Snow accumulation display
**Affects:** All winter weather alerts
**Icon:** ❄️ (fas fa-snowflake)
