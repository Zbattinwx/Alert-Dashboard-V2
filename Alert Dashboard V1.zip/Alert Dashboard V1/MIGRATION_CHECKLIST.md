# Migration Checklist - Quick Wins Update

## ⚠️ Before You Start
**IMPORTANT:** These changes improve security and performance. Follow this checklist to ensure a smooth transition.

---

## 🔍 Pre-Migration Steps

### 1. Backup Current Configuration
```bash
# Create a backup of your current config
copy config.json config.json.backup
```

### 2. Verify Current Setup
- [ ] Dashboard is currently working
- [ ] You can access it at atmosphericx.ddns.net:8000
- [ ] NWWS connection is active
- [ ] OBS integration is working

---

## 📝 Migration Steps

### Step 1: Review the .env File (Already Created)
The `.env` file has been created with your current credentials from `config.json`.

**Action Required:**
- [ ] Open `.env` and verify all credentials are correct
- [ ] Ensure SSL certificate paths are correct for production
- [ ] Confirm `ENVIRONMENT=development` is set (or `production` if deploying to prod)

**File Location:** `c:\Users\zbattin\Documents\ONWAlertDashboard - December 2025\.env`

### Step 2: Install python-dotenv (Already Installed)
```bash
pip install python-dotenv
```
✅ **Status:** Already installed in your environment

### Step 3: Test the Application
```bash
# Start the application
python main_app.py
```

**Expected Output:**
- Should see "Loading environment variables from .env"
- No errors about missing credentials
- NWWS connection should establish
- WebSocket server starts on port 8765
- HTTP server starts on port 8080

### Step 4: Test Dashboard Connection
1. [ ] Open browser to `http://localhost:8000` (or your usual URL)
2. [ ] Verify alerts are loading
3. [ ] Check WebSocket connection status in browser console
4. [ ] Test OBS connection (should connect automatically)
5. [ ] Try stopping and restarting the server (should auto-reconnect)

### Step 5: Test Health Endpoint
```bash
curl http://localhost:8000/health
```
or open in browser:
```
http://localhost:8000/health
```

**Expected Response:**
```json
{
  "status": "healthy",
  "uptime_seconds": 123,
  "environment": "development",
  ...
}
```

### Step 6: Test Reconnection Logic
1. [ ] Open dashboard in browser
2. [ ] Open browser console (F12)
3. [ ] Stop the Python backend (Ctrl+C)
4. [ ] Watch console for reconnection attempts
5. [ ] Restart Python backend
6. [ ] Verify dashboard reconnects automatically

---

## 🚀 Production Deployment Checklist

### When Ready for Production on atmosphericx.ddns.net:

1. [ ] Stop the current production server

2. [ ] Update `.env` on production server:
   ```
   ENVIRONMENT=production
   ```

3. [ ] Verify SSL certificate paths in `.env`:
   ```
   SSL_CERT_PATH=C:\ssl-certs\atmosphericx.ddns.net-chain.pem
   SSL_KEY_PATH=C:\ssl-certs\atmosphericx.ddns.net-key.pem
   ```

4. [ ] Start the server:
   ```bash
   python main_app.py
   ```

5. [ ] Verify SSL is enabled (should see HTTPS/WSS in logs)

6. [ ] Test from remote location:
   - [ ] Navigate to `https://atmosphericx.ddns.net:8000`
   - [ ] Verify SSL certificate is valid
   - [ ] Test dashboard functionality
   - [ ] Verify team members can access

7. [ ] Test health endpoint:
   ```bash
   curl https://atmosphericx.ddns.net:8000/health
   ```

---

## ✅ Verification Checklist

### Functionality Tests
- [ ] Dashboard loads and displays alerts
- [ ] WebSocket connection is stable
- [ ] Auto-reconnection works after disconnect
- [ ] NWWS connection is active
- [ ] OBS connection works (if using)
- [ ] Storm report submission works
- [ ] Map displays correctly
- [ ] Filters work properly
- [ ] Theme switching works

### Security Tests
- [ ] No credentials visible in browser console
- [ ] OBS password not in dashboard.js source
- [ ] `.env` file not committed to git
- [ ] `config.json` has no sensitive data
- [ ] SSL works in production mode

### Performance Tests
- [ ] Dashboard loads quickly
- [ ] No lag during file saves (every 5 minutes)
- [ ] WebSocket messages are responsive
- [ ] No console errors

---

## 🆘 Rollback Plan (If Needed)

If something goes wrong, you can quickly rollback:

### Option 1: Restore Old config.json
```bash
copy config.json.backup config.json
```

### Option 2: Use Git (if versioned)
```bash
git checkout HEAD~1 config.json main_app.py dashboard.js
```

### Option 3: Manual Revert
The old credentials are still in `config.json.backup`. You can:
1. Copy values back from backup
2. Remove the `load_dotenv()` calls
3. Restart the server

**Note:** The new code is backward compatible, so the main issue would be missing environment variables.

---

## 📊 Success Criteria

Your migration is successful when:
- ✅ Dashboard loads at atmosphericx.ddns.net:8000
- ✅ Team members can access remotely
- ✅ Alerts are updating in real-time
- ✅ No credentials in config.json
- ✅ Health endpoint responds
- ✅ Auto-reconnection works
- ✅ File I/O is non-blocking
- ✅ OBS connects without hardcoded password

---

## 🔐 Security Verification

### Critical: Ensure These Files Are NOT in Git
```bash
# Check git status
git status

# These files should be listed under "Untracked" or in .gitignore:
# - .env
# - service-account.json
# - config.json (if it contains any sensitive data)
```

### Add to .gitignore if Needed
Your `.gitignore` already includes these files, but verify:
```
.env
service-account.json
config.json
```

---

## 📞 Getting Help

### Common Issues

**Issue 1: "NWWS_USERNAME not found"**
- Check `.env` file exists
- Verify variable names match exactly
- Ensure no extra spaces in `.env` file

**Issue 2: "Module not found: dotenv"**
```bash
pip install python-dotenv
```

**Issue 3: Dashboard won't connect**
- Check browser console for errors
- Verify WebSocket URL is correct
- Check firewall settings
- Test health endpoint first

**Issue 4: SSL not working in production**
- Verify `ENVIRONMENT=production` in `.env`
- Check certificate paths are correct
- Ensure certificates are valid and not expired

---

## 📝 Post-Migration Tasks

After successful migration:

1. [ ] Update team documentation with new environment variable setup
2. [ ] Share `.env.example` with team members
3. [ ] Document the health endpoint URL for monitoring
4. [ ] Set up monitoring alerts using the health endpoint (optional)
5. [ ] Remove old `config.json.backup` once verified working
6. [ ] Consider setting up automated health checks

---

## 🎉 Next Steps

Once these quick wins are stable, consider:
1. **Database Migration** - Move from JSON files to SQLite/PostgreSQL
2. **Rate Limiting** - Add API rate limiting for security
3. **Metrics** - Add Prometheus metrics for monitoring
4. **Testing** - Add automated test suite
5. **Code Splitting** - Break down large files into modules

---

**Last Updated:** 2025-12-05
**Status:** Ready for Migration
**Estimated Migration Time:** 15-30 minutes
