# ONW Alert Dashboard - Remote Access Guide

This guide is for users accessing the ONW Alert Dashboard hosted remotely at **https://atmosphericx.ddns.net:8000/**

## Overview

The ONW Alert Dashboard is already running on a remote server and is accessible via the web. You don't need to install anything - just open your browser and connect!

## Quick Start

### Accessing the Dashboard

1. Open your web browser (Chrome, Firefox, Edge, or Safari)
2. Navigate to: **https://atmosphericx.ddns.net:8000/index.html**
3. Enter the dashboard password (contact the administrator if you don't have it)
4. Start monitoring weather alerts!

**Note**: The first time you access the site, your browser may show a security warning about the SSL certificate. This is normal for self-signed certificates - click "Advanced" and "Proceed to site" to continue.

## Dashboard Features

### Main Dashboard Sections

Once logged in, you'll see a sidebar menu with these sections:

#### Director Panel
Control OBS Studio remotely (requires OBS WebSocket plugin configured on the streaming computer)
- Switch OBS scenes
- Toggle source visibility
- Show/hide lower thirds
- View live preview

#### Active Alerts
Real-time display of active weather warnings
- Color-coded by severity (red = tornado, orange = severe storm, etc.)
- Click any alert to see full details
- Click the star icon to feature an alert in OBS
- Alerts auto-expire when no longer active

#### Alert Map
Interactive map showing warning polygons
- Toggle radar overlay
- View Tempest weather station locations
- Click polygons for alert details
- Zoom and pan with mouse/touch

#### Local Storm Reports (LSR)
Recent storm reports from the National Weather Service and user submissions
- Filter by report type (tornado, hail, wind, flood)
- View photos if available
- Submit your own reports (see below)

#### Snow Accumulation Map
Visual representation of snow depths (opens in new tab)
- Color-coded depth indicators
- Updated as reports come in
- Historical data view

#### ODOT Feeds
Live traffic camera feeds from Ohio Department of Transportation
- Search by location
- Click camera to view live image
- "Feature in OBS" button sends camera to stream

#### SPC Outlooks
Storm Prediction Center convective outlooks
- Day 1, 2, and 3 outlooks
- Risk categories and details
- Updated multiple times per day

#### Mesoscale Discussions
SPC mesoscale discussions about developing severe weather
- Real-time updates
- Links to full text
- Map graphics

#### Area Forecast Discussions (AFD)
Detailed forecasts from NWS offices
- Select from multiple offices
- Meteorologist-written analyses
- Updated several times per day

#### Top Wind Gusts
Highest wind speeds from Tempest weather stations
- Real-time updates during wind events
- Location and speed data

#### Snow Emergencies
Snow emergency levels by county (Ohio)
- Level 1, 2, 3 indicators
- County-by-county breakdown
- Updated during winter storms

#### NWWS Products Issued
Recent products issued via NWS Weather Wire
- Product type and issuing office
- Timestamp
- Quick reference for latest activity

#### Daily Recap
Statistics for today's alerts
- Alert counts by type
- Timeline of issuances
- Historical comparison

#### Ticker Settings
Customize the alert ticker (if you have streaming access)
- Adjust scroll speed
- Change themes
- Set custom messages

## Using OBS Widgets (For Streamers)

If you're using OBS Studio to stream weather coverage, you can add browser sources pointing to the remote server.

### Available OBS Widgets

Replace `http://localhost:8080` with `https://atmosphericx.ddns.net:8000` in all widget URLs.

#### 1. Alert Ticker
- **URL**: `https://atmosphericx.ddns.net:8000/ticker.html`
- **Purpose**: Scrolling ticker showing active alerts
- **Recommended Size**: 1920x80
- **Features**: Auto-updates, shows all active alerts

#### 2. Sponsored Ticker
- **URL**: `https://atmosphericx.ddns.net:8000/ticker-sponsored.html`
- **Purpose**: Ticker with sponsor logo
- **Recommended Size**: 1920x100

#### 3. Featured Alert Widget
- **URL**: `https://atmosphericx.ddns.net:8000/feature.html`
- **Purpose**: Large graphic for single high-priority alert
- **Recommended Size**: 800x600
- **Usage**: Click star icon on any alert in dashboard to feature it
- **Auto-hides**: After 20 seconds

#### 4. New Alert Chime
- **URL**: `https://atmosphericx.ddns.net:8000/new_alert.html`
- **Purpose**: Audio/visual alert for new tornado, severe storm, or flash flood warnings
- **Recommended Size**: 600x200
- **Auto-hides**: After 5 seconds

#### 5. Alert Rotator
- **URL**: `https://atmosphericx.ddns.net:8000/rotator.html`
- **Purpose**: Cycles through active alert titles
- **Recommended Size**: 600x100

#### 6. Lower Third
- **URL**: `https://atmosphericx.ddns.net:8000/lower_third.html`
- **Purpose**: Professional lower third graphic
- **Recommended Size**: 1920x200
- **Usage**: Control from Director Panel

#### 7. Camera Widget
- **URL**: `https://atmosphericx.ddns.net:8000/camera_widget.html`
- **Purpose**: Display single ODOT traffic camera
- **Recommended Size**: 640x480
- **Usage**: Click "Feature in OBS" on any camera in ODOT Feeds

#### 8. Camera Rotator
- **URL**: `https://atmosphericx.ddns.net:8000/camera_rotator.html`
- **Purpose**: Cycle through multiple cameras automatically
- **Recommended Size**: 640x480

### Adding a Remote Widget to OBS

1. In OBS, add a new **Browser Source**
2. Set the URL to the widget (e.g., `https://atmosphericx.ddns.net:8000/ticker.html`)
3. Set width and height (see recommended sizes above)
4. **Important**: Uncheck "Local file" - you're using a web URL
5. Check "Shutdown source when not visible" to save resources
6. Click OK

The widget will connect to the remote dashboard and update in real-time.

## Submitting Storm Reports

You can submit storm reports directly to the dashboard:

1. Navigate to: **https://atmosphericx.ddns.net:8000/submit_report.html**
2. Allow location access (or enter location manually)
3. Select report type:
   - Tornado
   - Funnel Cloud
   - Hail
   - Wind Damage
   - Flooding
4. Enter details:
   - Description
   - Measurements (hail size, wind speed, etc.)
   - Upload a photo (optional)
5. Complete reCAPTCHA verification
6. Submit

Your report will appear immediately on the dashboard's Local Storm Reports page.

### Report Guidelines

- Be accurate with location
- Include specific details (hail size, damage description, etc.)
- Photos are valuable - upload if safe to do so
- Do not submit reports while in immediate danger
- Reports are public and visible to all dashboard users

## Understanding Alert Colors

Alerts are color-coded by severity:

| Color | Alert Type |
|-------|-----------|
| Red | Tornado Warning, Flash Flood Emergency |
| Dark Orange | Severe Thunderstorm Warning (destructive) |
| Orange | Severe Thunderstorm Warning |
| Yellow/Gold | Flash Flood Warning |
| Pink/Magenta | Winter Storm Warning, Lake Effect Snow Warning |
| Light Blue | Winter Weather Advisory |
| Cyan | Snow Squall Warning |
| Purple | Storm Surge Warning |
| Dark Red | Tornado Watch |
| Yellow | Severe Thunderstorm Watch |
| Green | Flash Flood Watch |
| Blue | Winter Storm Watch |
| Gray | Special Weather Statement |

## Dashboard Themes

The dashboard supports multiple visual themes. Change themes using the settings icon (gear) in the top right corner:

- **Classic**: Traditional weather dashboard look
- **Atmospheric**: Modern gradient design
- **Storm Chaser**: High-contrast for field use
- **Meteorologist**: Professional broadcast style
- **Winter**: Ice blue theme for winter weather

Your theme preference is saved in your browser.

## Mobile Access

The dashboard is mobile-friendly!

### On Your Phone/Tablet:

1. Open browser (Safari, Chrome, etc.)
2. Navigate to: `https://atmosphericx.ddns.net:8000/index.html`
3. Enter password
4. Tap menu items to navigate
5. Pinch to zoom on maps

**Tip**: Add to home screen for quick access:
- **iOS**: Tap share icon → "Add to Home Screen"
- **Android**: Tap menu → "Add to Home Screen"

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `Esc` | Close modal/overlay |
| `?` | Show help (if implemented) |

## Connectivity Requirements

### Minimum Internet Speed:
- **Download**: 5 Mbps recommended
- **Upload**: 1 Mbps (for storm report uploads)

### Data Usage:
- Dashboard: ~50 MB per hour of active use
- OBS widgets: ~10-20 MB per hour per widget
- Photos uploaded: Depends on photo size (typically 2-5 MB)

### Bandwidth-Saving Tips:
- Close OBS widgets when not streaming
- Avoid loading multiple map layers simultaneously
- Compress photos before uploading reports

## Troubleshooting

### Can't Access Dashboard

**Problem**: Browser shows "Site can't be reached" or times out

**Solutions**:
1. Check your internet connection
2. Verify the URL: `https://atmosphericx.ddns.net:8000/index.html`
3. Try a different browser
4. Check if the server is temporarily down (contact administrator)
5. Disable VPN if using one (it may block the connection)

### SSL Certificate Warning

**Problem**: Browser shows "Your connection is not private" or similar

**Solution**:
1. Click "Advanced" or "Details"
2. Click "Proceed to atmosphericx.ddns.net" or "Accept the risk"
3. This is normal for self-signed certificates on private servers

**Why this happens**: The server uses a self-signed SSL certificate rather than one from a commercial certificate authority.

### OBS Widgets Not Connecting

**Problem**: Widgets in OBS show "Connecting..." or are blank

**Solutions**:
1. Verify the URL is exactly: `https://atmosphericx.ddns.net:8000/[widget].html`
2. Refresh the browser source (right-click → Refresh)
3. Check your firewall settings
4. Try accessing the widget URL in a regular browser first
5. Ensure OBS isn't blocking WebSocket connections

### Dashboard Not Updating

**Problem**: Alerts appear frozen or outdated

**Solutions**:
1. Refresh the page (F5 or Ctrl+R)
2. Check your internet connection
3. Clear browser cache (Ctrl+Shift+Delete)
4. Try a different browser
5. Check if server is experiencing issues

### Wrong Password

**Problem**: "Invalid password" message

**Solution**:
Contact the dashboard administrator for the correct password

### Report Submission Failed

**Problem**: Storm report won't submit

**Solutions**:
1. Check internet connection
2. Complete the reCAPTCHA verification
3. Ensure all required fields are filled
4. Try reducing photo size if uploading large images
5. Your IP may be blocked - contact administrator

## Privacy and Data

### What Data is Collected:

- **IP Addresses**: Logged for storm report spam prevention
- **Location**: Only if you allow it for storm reports
- **Browser Info**: For compatibility and troubleshooting
- **Usage Statistics**: Anonymous dashboard usage

### What Data is NOT Collected:

- Personal information (unless you provide it in reports)
- Browsing history
- Passwords (stored securely, never transmitted)

### Storm Report Data:

- Reports are public and visible to all users
- Location data is approximate (nearest town/landmark)
- Photos may be used in broadcasts or social media
- IP addresses are logged to prevent abuse

## Best Practices

### For Alert Monitoring:
- Keep dashboard open in a dedicated browser window/tab
- Enable browser notifications if available
- Check multiple sections for comprehensive weather picture
- Cross-reference SPC outlooks with active alerts

### For Streaming:
- Test all OBS widgets before going live
- Keep ticker active when streaming severe weather
- Feature high-priority alerts manually with star icon
- Use lower thirds for on-air meteorologists
- Monitor server connection status

### For Storm Reporting:
- Report from a safe location only
- Be as specific as possible with details
- Upload clear, well-lit photos
- Include approximate time of observation
- Don't exaggerate or speculate

## Advanced Features

### OBS WebSocket Control

If the administrator has configured OBS WebSocket, you can:
- Control OBS scenes remotely from the dashboard
- Toggle source visibility
- Show/hide widgets programmatically
- View live preview of program output

**Setup Required**: Administrator must configure OBS WebSocket and credentials.

### Google Chat Integration

Some alerts may be posted to Google Chat if configured by administrator.

### Daily Recap Statistics

View comprehensive statistics about the day's weather:
- Total alerts issued
- Breakdown by type
- Most active counties
- Timeline visualization

## Contact and Support

### Getting Help:

- **Technical Issues**: Contact the dashboard administrator
- **Weather Questions**: Consult National Weather Service ([weather.gov](https://www.weather.gov))
- **Feature Requests**: Submit to administrator

### Administrator Contact:

Contact the person who provided you with the dashboard URL and password.

## Limitations

### What This Dashboard Is:

- Real-time alert monitoring tool
- Streaming broadcast integration
- Community storm reporting platform
- Educational weather resource

### What This Dashboard Is Not:

- A replacement for official NWS products
- Guaranteed to be 100% available
- A weather forecasting service
- Suitable for life-safety decisions alone

**Always follow official NWS guidance and local emergency management instructions during severe weather.**

## System Status

### How to Check if Server is Running:

1. Try accessing: `https://atmosphericx.ddns.net:8000/index.html`
2. If the login page loads, server is running
3. If you get "can't be reached", server may be down or restarting

### Scheduled Maintenance:

The server may restart periodically for maintenance. Restarts typically take 30-60 seconds.

## Related Documentation

For technical documentation (developers and server administrators):
- **Local Setup Guide**: [LOCAL_SETUP_GUIDE.md](LOCAL_SETUP_GUIDE.md)
- **Architecture**: [ARCHITECTURE.md](ARCHITECTURE.md)
- **Alert Configuration**: [ADDING_NEW_ALERTS_GUIDE.md](ADDING_NEW_ALERTS_GUIDE.md)

## Bookmarks

Save these URLs for quick access:

- **Main Dashboard**: `https://atmosphericx.ddns.net:8000/index.html`
- **Submit Report**: `https://atmosphericx.ddns.net:8000/submit_report.html`
- **Snow Map**: `https://atmosphericx.ddns.net:8000/snow_map.html`
- **State Map**: `https://atmosphericx.ddns.net:8000/state_map.html`

## Updates and Changes

The dashboard is continuously improved. New features and fixes are deployed regularly. Check with the administrator for the latest updates and feature additions.

---

**Stay Safe and Monitor Wisely!**

For emergencies, always dial 911 or follow guidance from local emergency management.
