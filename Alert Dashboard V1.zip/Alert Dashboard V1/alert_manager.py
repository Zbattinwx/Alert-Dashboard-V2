# alert_manager.py
# ==================================================================================
# ALERT MANAGER SERVICE
# ==================================================================================
# This service manages all alert state and operations:
# - Active alerts storage
# - Recent products tracking
# - AFD (Area Forecast Discussion) tracking
# - Manual Local Storm Reports (LSRs)
# - Alert expiration handling
# ==================================================================================

import collections
import json
import os
from datetime import datetime, timezone
from typing import Dict, List, Optional, Set
from alert import Alert
from daily_stats import get_daily_stats_tracker


class AlertManager:
    """
    Manages the lifecycle and state of all weather alerts in the system.
    Provides centralized alert storage, retrieval, and expiration handling.
    """

    def __init__(self, cache_file: str = "active_alerts.json"):
        """
        Initializes the AlertManager.

        Args:
            cache_file: Path to JSON file for persisting alert state
        """
        self.cache_file = cache_file
        self.active_alerts: Dict[str, Alert] = {}
        self.recent_products = collections.deque(maxlen=20)
        self.latest_afds: Dict[str, str] = {}
        self.manual_lsrs: List[dict] = []

    # ==================================================================================
    # ALERT OPERATIONS
    # ==================================================================================

    def add_alert(self, alert: Alert) -> bool:
        """
        Adds a new alert to active alerts.

        Args:
            alert: The Alert object to add

        Returns:
            True if added (new alert), False if already exists
        """
        if alert.product_id in self.active_alerts:
            return False

        self.active_alerts[alert.product_id] = alert

        # Track alert for daily statistics (only new, non-update alerts)
        try:
            stats_tracker = get_daily_stats_tracker()
            stats_tracker.record_alert(alert)
        except Exception as e:
            print(f"⚠️ Error tracking alert for daily stats: {e}")

        return True

    def get_alert(self, product_id: str) -> Optional[Alert]:
        """
        Retrieves an alert by its product ID.

        Args:
            product_id: The alert's product identifier

        Returns:
            The Alert object or None if not found
        """
        return self.active_alerts.get(product_id)

    def update_alert(self, alert: Alert) -> bool:
        """
        Updates an existing alert or adds it if not present.

        Args:
            alert: The Alert object to update/add

        Returns:
            True if alert was updated, False if newly added
        """
        exists = alert.product_id in self.active_alerts
        self.active_alerts[alert.product_id] = alert
        return exists

    def remove_alert(self, product_id: str) -> bool:
        """
        Removes an alert from active alerts.

        Args:
            product_id: The product ID to remove

        Returns:
            True if removed, False if not found
        """
        if product_id in self.active_alerts:
            del self.active_alerts[product_id]
            return True
        return False

    def get_all_alerts(self) -> Dict[str, Alert]:
        """Returns all active alerts as a dictionary."""
        return self.active_alerts

    def get_alert_count(self) -> int:
        """Returns the number of active alerts."""
        return len(self.active_alerts)

    def clear_all_alerts(self) -> int:
        """
        Clears all active alerts.

        Returns:
            Number of alerts that were removed
        """
        count = len(self.active_alerts)
        self.active_alerts.clear()
        return count

    # ==================================================================================
    # ALERT EXPIRATION HANDLING
    # ==================================================================================

    def clear_expired_alerts(self) -> int:
        """
        Removes all expired alerts from the active list.

        Returns:
            Number of alerts that were removed
        """
        now_utc = datetime.now(timezone.utc)
        initial_count = len(self.active_alerts)

        unexpired_alerts = {
            alert_id: alert for alert_id, alert in self.active_alerts.items()
            if not (alert.expiration_time and alert.expiration_time < now_utc)
        }

        removed_count = initial_count - len(unexpired_alerts)

        if removed_count > 0:
            self.active_alerts.clear()
            self.active_alerts.update(unexpired_alerts)
            print(f"Cleared {removed_count} expired alert(s).")

        return removed_count

    # ==================================================================================
    # RECENT PRODUCTS
    # ==================================================================================

    def add_recent_product(self, product: dict) -> None:
        """
        Adds a product to the recent products queue.

        Args:
            product: Product data to add (automatically limited to 20 most recent)
        """
        self.recent_products.appendleft(product)

    def get_recent_products(self) -> List[dict]:
        """Returns list of recent products."""
        return list(self.recent_products)

    def clear_recent_products(self) -> None:
        """Clears all recent products."""
        self.recent_products.clear()

    # ==================================================================================
    # AREA FORECAST DISCUSSIONS (AFDs)
    # ==================================================================================

    def add_afd(self, office: str, text: str) -> None:
        """
        Stores an Area Forecast Discussion for a given office.

        Args:
            office: Weather office code (e.g., "CLE", "ILN")
            text: Full AFD text content
        """
        self.latest_afds[office] = text

    def get_afd(self, office: str) -> Optional[str]:
        """
        Retrieves the latest AFD for an office.

        Args:
            office: Weather office code

        Returns:
            AFD text or None if not available
        """
        return self.latest_afds.get(office)

    def get_all_afds(self) -> Dict[str, str]:
        """Returns all stored AFDs."""
        return self.latest_afds

    # ==================================================================================
    # MANUAL LOCAL STORM REPORTS (LSRs)
    # ==================================================================================

    def add_manual_lsr(self, report: dict) -> None:
        """
        Adds a manual storm report.

        Args:
            report: LSR data dictionary
        """
        self.manual_lsrs.append(report)

    def get_manual_lsrs(self) -> List[dict]:
        """Returns all manual LSRs."""
        return self.manual_lsrs

    def clear_manual_lsrs(self) -> int:
        """
        Clears all manual storm reports.

        Returns:
            Number of reports that were cleared
        """
        count = len(self.manual_lsrs)
        self.manual_lsrs.clear()
        return count

    # ==================================================================================
    # TEST ALERT MANAGEMENT
    # ==================================================================================

    def clear_test_alerts(self) -> int:
        """
        Removes all alerts marked as test alerts.

        Returns:
            Number of test alerts removed
        """
        test_alert_ids = [
            alert_id for alert_id, alert in self.active_alerts.items()
            if getattr(alert, 'is_test', False)
        ]

        for alert_id in test_alert_ids:
            del self.active_alerts[alert_id]

        if test_alert_ids:
            print(f"Cleared {len(test_alert_ids)} test alert(s)")

        return len(test_alert_ids)

    # ==================================================================================
    # PERSISTENCE (Save/Load from Disk)
    # ==================================================================================

    def save_to_disk(self) -> bool:
        """
        Saves the current state to disk.

        Returns:
            True if successful, False on error
        """
        print(f"Saving {len(self.active_alerts)} alerts and {len(self.recent_products)} products to disk.")
        try:
            with open(self.cache_file, 'w') as f:
                data_to_save = {
                    "active_alerts": {
                        alert_id: alert.to_json() for alert_id, alert in self.active_alerts.items()
                    },
                    "recent_products": list(self.recent_products),
                    "latest_afds": self.latest_afds
                }
                json.dump(data_to_save, f, indent=2)
            return True
        except Exception as e:
            print(f"❌ Error saving alerts to disk: {e}")
            return False

    def load_from_disk(self) -> bool:
        """
        Loads alert state from disk.

        Returns:
            True if loaded successfully, False if file doesn't exist or error
        """
        if not os.path.exists(self.cache_file):
            print("No existing alert cache file found.")
            return False

        try:
            with open(self.cache_file, 'r') as f:
                data = json.load(f)

            # Restore active alerts
            self.active_alerts.clear()
            for alert_id, alert_data in data.get("active_alerts", {}).items():
                # Check for required raw_text field
                raw_text_from_cache = alert_data.get("raw_text")
                if not raw_text_from_cache:
                    print(f"⚠️ Skipping alert {alert_id} from cache, missing raw_text.")
                    continue

                # Instantiate the Alert with the required text, then update it
                alert = Alert(raw_text_from_cache)
                alert.__dict__.update(alert_data)

                # Ensure datetime objects are properly restored
                if isinstance(alert.issue_time, str):
                    alert.issue_time = datetime.fromisoformat(alert.issue_time)
                if isinstance(alert.expiration_time, str):
                    alert.expiration_time = datetime.fromisoformat(alert.expiration_time)

                self.active_alerts[alert_id] = alert

            # Restore recent products
            self.recent_products.clear()
            for product in data.get("recent_products", []):
                self.recent_products.append(product)

            # Restore AFD data
            self.latest_afds.update(data.get("latest_afds", {}))

            print(f"Loaded {len(self.active_alerts)} alerts and {len(self.recent_products)} products from disk.")
            return True

        except Exception as e:
            print(f"Error loading alerts from disk: {e}")
            # Clean up corrupted file
            if os.path.exists(self.cache_file):
                os.remove(self.cache_file)
                print("Removed corrupted alert cache file.")
            return False

    # ==================================================================================
    # STATISTICS
    # ==================================================================================

    def get_stats(self) -> dict:
        """Returns statistics about the current alert state."""
        return {
            "active_alerts": len(self.active_alerts),
            "recent_products": len(self.recent_products),
            "afds": len(self.latest_afds),
            "manual_lsrs": len(self.manual_lsrs)
        }
