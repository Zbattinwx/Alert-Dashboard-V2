# logger.py
# ==================================================================================
# LOGGING UTILITY MODULE
# ==================================================================================
# Provides configurable logging with different verbosity levels to reduce
# console clutter while maintaining important information visibility.
# ==================================================================================

from typing import Optional

class Logger:
    """
    Configurable logger with verbosity levels.

    Log Levels:
    - minimal: Only critical errors and important status (restarts, connections)
    - normal: Errors, warnings, and key events (new alerts, summaries)
    - verbose: All messages including debug info (zone geometry, API calls)
    """

    LEVEL_MINIMAL = 0
    LEVEL_NORMAL = 1
    LEVEL_VERBOSE = 2

    def __init__(self, level: str = "normal"):
        """
        Initialize logger with specified level.

        Args:
            level: One of "minimal", "normal", or "verbose"
        """
        self.set_level(level)

    def set_level(self, level: str):
        """
        Set the logging level.

        Args:
            level: One of "minimal", "normal", or "verbose"
        """
        level = level.lower()
        if level == "minimal":
            self.level = self.LEVEL_MINIMAL
        elif level == "verbose" or level == "debug":
            self.level = self.LEVEL_VERBOSE
        else:
            self.level = self.LEVEL_NORMAL

        level_names = {
            self.LEVEL_MINIMAL: "MINIMAL",
            self.LEVEL_NORMAL: "NORMAL",
            self.LEVEL_VERBOSE: "VERBOSE"
        }
        # Avoid emoji in logger initialization to prevent encoding issues
        print(f"Logging level set to: {level_names[self.level]}")

    def minimal(self, message: str):
        """Log critical/important messages (always shown)."""
        if self.level >= self.LEVEL_MINIMAL:
            print(message)

    def info(self, message: str):
        """Log normal informational messages."""
        if self.level >= self.LEVEL_NORMAL:
            print(message)

    def debug(self, message: str):
        """Log verbose debug messages."""
        if self.level >= self.LEVEL_VERBOSE:
            print(message)

    def error(self, message: str):
        """Log errors (always shown)."""
        print(message)

    def warning(self, message: str):
        """Log warnings (shown in normal and verbose)."""
        if self.level >= self.LEVEL_NORMAL:
            print(message)


# Global logger instance
_logger: Optional[Logger] = None


def get_logger() -> Logger:
    """Get or create the global logger instance."""
    global _logger
    if _logger is None:
        _logger = Logger()
    return _logger


def set_log_level(level: str):
    """Set the global logging level."""
    logger = get_logger()
    logger.set_level(level)
