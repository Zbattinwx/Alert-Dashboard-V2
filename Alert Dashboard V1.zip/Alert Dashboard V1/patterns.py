# patterns.py
# ==================================================================================
# COMPILED REGEX PATTERNS MODULE
# ==================================================================================
# This module contains pre-compiled regex patterns used for parsing weather alerts.
# Pre-compiling patterns improves performance and makes them easier to test/maintain.
# ==================================================================================

import re

# ==================================================================================
# ALERT STRUCTURE PATTERNS
# ==================================================================================

# Detects if alert is in XML/CAP format
PATTERN_XML_ALERT = re.compile(r'<alert.*?>', re.DOTALL)

# Extracts event ending time from XML (preferred - when the weather event actually ends)
# CAP format stores this as a parameter: <valueName>eventEndingTime</valueName><value>...</value>
PATTERN_XML_EVENT_ENDING_TIME = re.compile(r'<valueName>eventEndingTime</valueName>\s*<value>(.*?)</value>')

# Extracts message expiration time from XML (fallback - when the alert message stops being distributed)
PATTERN_XML_EXPIRES = re.compile(r'<expires>(.*?)</expires>')

# Extracts FIPS codes from XML (handles both FIPS6 and SAME format)
PATTERN_XML_FIPS = re.compile(r'<valueName>(?:FIPS6|SAME)</valueName>[\s\S]*?<value>(\d{5,6})</value>')

# Extracts UGC codes from XML
PATTERN_XML_UGC = re.compile(r'<valueName>UGC</valueName>[\s\S]*?<value>([A-Z]{2}[CZ]\d{3})</value>')

# Extracts area description from XML
PATTERN_XML_AREA_DESC = re.compile(r'<areaDesc>([\s\S]*?)</areaDesc>')

# ==================================================================================
# VTEC (Valid Time Extent Code) PATTERNS
# ==================================================================================

# Main VTEC string pattern (e.g., /O.NEW.KCLE.TO.W.0001.250120T1500Z-250120T1600Z/)
PATTERN_VTEC = re.compile(r'(/O\..*?/)')

# VTEC timestamp update pattern for test alerts
PATTERN_VTEC_TIMESTAMP = re.compile(r'(/O\.[A-Z]{3}\.[A-Z]{4}\.[A-Z]{2}\.[A-Z]\.\d{4}\.)(\d{6}T\d{4}Z)(-\d{6}T\d{4}Z/)')

# ==================================================================================
# UGC (Universal Geographic Code) PATTERNS
# ==================================================================================

# UGC line pattern (e.g., "OHC049-041-061-200300-")
PATTERN_UGC_LINE = re.compile(r'^[A-Z]{2}[CZ].*?-\d{6}-?$', re.MULTILINE)

# UGC expiration timestamp pattern
PATTERN_UGC_EXPIRATION = re.compile(r'([A-Z]{2}[CZ]\d{3}(?:-\d{3})*-)(\d{6})(-)')

# UGC prefix extraction (e.g., "OHC" or "OHZ")
PATTERN_UGC_PREFIX = re.compile(r'([A-Z]{2}[CZ])')

# ==================================================================================
# LOCATION AND DESCRIPTION PATTERNS
# ==================================================================================

# Location description (between UGC line and time)
PATTERN_LOCATION_DESC = re.compile(
    r'^[A-Z]{2}[CZ].*?-\d{6}-?\n((?:.|\n)*?)\n\d{3,4}\s(?:AM|PM)\s[A-Z]{3,4}',
    re.MULTILINE
)

# Counties block in SPC watches
PATTERN_WATCH_COUNTIES = re.compile(
    r'IN (?:.*?) THIS WATCH INCLUDES \d+ COUNTIES\n\n(?:.*\n\n)?((?:.|\n)*?)\$\$'
)

# SPC watch county list extraction
PATTERN_WATCH_COUNTY_SECTION = re.compile(
    r'IN\s+(?:.*?)\s+THIS WATCH INCLUDES.*?(?:IN CENTRAL OHIO|IN (?:[A-Z]+ )?OHIO)(.*?)\$\$',
    re.DOTALL
)

# County names in watch products
PATTERN_COUNTY_NAMES = re.compile(r'([A-Z]{3,})')

# ==================================================================================
# WATCH PATTERNS
# ==================================================================================

# Tornado or Severe Thunderstorm Watch header
PATTERN_WATCH_HEADER = re.compile(r'^\s*(?:TORNADO|SEVERE THUNDERSTORM) WATCH', re.MULTILINE | re.IGNORECASE)

# Watch number extraction
PATTERN_WATCH_NUMBER = re.compile(r'WATCH\s+(\d+)')

# Watch expiration time (e.g., "UNTIL 800 PM EDT")
PATTERN_WATCH_EXPIRATION = re.compile(r'(?:UNTIL|THROUGH)\s+(\d{3,4})\s+(AM|PM)\s+([A-Z]{3,4})')

# Watch UGC codes extraction (from WOU - Watch Outline Update)
# Matches lines like: LAC003-011-013-015-017-019-021-290300-
# These span multiple lines, so we capture each line segment separately
PATTERN_WATCH_UGC = re.compile(r'^([A-Z]{2}[CZ]\d{3}(?:-\d{3})*-)$', re.MULTILINE)

# ==================================================================================
# SPECIAL WEATHER STATEMENT PATTERNS
# ==================================================================================

# SPS header detection
PATTERN_SPS_HEADER = re.compile(r'^\s*Special Weather Statement', re.MULTILINE | re.IGNORECASE)

# AWIPS identifier extraction
PATTERN_AWIPS_ID = re.compile(r'<valueName>AWIPSidentifier</valueName>\s*<value>(.*?)</value>')

# Alternative AWIPS ID pattern (text format)
PATTERN_AWIPS_ID_TEXT = re.compile(r'^\s*([A-Z]{6})\s*$', re.MULTILINE)

# SPS expiration time pattern
PATTERN_SPS_EXPIRATION = re.compile(r'(?:UNTIL|EXPIRES AT|THROUGH|AFTER|BY)\s+(\d{3,4})\s+(AM|PM)?\s*([A-Z]{3,4})?')

# ==================================================================================
# THREAT TAG PATTERNS
# ==================================================================================

# Tornado detection tag
PATTERN_TORNADO_DETECTION = re.compile(r'<tornadoDetection>([\s\S]*?)</tornadoDetection>')

# Max wind gust (XML format)
PATTERN_WIND_GUST_XML = re.compile(r'<maxWindGust>([\s\S]*?)</maxWindGust>')

# Max wind gust (text format)
PATTERN_WIND_GUST_TEXT = re.compile(r'^MAX WIND GUST\.\.\.(.*)$', re.MULTILINE | re.IGNORECASE)

# Wind hazard in HAZARD line
PATTERN_WIND_HAZARD = re.compile(r'HAZARD\.\.\.([\s\S]*?)(\d+\s*MPH)')

# Max hail size (XML format)
PATTERN_HAIL_SIZE_XML = re.compile(r'<maxHailSize>([\s\S]*?)</maxHailSize>')

# Max hail size (text format)
PATTERN_HAIL_SIZE_TEXT = re.compile(r'^MAX HAIL SIZE\.\.\.(.*)$', re.MULTILINE | re.IGNORECASE)

# Hail hazard in HAZARD line
PATTERN_HAIL_HAZARD = re.compile(
    r'HAZARD\.\.\.([\s\S]*?)(?:AND\s+)?((?:[\d\.]+\s*INCH|GOLF\s*BALL|QUARTER|NICKEL|DIME|PEA)\s*SIZE\s*HAIL)'
)

# ==================================================================================
# STORM MOTION PATTERNS
# ==================================================================================

# Storm motion in XML (e.g., "...230DEG...45KT...")
PATTERN_MOTION_XML = re.compile(
    r'<valueName>eventMotionDescription</valueName>\s*<value>.*?\.\.\.(\d{3})DEG\.\.\.(\d+)KT.*?</value>'
)

# Storm motion in TIME...MOT...LOC line
PATTERN_MOTION_TEXT = re.compile(r'TIME\.\.\.MOT\.\.\.LOC\s+\d+Z\s+(\d{3})DEG\s+(\d+)KT')

# ==================================================================================
# POLYGON PATTERNS
# ==================================================================================

# Polygon in XML format
PATTERN_POLYGON_XML = re.compile(r'<polygon>([\s\S]*?)</polygon>')

# LAT...LON section in text format
PATTERN_POLYGON_TEXT = re.compile(r'LAT\.\.\.LON(.*?)(?:TIME\.\.\.MOT\.\.\.LOC|\$\$)', re.DOTALL)

# Coordinate pairs in LAT...LON section
PATTERN_COORDS = re.compile(r'\d{4,5}')

# ==================================================================================
# AFD (Area Forecast Discussion) PATTERNS
# ==================================================================================

# AFD product identifier (e.g., "AFDCLE")
PATTERN_AFD_ID = re.compile(r'^\s*(AFD[A-Z]{3})\s*$', re.MULTILINE | re.IGNORECASE)

# ==================================================================================
# OFFICE EXTRACTION PATTERNS
# ==================================================================================

# Office code from API URL (e.g., "https://api.weather.gov/offices/CLE")
PATTERN_OFFICE_URL = re.compile(r'/offices/([A-Z]{3})$')

# Office code from sender name
PATTERN_OFFICE_SENDER = re.compile(r'NWS\s+\w+\s+([A-Z]{2})')
