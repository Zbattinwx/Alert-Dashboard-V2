# alert.py
import json
import hashlib
from dataclasses import dataclass, field
from datetime import datetime, timezone

@dataclass
class Alert:
    """A class to hold structured weather alert data."""
    raw_text: str
    id: str = ""
    product_id: str = ""
    issue_time: datetime = None
    issuing_office: str = ""
    vtec_string: str = ""
    phenomenon: str = ""
    significance: str = ""
    event_tracking_number: str = ""
    is_cancellation: bool = False # This will be True for CAN or EXP actions
    is_update: bool = False       # True for CON (continuation) actions
    is_api_source: bool = False   # True if alert came from NWS API, False if from NWWS
    fips_codes: list = field(default_factory=list) # Add this field to store FIPS codes
    expiration_time: datetime = None
    affected_areas: list = field(default_factory=list)
    display_locations: str = "N/A"
    damage_threat: str = "BASE"
    tornado_possible: bool = False
    tornado_observed: bool = False
    is_emergency: bool = False
    polygon: list = field(default_factory=list)
    max_wind_gust: str = None
    max_hail_size: str = None
    snow_amount: str = None  # Snow accumulation (e.g., "4 to 13 inches")
    tornado_detection: str = None
    storm_motion: str = None
    text: str = ""  # Human-readable alert text for display
    is_test: bool = False  # True if this is a test alert injected via test panel

    def __post_init__(self):
        """Generate a unique ID for the alert after it's created."""
        if self.vtec_string:
            # Use the VTEC string for a stable ID across updates
            self.id = hashlib.md5(self.vtec_string.encode()).hexdigest()
        else:
            # Fallback for non-VTEC products
            self.id = hashlib.md5(self.raw_text.encode()).hexdigest()

    @classmethod
    def from_vtec_string(cls, vtec_string):
        """
        Parses a VTEC string to extract the alert's expiration time.
        """
        try:
            # This format is used in follow-up alerts (e.g., -250712T0115Z/)
            expiration_part = vtec_string.split('-')[1]
            expiration_str = expiration_part.strip('/')
            return datetime.strptime(expiration_str, '%y%m%dT%H%MZ').replace(tzinfo=timezone.utc)
        except (IndexError, ValueError):
            return None # Or handle other formats if necessary

    def to_json(self):
        """Converts the alert object to a JSON-serializable dictionary."""
        data = self.__dict__.copy()
        data['issue_time'] = self.issue_time.isoformat() if self.issue_time else None
        data['expiration_time'] = self.expiration_time.isoformat() if self.expiration_time else None
        return data