// snow_widget.js

const SHEET_URL = 'https://script.google.com/macros/s/AKfycbyyy6Pp5cKJqelzOLugwvYPA29aDaYg3S0-EE9aSRP1aSveLeWZZ4CC0vGlq1Gh38ia/exec';
const POLL_INTERVAL = 30000; // Check every 30 seconds
const DISPLAY_DURATION = 8000; // How long to show each alert (8 seconds)

let countyCache = {}; // Stores previous state: { "FIPSCODE": Level }
let isQueueProcessing = false;
let updateQueue = [];

// DOM Elements
const card = document.getElementById('snow-notification');
const levelNumEl = document.getElementById('level-number');
const countyNameEl = document.getElementById('county-name');
const statusTextEl = document.getElementById('status-text');
const levelIndicator = document.getElementById('level-indicator');

// --- Initialization ---
async function init() {
    console.log("❄️ Snow Emergency Widget Started");
    
    // First load: Populate cache but don't alert (avoids spamming on startup)
    await fetchSnowData(true); 
    
    // Start polling
    setInterval(() => fetchSnowData(false), POLL_INTERVAL);
}

// --- Fetch Data from Google Sheet ---
async function fetchSnowData(isFirstLoad) {
    try {
        const response = await fetch(SHEET_URL);
        const data = await response.json();
        
        // data structure is likely: [{ stateFIPS: 39, countyFIPS: 49, level: 1, ... }, ...]
        
        data.forEach(row => {
            // Construct a unique ID (FIPS)
            const fips = String(row.stateFIPS).padStart(2, '0') + String(row.countyFIPS).padStart(3, '0');
            const newLevel = row.level;
            const countyName = row.county || "Unknown County"; // You might need to map FIPS to Names if not in sheet
            
            // Check for changes
            if (countyCache[fips] !== undefined) {
                const oldLevel = countyCache[fips];
                
                // If level changed (and it's not the first load)
                if (!isFirstLoad && oldLevel !== newLevel) {
                    
                    // Only alert if level INCREASES or is significant
                    // You can remove this check if you want alerts for downgrades too
                    if (newLevel > 0 && newLevel !== 5) { 
                        queueUpdate({
                            county: countyName,
                            level: newLevel,
                            oldLevel: oldLevel
                        });
                    }
                }
            }
            
            // Update Cache
            countyCache[fips] = newLevel;
        });
        
    } catch (error) {
        console.error("❌ Error fetching snow data:", error);
    }
}

// --- Queue Management ---
function queueUpdate(data) {
    console.log(`📥 Queuing update: ${data.county} -> Level ${data.level}`);
    updateQueue.push(data);
    processQueue();
}

async function processQueue() {
    if (isQueueProcessing || updateQueue.length === 0) return;
    
    isQueueProcessing = true;
    const currentAlert = updateQueue.shift();
    
    await showAlert(currentAlert);
    
    // Small buffer between alerts
    setTimeout(() => {
        isQueueProcessing = false;
        processQueue();
    }, 1000);
}

// --- Display Logic ---
function showAlert(data) {
    return new Promise(resolve => {
        // 1. Reset Classes
        card.className = "snow-card hidden"; // Remove old level classes
        
        // 2. Set Content
        // If data.county doesn't exist in sheet, we might need a lookup map here
        // Assuming sheet has 'county' field based on your map code, if not, let me know
        countyNameEl.textContent = getCountyName(data.county); 
        
        let levelText = "";
        let levelClass = "";
        let iconContent = data.level;
        
        switch(data.level) {
            case 1:
                levelText = "LEVEL 1 SNOW EMERGENCY";
                levelClass = "level-1";
                break;
            case 2:
                levelText = "LEVEL 2 SNOW EMERGENCY";
                levelClass = "level-2";
                break;
            case 3:
                levelText = "LEVEL 3 SNOW EMERGENCY";
                levelClass = "level-3";
                break;
            case 4:
                levelText = "TRAVEL ADVISORY";
                levelClass = "level-4";
                iconContent = '<i class="fas fa-car-side" style="font-size:24px"></i>';
                break;
            default:
                levelText = "SNOW ALERT";
        }
        
        statusTextEl.textContent = levelText;
        levelNumEl.innerHTML = iconContent;
        card.classList.add(levelClass);
        
        // 3. Play Sound (Optional - create an Audio object if needed)
        // const audio = new Audio('alert.mp3'); audio.play();

        // 4. Animate In
        // Force reflow
        void card.offsetWidth; 
        card.classList.remove("hidden");
        card.classList.add("visible");
        
        // 5. Wait, then Animate Out
        setTimeout(() => {
            card.classList.remove("visible");
            card.classList.add("hidden");
            
            // Wait for CSS transition to finish before resolving
            setTimeout(resolve, 600); 
        }, DISPLAY_DURATION);
    });
}

// Helper: If your sheet data doesn't provide County Names (only FIPS), 
// we assume it provides a 'county' column or we just pass whatever string came in.
function getCountyName(rawName) {
    // If rawName is undefined, it means the sheet didn't have it.
    // In your map code, you loaded a GeoJSON file to get names. 
    // If the sheet only has FIPS, we might need to hardcode a FIPS map here.
    // For now, assume the sheet has a 'county' column or usage passes "County Name"
    return rawName || "Unknown County";
}

// --- TESTING FUNCTION ---
// Type `testAlert(2)` in browser console to test
window.testAlert = function(level) {
    queueUpdate({
        county: "Test County",
        level: level,
        oldLevel: 0
    });
};

// Start
init();