# alert_parser.py
# ==================================================================================
# ALERT PARSER MODULE
# ==================================================================================
# This module handles parsing of weather alerts from multiple sources:
# 1. NWS API (JSON format) - Official API alerts with structured data
# 2. NWWS/Weather Wire (Text format) - Real-time text-based alerts with VTEC
# 3. SPC Watches (Special format) - Storm Prediction Center watch products
#
# The parser extracts critical information like phenomena codes, FIPS codes,
# UGC codes, expiration times, and threat details from each format.
# ==================================================================================

import re
from datetime import datetime, timedelta, timezone
from alert import Alert
import uuid
from ugc_parser import UGC_TO_COUNTY
from constants import NWS_EVENT_TO_PHENOMENON, TIMEZONE_MAP
from logger import get_logger

# Module-level logger
_logger = get_logger()

from patterns import (
    PATTERN_XML_ALERT, PATTERN_XML_EXPIRATION, PATTERN_XML_FIPS, PATTERN_XML_UGC,
    PATTERN_XML_AREA_DESC, PATTERN_VTEC, PATTERN_UGC_LINE, PATTERN_UGC_PREFIX,
    PATTERN_LOCATION_DESC, PATTERN_WATCH_HEADER, PATTERN_WATCH_NUMBER,
    PATTERN_WATCH_EXPIRATION, PATTERN_WATCH_COUNTY_SECTION, PATTERN_COUNTY_NAMES,
    PATTERN_WATCH_UGC, PATTERN_SPS_HEADER, PATTERN_AWIPS_ID, PATTERN_AWIPS_ID_TEXT,
    PATTERN_SPS_EXPIRATION, PATTERN_TORNADO_DETECTION, PATTERN_WIND_GUST_XML,
    PATTERN_WIND_GUST_TEXT, PATTERN_WIND_HAZARD, PATTERN_HAIL_SIZE_XML,
    PATTERN_HAIL_SIZE_TEXT, PATTERN_HAIL_HAZARD, PATTERN_MOTION_XML,
    PATTERN_MOTION_TEXT, PATTERN_POLYGON_XML, PATTERN_POLYGON_TEXT,
    PATTERN_COORDS, PATTERN_AFD_ID, PATTERN_OFFICE_URL, PATTERN_OFFICE_SENDER,
    PATTERN_WATCH_COUNTIES
)

# ==================================================================================
# NWS API ALERT PARSER (JSON FORMAT)
# ==================================================================================
# Parses alerts from the official NWS API which provides structured JSON data.
# API alerts include stable URN identifiers, structured fields, and GeoJSON polygons.
# ==================================================================================
def parse_nws_api_alert(feature_json: dict) -> Alert:
    """
    Parses an alert from NWS API JSON format.

    Args:
        feature_json: Complete GeoJSON feature from NWS API

    Returns:
        Alert object with parsed data or None if invalid
    """
    properties = feature_json.get("properties", {})
    if not properties:
        return None

    # Include NWSheadline parameter for SPS filtering (contains important keywords like "FIRE DANGER")
    nws_headline = properties.get('parameters', {}).get('NWSheadline', [])
    nws_headline_text = nws_headline[0] if nws_headline else ''

    full_text_for_display = f"{nws_headline_text}\n\n{properties.get('headline', '')}\n\n{properties.get('description', '')}\n\n{properties.get('instruction', '')}"

    alert = Alert(raw_text=properties.get("headline", "API Alert"))

    # Extract product ID from VTEC to ensure consistency with NWWS alerts
    # This prevents duplicate alerts when the same alert comes from both API and NWWS
    vtec_list = properties.get('parameters', {}).get('VTEC', [])
    if vtec_list and vtec_list[0]:
        # Parse VTEC string like: /O.CON.KTFX.WW.Y.0044.000000T0000Z-251020T1800Z/
        try:
            vtec = vtec_list[0]
            parts = vtec.strip('/').split('.')
            if len(parts) >= 5:
                # parts: ['O', 'CON', 'KTFX', 'WW', 'Y', '0044', ...]
                phenomenon = parts[3]  # WW
                office = parts[2]       # KTFX
                event_num = parts[5].split('/')[0]  # 0044

                # For watches (significance 'A'), include significance in phenomenon
                if parts[4] == 'A':
                    alert.product_id = f"{phenomenon}A.{office}.{event_num}"
                else:
                    alert.product_id = f"{phenomenon}.{office}.{event_num}"
        except (IndexError, ValueError) as e:
            _logger.debug(f"⚠️ Could not parse VTEC from API alert, using API ID as fallback: {e}")
            alert.product_id = properties.get('id')
    else:
        # For non-VTEC products (like SPS), try to use AWIPS ID for consistency with NWWS
        awips_id_list = properties.get('parameters', {}).get('AWIPSidentifier', [])
        if awips_id_list and awips_id_list[0]:
            alert.product_id = awips_id_list[0].strip()
        else:
            # Fallback to API ID if no AWIPS identifier present
            alert.product_id = properties.get('id')

    alert.is_api_source = True
    alert.phenomenon = NWS_EVENT_TO_PHENOMENON.get(properties.get("event"), "UNKNOWN")

    # Filter out non-thunderstorm SPS alerts
    if alert.phenomenon == "SPS":
        # For API alerts, check the full_text_for_display
        if not is_thunderstorm_related_sps(full_text_for_display):
            _logger.debug("Filtering out non-thunderstorm SPS alert from API")
            return None

    # Extract issuing office code (e.g., "ILN", "CLE") from the API
    office_url = properties.get("office")
    if office_url:
        # Extract office code from URL like "https://api.weather.gov/offices/CLE"
        office_code_match = PATTERN_OFFICE_URL.search(office_url)
        if office_code_match:
            alert.issuing_office = office_code_match.group(1)

    # Fallback: attempt to parse from senderName if office URL not available
    if not alert.issuing_office:
        sender_name = properties.get("senderName", "")
        office_match = PATTERN_OFFICE_SENDER.search(sender_name)
        if office_match:
            _logger.debug(f"⚠️ Could not extract exact office code from API alert, sender: {sender_name}")

    # Parse location, time, and geographic data
    alert.display_locations = properties.get("areaDesc", "Unknown Location")
    alert.issue_time = datetime.fromisoformat(properties.get("sent"))
    alert.expiration_time = datetime.fromisoformat(properties.get("expires"))

    geocode = properties.get("geocode", {})
    alert.affected_areas = geocode.get("UGC", [])  # UGC zone/county codes

    # Convert SAME codes from 6-digit (008093) to standard 5-digit FIPS (08093)
    same_codes = geocode.get("SAME", [])
    alert.fips_codes = [code[-5:].zfill(5) for code in same_codes if code and len(code) >= 5]

    alert.text = full_text_for_display.strip()

    # Extract threat tags from API parameters (wind, hail, motion)
    parameters = properties.get("parameters", {})

    # Max wind gust
    max_wind_gust = parameters.get("maxWindGust", [])
    if max_wind_gust and max_wind_gust[0]:
        alert.max_wind_gust = max_wind_gust[0].strip()

    # Max hail size
    max_hail_size = parameters.get("maxHailSize", [])
    if max_hail_size and max_hail_size[0]:
        hail_val = max_hail_size[0].strip()
        # Format hail size consistently with text alerts (add inch marker if just a number)
        if hail_val and not hail_val.endswith('"') and hail_val.replace('.', '').isdigit():
            alert.max_hail_size = f'{hail_val}"'
        else:
            alert.max_hail_size = hail_val

    # Storm motion from eventMotionDescription
    # Format: "2025-10-22T13:34:00-00:00...storm...156DEG...27KT...35.3,-119.11"
    event_motion = parameters.get("eventMotionDescription", [])
    if event_motion and event_motion[0]:
        motion_str = event_motion[0]
        # Extract degrees and knots using regex
        motion_match = re.search(r'(\d{3})DEG\.\.\.(\d+)KT', motion_str)
        if motion_match:
            try:
                motion_deg = int(motion_match.group(1))
                motion_kt = int(motion_match.group(2))
                alert.storm_motion = get_storm_motion_string(motion_deg, motion_kt)
            except (ValueError, IndexError):
                pass

    # Parse GeoJSON polygon geometry for map rendering
    geometry = feature_json.get("geometry")
    if geometry:
        geom_type = geometry.get("type")
        coordinates = geometry.get("coordinates", [])
        polygon_list = []

        if geom_type == "Polygon":
            outer_ring = coordinates[0]
            swapped_coords = [[lat, lon] for lon, lat in outer_ring]
            polygon_list.append(swapped_coords)

        elif geom_type == "MultiPolygon":
            for polygon_coords in coordinates:
                outer_ring = polygon_coords[0]
                swapped_coords = [[lat, lon] for lon, lat in outer_ring]
                polygon_list.append(swapped_coords)
        
        if polygon_list:
             alert.polygon = polygon_list
    
    return alert
# --- END: New function to parse NWS API JSON ---


def is_thunderstorm_related_sps(alert_text: str) -> bool:
    """
    Determines if a Special Weather Statement is related to thunderstorms.
    Only thunderstorm-related SPS alerts should be shown on the dashboard.

    Args:
        alert_text: The raw alert text

    Returns:
        True if the SPS is about thunderstorms, False otherwise (e.g., fire weather, dense fog, etc.)
    """
    upper_text = alert_text.upper()

    # Keywords that indicate thunderstorm-related SPS
    thunderstorm_keywords = [
        'STRONG THUNDERSTORM',
        'THUNDERSTORMS',
        'THUNDERSTORM',
        'TSTM',
        'TSTMS',
        'LIGHTNING',
        'WIND GUST',
        'GUSTY WIND',
        'GUSTY SHOWERS',
        'STRONG SHOWERS',
        'DOPPLER RADAR',
        'SEVERE WEATHER',
        'DOWNBURST',
        'MICROBURST',
    ]

    # Keywords that indicate non-thunderstorm SPS (should be excluded)
    # Use word boundaries to avoid false matches (e.g., 'ICE' in 'SERVICE')
    excluded_keywords = [
        'FIRE DANGER',
        'FIRE WEATHER',
        'RED FLAG',
        'DENSE FOG',
        'FREEZING FOG',
        'FROST',
        'FREEZE',
        'HEAT',
        'EXCESSIVE HEAT',
        'WIND CHILL',
        'COLD',
        'SNOW',
        r'\bICE\b',  # Word boundary to avoid matching 'SERVICE', 'OFFICE', etc.
        'BLIZZARD',
        'HIGH SURF',
        'RIP CURRENT',
        'COASTAL',
        'BEACH',
    ]

    # First check for excluded keywords - if found, reject immediately
    for keyword in excluded_keywords:
        # Use regex for keywords with word boundaries, simple string search for phrases
        if keyword.startswith(r'\b'):
            if re.search(keyword, upper_text):
                return False
        else:
            if keyword in upper_text:
                return False

    # Then check for thunderstorm keywords - if found, accept
    for keyword in thunderstorm_keywords:
        if keyword in upper_text:
            return True

    # If no keywords matched, default to rejecting (safer to filter out)
    return False


def get_storm_motion_string(degrees, knots):
    """Converts direction in degrees and speed in knots to a formatted string."""
    if degrees is None or knots is None:
        return None

    mph = round(knots * 1.15078)
    destination_degrees = (degrees + 180) % 360
    dirs = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"]
    ix = round(destination_degrees / (360. / len(dirs)))
    direction = dirs[ix % len(dirs)]
    
    return f"{direction} {mph} MPH"

# ==================================================================================
# HELPER FUNCTIONS
# ==================================================================================

def get_location_string(ugc_list):
    """
    Converts UGC codes to human-readable location string.
    Example: ["OHC049", "OHC041"] -> "Franklin, OH and Delaware, OH"
    """
    if not ugc_list:
        return "Unknown Location"
    locations = [UGC_TO_COUNTY.get(code, {'name': code, 'state': ''}) for code in sorted(list(set(ugc_list)))]
    location_strings = sorted(list(set(f"{loc['name']}, {loc['state']}".strip(', ') for loc in locations)))
    if len(location_strings) == 1: return location_strings[0]
    if len(location_strings) == 2: return f"{location_strings[0]} and {location_strings[1]}"
    return ", ".join(location_strings[:-1]) + f", and {location_strings[-1]}"

def parse_ugc_line(ugc_line_text: str) -> list:
    """
    Parses condensed UGC line format into full list of codes.
    Example: "OHC049-041-061-" -> ["OHC049", "OHC041", "OHC061"]
    Handles ranges: "OHZ001>003-" -> ["OHZ001", "OHZ002", "OHZ003"]
    """
    full_codes = []
    cleaned_text = re.sub(r'-\d{6}-?$', '', ugc_line_text).strip('-')
    prefix_match = PATTERN_UGC_PREFIX.match(cleaned_text)
    if not prefix_match: return []
    prefix = prefix_match.group(1)
    number_text = cleaned_text[len(prefix):]
    parts = number_text.split('-')
    for part in parts:
        if not part: continue
        if '>' in part:
            try:
                start, end = map(int, part.split('>'))
                for i in range(start, end + 1):
                    full_codes.append(f"{prefix}{str(i).zfill(3)}")
            except ValueError: continue
        elif part.isdigit():
            full_codes.append(f"{prefix}{part.zfill(3)}")
    return full_codes

# ==================================================================================
# MAIN PARSE FUNCTION - ROUTES TO APPROPRIATE PARSER
# ==================================================================================
def parse_alert(alert_data) -> Alert:
    """
    Main parsing function that routes to the appropriate parser based on input type.

    Args:
        alert_data: Either a dict (NWS API JSON) or str (NWWS text/XML)

    Returns:
        Alert object with parsed data
    """
    # Route to API parser for JSON input
    if isinstance(alert_data, dict):
        return parse_nws_api_alert(alert_data)

    # ==================================================================================
    # NWWS/TEXT ALERT PARSER (VTEC FORMAT)
    # ==================================================================================
    # Handles text-based alerts from Weather Wire (NWWS) including:
    # - Standard VTEC products (Tornado Warnings, Severe Warnings, etc.)
    # - CAP-XML wrapped alerts
    # - SPC Watch products (special format without VTEC)
    # ==================================================================================
    raw_alert_text = alert_data
    alert = Alert(raw_text=raw_alert_text)
    # Set issue_time to now for NWWS alerts (API alerts get it from JSON)
    alert.issue_time = datetime.now(timezone.utc)
    is_xml = bool(PATTERN_XML_ALERT.search(raw_alert_text))
    upper_text = raw_alert_text.upper()

    expires_match = PATTERN_XML_EXPIRATION.search(raw_alert_text)
    if expires_match:
        try:
            alert.expiration_time = datetime.fromisoformat(expires_match.group(1))
        except (ValueError, TypeError):
            pass

    if is_xml:
        fips_codes = PATTERN_XML_FIPS.findall(raw_alert_text)
        if fips_codes:
            # CRITICAL FIX: Extract last 5 digits to get county FIPS (removes leading zero if present)
            # Example: "008093" (6-digit) → "08093" (5-digit state+county)
            alert.fips_codes = [f[-5:].zfill(5) for f in fips_codes]
        ugc_codes = PATTERN_XML_UGC.findall(raw_alert_text)
        if ugc_codes:
            alert.affected_areas = ugc_codes
            alert.display_locations = get_location_string(ugc_codes)
        else:
            area_desc_match = PATTERN_XML_AREA_DESC.search(raw_alert_text)
            if area_desc_match:
                alert.display_locations = area_desc_match.group(1).replace(';', ',').replace('\n', ' ')
    else:
        location_desc_match = PATTERN_LOCATION_DESC.search(raw_alert_text)
        if location_desc_match:
            desc = location_desc_match.group(1).strip()
            desc = desc.split('\n')[0]
            # FIX: Don't use VTEC lines as location descriptions
            if not desc.startswith('/O.'):
                alert.display_locations = desc.strip().rstrip('-').strip()

        ugc_lines = PATTERN_UGC_LINE.findall(raw_alert_text)
        all_ugcs = []
        for line in ugc_lines:
            all_ugcs.extend(parse_ugc_line(line))
        if all_ugcs:
            alert.affected_areas = sorted(list(set(all_ugcs)))
            # FIX: Always use UGC-based location string if we have UGC codes
            # This is more reliable than trying to parse location descriptions
            if not alert.display_locations or alert.display_locations == "N/A":
                alert.display_locations = get_location_string(alert.affected_areas)

        if not alert.display_locations:
            counties_block_match = PATTERN_WATCH_COUNTIES.search(upper_text)
            if counties_block_match:
                alert.display_locations = counties_block_match.group(1).replace('\n', ' ').replace('               ', ', ').strip()

    # Check if this is a watch product before processing VTEC
    is_watch_product = PATTERN_WATCH_HEADER.search(raw_alert_text)

    vtec_match = PATTERN_VTEC.search(raw_alert_text)
    if vtec_match and not is_watch_product:
        full_vtec_string = vtec_match.group(1)
        alert.vtec_string = full_vtec_string
        try:
            vtec_parts = full_vtec_string.strip('/').split('.')
            action, office, phenomenon, significance, event_number = vtec_parts[1:6]

            # DEBUG: Log VTEC action for SV warnings to troubleshoot stats tracking
            if phenomenon.strip() == 'SV':
                print(f"[DEBUG-VTEC] SV warning parsed - Action: {action}, Office: {office}, Event: {event_number}, VTEC: {full_vtec_string}")

            if action in ['CAN', 'EXP']: alert.is_cancellation = True
            elif action == 'CON': alert.is_update = True
            alert.significance = significance.strip()
            alert.issuing_office = office.strip()  # CRITICAL FIX: Extract and store issuing office
            phenomenon_clean = phenomenon.strip()
            significance_clean = significance.strip()
            office_clean = office.strip()
            event_clean = event_number.strip()

            if significance_clean == 'A':
                # Watch product - include office code for consistency with API alerts
                alert.phenomenon = f"{phenomenon_clean}A"
                alert.product_id = f"{phenomenon_clean}A.{office_clean}.{event_clean}"
            else:
                # Warning/Advisory product
                alert.phenomenon = phenomenon_clean
                alert.product_id = f"{phenomenon_clean}.{office_clean}.{event_clean}"
            if not alert.expiration_time:
                alert.expiration_time = Alert.from_vtec_string(full_vtec_string)
        except (IndexError, ValueError): pass
    # Handle SPC Watches (Tornado Watch, Severe Thunderstorm Watch)
    # Note: We check is_watch_product instead of PATTERN_WATCH_HEADER again to be consistent
    if is_watch_product:
        # Determine watch type
        if 'TORNADO WATCH' in upper_text:
            alert.phenomenon = "TOA"
        elif 'SEVERE THUNDERSTORM WATCH' in upper_text:
            alert.phenomenon = "SVA"

        # Extract watch number for product ID
        watch_num_match = PATTERN_WATCH_NUMBER.search(upper_text)
        if watch_num_match:
            alert.product_id = f"WW.SPC.{watch_num_match.group(1)}"

        # Extract expiration time (e.g., "UNTIL 800 PM EDT")
        if not alert.expiration_time:
            expires_match = PATTERN_WATCH_EXPIRATION.search(upper_text)
            if expires_match:
                try:
                    time_str, am_pm, tz_str = expires_match.groups()
                    time_str = time_str.zfill(4)
                    hour, minute = int(time_str[:2]), int(time_str[2:])
                    if am_pm == 'PM' and hour != 12: hour += 12
                    elif am_pm == 'AM' and hour == 12: hour = 0
                    tz_info = TIMEZONE_MAP.get(tz_str, timezone.utc)
                    now_in_tz = datetime.now(tz_info)
                    expire_time = now_in_tz.replace(hour=hour, minute=minute, second=0, microsecond=0)
                    if expire_time < now_in_tz: expire_time += timedelta(days=1)
                    alert.expiration_time = expire_time
                except Exception: pass

        # Extract UGC codes from Watch Outline Update (WOU)
        # WOU sections have UGC codes spread across multiple lines like:
        # LAC003-011-013-015-017-019-021-031-039-043-049-053-059-069-079-
        # 081-085-115-127-290300-
        # We need to find all UGC-style lines and concatenate them by state
        # First, check if this is a WOU (Watch Outline Update) - it has county-level codes
        is_wou = 'WATCH OUTLINE UPDATE' in upper_text or re.search(r'[A-Z]{2}C\d{3}-', upper_text)

        watch_ugc_matches = PATTERN_WATCH_UGC.findall(upper_text)
        all_watch_ugcs = []

        if watch_ugc_matches:
            # Group continuation lines with their parent state lines
            # A continuation line starts with just digits (no state prefix)
            ugc_text = raw_alert_text.upper()
            for ugc_line in watch_ugc_matches:
                # Skip zone-only codes (like LAZ000) if this is a WOU with county codes
                # WOU products have county codes (LAC###), zone-only codes are from SEL products
                if is_wou and re.match(r'^[A-Z]{2}Z\d{3}', ugc_line):
                    continue

                # Find this line and any continuation lines after it
                line_pos = ugc_text.find(ugc_line)
                if line_pos == -1:
                    continue

                # Get the full UGC section by looking at lines after this one
                remaining_text = ugc_text[line_pos:]
                lines = remaining_text.split('\n')

                # First line is the main UGC line (e.g., LAC003-011-)
                combined_ugc = lines[0]

                # Check if next lines are continuations (start with digits)
                for i in range(1, min(len(lines), 5)):  # Check up to 5 lines ahead
                    next_line = lines[i].strip()
                    if re.match(r'^\d{3}-', next_line):
                        # This is a continuation line, add it
                        combined_ugc += next_line
                    else:
                        # Not a continuation, stop
                        break

                # Parse the combined UGC line
                parsed_ugcs = parse_ugc_line(combined_ugc)
                all_watch_ugcs.extend(parsed_ugcs)

        if all_watch_ugcs:
            alert.affected_areas = all_watch_ugcs
            _logger.debug(f"Extracted {len(all_watch_ugcs)} UGC codes from watch")

        # Extract county list for watches (for display purposes)
        county_section = PATTERN_WATCH_COUNTY_SECTION.search(upper_text)
        if county_section:
            counties_text = county_section.group(1)
            # Extract county names (they're in all caps, multiple per line)
            county_names = PATTERN_COUNTY_NAMES.findall(counties_text)
            if county_names:
                # Build display string
                alert.display_locations = ", ".join(county_names[:5])  # Show first 5
                if len(county_names) > 5:
                    alert.display_locations += f" and {len(county_names) - 5} other counties"

        # If we have UGC codes but no display string, generate one
        if not alert.display_locations and all_watch_ugcs:
            alert.display_locations = get_location_string(all_watch_ugcs[:5])

    elif PATTERN_SPS_HEADER.search(raw_alert_text):
        # Filter SPS alerts - only accept thunderstorm-related ones
        if not is_thunderstorm_related_sps(raw_alert_text):
            _logger.debug("Filtering out non-thunderstorm SPS alert")
            return None

        alert.phenomenon = "SPS"
        awips_id_match = PATTERN_AWIPS_ID.search(raw_alert_text) or PATTERN_AWIPS_ID_TEXT.search(raw_alert_text)
        if awips_id_match: alert.product_id = awips_id_match.group(1).strip()
        if not alert.expiration_time:
            expires_match_text = PATTERN_SPS_EXPIRATION.search(upper_text)
            if expires_match_text:
                try:
                    time_str, am_pm, tz_str = expires_match_text.groups()
                    time_str = time_str.zfill(4); hour, minute = int(time_str[:2]), int(time_str[2:])
                    if am_pm == 'PM' and hour != 12: hour += 12
                    elif am_pm == 'AM' and hour == 12: hour = 0
                    tz_info = TIMEZONE_MAP.get(tz_str)
                    now_in_tz = datetime.now(tz_info)
                    expire_time = now_in_tz.replace(hour=hour, minute=minute, second=0, microsecond=0)
                    if expire_time < now_in_tz: expire_time += timedelta(days=1)
                    alert.expiration_time = expire_time
                except Exception: pass
    
    if 'TORNADO...OBSERVED' in upper_text: alert.tornado_observed = True
    if 'TORNADO EMERGENCY' in upper_text or 'FLASH FLOOD EMERGENCY' in upper_text: alert.is_emergency = True
    if 'TORNADO...POSSIBLE' in upper_text: alert.tornado_possible = True
    if 'DAMAGE THREAT...CATASTROPHIC' in upper_text: alert.damage_threat = 'CATASTROPHIC'
    elif any(s in upper_text for s in ['DAMAGE THREAT...DESTRUCTIVE', 'HAIL THREAT...DESTRUCTIVE', 'WIND THREAT...DESTRUCTIVE']): alert.damage_threat = 'DESTRUCTIVE'
    elif 'DAMAGE THREAT...CONSIDERABLE' in upper_text: alert.damage_threat = 'CONSIDERABLE'

    detection_match = PATTERN_TORNADO_DETECTION.search(raw_alert_text)
    if detection_match:
        status = detection_match.group(1).strip().upper()
        alert.tornado_detection = status
        if status == 'OBSERVED': alert.tornado_observed = True

    wind_gust_match = PATTERN_WIND_GUST_XML.search(raw_alert_text) or PATTERN_WIND_GUST_TEXT.search(raw_alert_text)
    if wind_gust_match: alert.max_wind_gust = wind_gust_match.group(1).strip()
    else:
        wind_hazard_match = PATTERN_WIND_HAZARD.search(upper_text)
        if wind_hazard_match: alert.max_wind_gust = wind_hazard_match.group(2)

    hail_size_match = PATTERN_HAIL_SIZE_XML.search(raw_alert_text)
    if hail_size_match: alert.max_hail_size = hail_size_match.group(1).strip().replace("Up to ", "") + '"'
    else:
        hail_size_match = PATTERN_HAIL_SIZE_TEXT.search(raw_alert_text)
        if hail_size_match:
            hail_val = hail_size_match.group(1).strip()
            if "0.00" not in hail_val: alert.max_hail_size = hail_val
        else:
            hail_hazard_match = PATTERN_HAIL_HAZARD.search(upper_text)
            if hail_hazard_match: alert.max_hail_size = hail_hazard_match.group(2).replace(" SIZE HAIL", "").strip()

    motion_deg, motion_kt = None, None
    motion_match_xml = PATTERN_MOTION_XML.search(raw_alert_text)
    if motion_match_xml:
        try: motion_deg, motion_kt = int(motion_match_xml.group(1)), int(motion_match_xml.group(2))
        except (ValueError, IndexError): pass
    else:
        motion_match_text = PATTERN_MOTION_TEXT.search(raw_alert_text)
        if motion_match_text:
            try: motion_deg, motion_kt = int(motion_match_text.group(1)), int(motion_match_text.group(2))
            except (ValueError, IndexError): pass
    if motion_deg is not None and motion_kt is not None: alert.storm_motion = get_storm_motion_string(motion_deg, motion_kt)

    polygon_list = []
    if is_xml:
        poly_matches = PATTERN_POLYGON_XML.findall(raw_alert_text)
        for poly_str in poly_matches:
            current_poly = []
            coords = poly_str.strip().split(' ')
            for pair in coords:
                try: lat, lon = map(float, pair.split(',')); current_poly.append([lat, lon])
                except ValueError: continue
            if current_poly: polygon_list.append(current_poly)
    else:
        section_match = PATTERN_POLYGON_TEXT.search(raw_alert_text)
        if section_match:
            coord_text = section_match.group(1)
            coords = PATTERN_COORDS.findall(coord_text)
            current_poly = []
            if len(coords) % 2 == 0:
                it = iter(coords)
                for lat_str in it:
                    try:
                        lon_str = next(it); lat = float(lat_str) / 100.0; lon = -float(lon_str) / 100.0
                        current_poly.append([lat, lon])
                    except (StopIteration, ValueError): break
            if current_poly: polygon_list.append(current_poly)
    # IMPORTANT: Always store polygons as a list of polygon arrays for consistent frontend rendering
    if polygon_list:
        alert.polygon = polygon_list
        
    if not alert.expiration_time:
        is_targeted_product = alert.phenomenon in {"TO", "SV", "FF", "SS", "SPS", "SVR", "FFW", "TOA", "SVA", "FFA"}
        if is_targeted_product:
            _logger.debug(f"Assigning default 60-min lifetime to {alert.product_id or 'unknown product'}")
            alert.expiration_time = datetime.now(timezone.utc) + timedelta(minutes=60)
    return alert