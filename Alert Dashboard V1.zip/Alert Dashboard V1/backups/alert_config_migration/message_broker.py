# message_broker.py
# ==================================================================================
# MESSAGE BROKER SERVICE
# ==================================================================================
# This service handles all WebSocket communication with connected dashboard clients.
# It manages client connections, broadcasts updates, and routes messages.
# ==================================================================================

import asyncio
import json
from typing import Set, Callable, Optional, Any, List
from datetime import datetime
import websockets


class MessageBroker:
    """
    Manages WebSocket connections and message broadcasting.
    Provides centralized communication with all connected dashboard clients.
    """

    def __init__(self):
        """Initialize the MessageBroker with an empty client set."""
        self.connected_clients: Set = set()

    # ==================================================================================
    # CLIENT MANAGEMENT
    # ==================================================================================

    def add_client(self, websocket) -> int:
        """
        Adds a new client to the connected clients set.

        Args:
            websocket: The WebSocket connection object

        Returns:
            Total number of connected clients after adding
        """
        self.connected_clients.add(websocket)
        print(f"\n💻 New client connected. Total clients: {len(self.connected_clients)}")
        return len(self.connected_clients)

    def remove_client(self, websocket) -> int:
        """
        Removes a client from the connected clients set.

        Args:
            websocket: The WebSocket connection object

        Returns:
            Total number of connected clients after removal
        """
        self.connected_clients.discard(websocket)
        print(f"Client disconnected. Total clients: {len(self.connected_clients)}")
        return len(self.connected_clients)

    def get_client_count(self) -> int:
        """Returns the number of currently connected clients."""
        return len(self.connected_clients)

    def has_clients(self) -> bool:
        """Returns True if there are any connected clients."""
        return len(self.connected_clients) > 0

    # ==================================================================================
    # ALERT SORTING
    # ==================================================================================

    def _sort_alerts(self, alerts_list: List[dict]) -> List[dict]:
        """
        Sorts alerts by priority (tornado warnings first, etc.) and then by issue time
        (newest first) within each priority group.

        Args:
            alerts_list: List of alert dictionaries

        Returns:
            Sorted list of alerts
        """
        # Import ALERT_PRIORITY here to avoid circular imports
        from constants import ALERT_PRIORITY

        def sort_key(alert):
            phenomenon = alert.get('phenomenon', 'UNKNOWN')
            priority = ALERT_PRIORITY.get(phenomenon, 99)  # Unknown alerts go to end

            # Parse issue_time and convert to sortable value (negative timestamp for newest first)
            issue_time_str = alert.get('issue_time')
            if issue_time_str:
                try:
                    issue_time = datetime.fromisoformat(issue_time_str)
                    # Negative timestamp so newest comes first within each priority
                    time_sort = -issue_time.timestamp()
                except (ValueError, AttributeError):
                    time_sort = 0  # If parsing fails, put at end of priority group
            else:
                time_sort = 0

            # Return tuple: (priority, time_sort)
            # Lower priority numbers come first, then newer times within each priority
            return (priority, time_sort)

        return sorted(alerts_list, key=sort_key)

    # ==================================================================================
    # BROADCAST OPERATIONS
    # ==================================================================================

    async def broadcast_message(self, message: str) -> None:
        """
        Broadcasts a raw message string to all connected clients.

        Args:
            message: The message string to broadcast (typically JSON)
        """
        if not self.connected_clients:
            return

        # Use asyncio.gather to send messages to all clients concurrently
        await asyncio.gather(
            *[client.send(message) for client in self.connected_clients],
            return_exceptions=True
        )

    async def broadcast_json(self, data: dict) -> None:
        """
        Broadcasts a dictionary as JSON to all connected clients.

        Args:
            data: Dictionary to serialize and broadcast
        """
        message = json.dumps(data, indent=2)
        await self.broadcast_message(message)

    async def broadcast_update(
        self,
        alert_manager,
        config: dict,
        latest_storm_threats: list,
        create_statewide_summary_func: Callable,
        earthquake_data: Optional[dict] = None
    ) -> None:
        """
        Broadcasts a complete state update to all connected clients.
        This is the main update message containing all dashboard data.

        Args:
            alert_manager: AlertManager instance with current alert state
            config: Configuration dictionary
            latest_storm_threats: List of storm threat data
            create_statewide_summary_func: Function to create statewide summary
            earthquake_data: Optional earthquake data dictionary
        """
        if not self.connected_clients:
            return

        # Prepare alert data and sort by priority then issue time
        alerts_list = [alert.to_json() for alert in alert_manager.active_alerts.values()]
        alerts_list = self._sort_alerts(alerts_list)
        statewide_summary = create_statewide_summary_func(alerts_list)

        # Build complete update message
        message_data = {
            "type": "update",
            "source": config.get("alert_source", "nwws"),
            "alerts": alerts_list,
            "recent_products": list(alert_manager.recent_products),
            "manual_lsrs": alert_manager.manual_lsrs,
            "ticker_rotation_speed_ms": config.get("ticker_rotation_speed_ms", 10000),
            "ticker_no_alerts_message": config.get("ticker_no_alerts_message", "No Active Alerts"),
            "ticker_theme": config.get("ticker_theme", "classic"),
            "dashboard_password": config.get("dashboard_password"),
            "ticker_sponsor": config.get("ticker_sponsor"),
            "afds": alert_manager.latest_afds,
            "ticker_suppress_sps_on_outbreak": config.get("ticker_suppress_sps_on_outbreak", False),
            "statewide_summary": statewide_summary,
            "storm_threat_data": latest_storm_threats,
            "earthquakes": earthquake_data if earthquake_data else {"earthquakes": [], "count": 0}
        }

        await self.broadcast_json(message_data)

    # ==================================================================================
    # SPECIALIZED BROADCAST MESSAGES
    # ==================================================================================

    async def broadcast_new_alert(self, alert) -> None:
        """
        Broadcasts a new alert notification (triggers chime).

        Args:
            alert: Alert object to broadcast
        """
        message_data = {
            "type": "new_alert",
            "alert_data": alert.to_json()
        }
        await self.broadcast_json(message_data)

    async def broadcast_feature_alert(self, alert_data: dict) -> None:
        """
        Broadcasts a featured alert message.

        Args:
            alert_data: Alert data dictionary
        """
        message_data = {
            "type": "feature_alert",
            "alert_data": alert_data
        }
        await self.broadcast_json(message_data)

    async def broadcast_feature_camera(self, camera_data: dict) -> None:
        """
        Broadcasts a featured camera message.

        Args:
            camera_data: Camera data dictionary
        """
        message_data = {
            "type": "feature_camera",
            "camera_data": camera_data
        }
        await self.broadcast_json(message_data)

    async def broadcast_hide_camera(self) -> None:
        """Broadcasts a message to hide the camera widget."""
        message_data = {"type": "hide_camera_widget"}
        await self.broadcast_json(message_data)

    async def broadcast_ticker_settings(self, settings: dict) -> None:
        """
        Broadcasts ticker settings update to all clients.

        Args:
            settings: Ticker settings dictionary
        """
        message_data = {
            "type": "ticker_settings_update",
            "settings": settings
        }
        await self.broadcast_json(message_data)

    async def broadcast_lower_third_show(self) -> None:
        """Broadcasts a message to show the lower third."""
        message_data = {"type": "show_lower_third"}
        await self.broadcast_json(message_data)

    async def broadcast_lower_third_hide(self) -> None:
        """Broadcasts a message to hide the lower third."""
        message_data = {"type": "hide_lower_third"}
        await self.broadcast_json(message_data)

    async def broadcast_chat_message(self, author: str, text: str) -> None:
        """
        Broadcasts a Google Chat message to all clients.

        Args:
            author: Message author name
            text: Message text content
        """
        message_data = {
            "type": "chat_message",
            "author": author,
            "text": text
        }
        await self.broadcast_json(message_data)

    # ==================================================================================
    # UTILITY METHODS
    # ==================================================================================

    def clear_all_clients(self) -> int:
        """
        Disconnects all clients (for shutdown).

        Returns:
            Number of clients that were connected
        """
        count = len(self.connected_clients)
        self.connected_clients.clear()
        return count

    def get_stats(self) -> dict:
        """Returns statistics about connected clients."""
        return {
            "connected_clients": len(self.connected_clients),
            "has_clients": len(self.connected_clients) > 0
        }
