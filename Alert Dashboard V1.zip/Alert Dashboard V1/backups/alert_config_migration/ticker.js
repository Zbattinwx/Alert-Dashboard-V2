document.addEventListener('DOMContentLoaded', () => {
    const WEBSOCKET_URL = CONFIG.websocket_url;
    const tickerContainer = document.getElementById('alert-ticker');

    // --- State Management ---
    let allActiveAlerts = [];
    let activeAlerts = [];
    let currentAlertIndex = 0;
    let rotationSpeed = 10000;
    let alertTimeoutId;
    let noAlertsMessage = 'No Active Alerts';
    let suppressSps = false;
    let lastAlertsJSON = null; // ADD THIS LINE to track changes
    let currentTheme = 'classic'; // Track current theme

    let tickerFilters = {
        states: [],
        phenomena: []
    };

    // --- Theme Management ---
    function applyTheme(themeName) {
        if (!themeName || themeName === currentTheme) return;

        const themes = ['classic', 'atmospheric', 'storm-chaser', 'meteorologist', 'winter'];
        const body = document.body;
        const html = document.documentElement;

        // Remove all theme classes from body and html
        themes.forEach(theme => {
            body.classList.remove(`ticker-theme-${theme}`);
            html.classList.remove(`ticker-theme-${theme}`);
        });

        // Add new theme class
        body.classList.add(`ticker-theme-${themeName}`);
        html.classList.add(`ticker-theme-${themeName}`);

        // Enable/disable theme stylesheets
        themes.forEach(theme => {
            const linkElement = document.getElementById(`ticker-theme-${theme}`);
            if (linkElement) {
                linkElement.disabled = (theme !== themeName);
            }
        });

        currentTheme = themeName;
        console.log(`🎨 Ticker theme applied: ${themeName}`);
    }

    // Alert type and state maps are now in widget-common.js

    function connect() {
        const socket = new WebSocket(WEBSOCKET_URL);
        socket.onopen = () => console.log("Alert Ticker connected.");
        socket.onclose = () => {
            clearTimeout(alertTimeoutId);
            setTimeout(connect, 5000);
        };
        socket.onmessage = (event) => {
            const data = JSON.parse(event.data);
            if (data.type === 'update') {
                const newAlertsJSON = JSON.stringify(data.alerts || []);

                // If alert data hasn't changed, do nothing to prevent interrupting the scroll.
                if (lastAlertsJSON !== null && newAlertsJSON === lastAlertsJSON) {
                    return;
                }

                // If data IS new, store it and update the ticker.
                lastAlertsJSON = newAlertsJSON;

                allActiveAlerts = data.alerts;
                rotationSpeed = data.ticker_rotation_speed_ms || 10000;
                noAlertsMessage = data.ticker_no_alerts_message || 'No Active Alerts';
                suppressSps = data.ticker_suppress_sps_on_outbreak || false;

                // Apply theme if received
                if (data.ticker_theme) {
                    applyTheme(data.ticker_theme);
                }

                applyFilters();

            } else if (data.type === 'ticker_settings_update') {
                console.log('Received new ticker settings:', data.settings);
                tickerFilters = data.settings;

                // Apply theme if included in settings update
                if (data.settings && data.settings.theme) {
                    applyTheme(data.settings.theme);
                }

                applyFilters();
            }
        }
    };

    function applyFilters() {
        let filtered = allActiveAlerts;

        const severeWarningCount = allActiveAlerts.filter(alert => alert.phenomenon !== 'SPS').length;
        if (suppressSps && severeWarningCount >= 3) {
            filtered = allActiveAlerts.filter(alert => alert.phenomenon !== 'SPS');
        }

        if (tickerFilters.states && tickerFilters.states.length > 0) {
            filtered = filtered.filter(alert => {
                if (!alert.affected_areas || alert.affected_areas.length === 0) return false;
                return alert.affected_areas.some(area => tickerFilters.states.includes(area.substring(0, 2)));
            });
        }

        if (tickerFilters.phenomena && tickerFilters.phenomena.length > 0) {
            filtered = filtered.filter(alert => tickerFilters.phenomena.includes(alert.phenomenon));
        }

        activeAlerts = filtered;

        clearTimeout(alertTimeoutId);
        currentAlertIndex = 0;
        rotateAlerts();
    }

    // Using shared getAlertDisplayInfo from widget-common.js

    function rotateAlerts() {
        clearTimeout(alertTimeoutId);
        const locationsContainer = document.getElementById('ticker-locations');
        const locationsSpan = locationsContainer.querySelector('span');

        if (activeAlerts.length === 0) {
            tickerContainer.classList.add('no-alerts-active');
            document.getElementById('ticker-title').textContent = "";
            document.getElementById('ticker-state').textContent = "";
            document.getElementById('ticker-expires-time').textContent = "";
            locationsContainer.classList.remove('scrolling');
            locationsSpan.style.animationDuration = '';
            locationsSpan.textContent = noAlertsMessage;

            setTimeout(() => {
                const containerWidth = locationsContainer.clientWidth;
                const textWidth = locationsSpan.scrollWidth;
                if (textWidth > containerWidth) {
                    locationsContainer.classList.add("scrolling");
                    const durationInSeconds = textWidth / 75;
                    locationsSpan.style.animationDuration = `${durationInSeconds}s`;
                }
            }, 100);
            return;
        }

        tickerContainer.classList.remove('no-alerts-active');
        
        if (currentAlertIndex >= activeAlerts.length) {
            currentAlertIndex = 0;
        }

        const alert = activeAlerts[currentAlertIndex];
        const alertInfo = getAlertDisplayInfo(alert);

        locationsContainer.classList.remove('scrolling');
        locationsSpan.style.animationDuration = '';

        document.querySelector('.ticker-icon i').className = `fas ${alertInfo.icon}`;
        document.getElementById('ticker-title').textContent = alertInfo.name;
        document.getElementById('ticker-state').textContent = alertInfo.stateName || '';
        document.getElementById('ticker-expires-time').textContent = formatExpirationTime(alert.expiration_time);
        locationsSpan.textContent = alert.display_locations;
        tickerContainer.className = `ticker-container ${alert.phenomenon}`;

        let displayTime = rotationSpeed;
        setTimeout(() => {
            const containerWidth = locationsContainer.clientWidth;
            const textWidth = locationsSpan.scrollWidth;
            if (textWidth > containerWidth) {
                const durationInSeconds = textWidth / 60;
                displayTime = (durationInSeconds * 1000) + 1500;
                locationsSpan.style.animationDuration = `${durationInSeconds}s`;
                locationsContainer.classList.add('scrolling');
            }
            
            currentAlertIndex++;
            alertTimeoutId = setTimeout(rotateAlerts, displayTime);
        }, 100);
    }

    connect();
});