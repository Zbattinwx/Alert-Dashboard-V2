// ==================================================================================
// DAILY RECAP FUNCTIONALITY
// ==================================================================================

let currentRecapDate = null;

// Initialize Daily Recap when DOM is loaded
function initDailyRecap() {
  // Populate date selector with last 7 days
  populateRecapDateSelector();

  // Populate monthly selector with last 12 months
  populateMonthlySelector();

  // Event listener for date change
  const dateSelector = document.getElementById('recap-date-selector');
  if (dateSelector) {
    dateSelector.addEventListener('change', () => {
      const selectedDate = dateSelector.value;
      loadDailyRecap(selectedDate);
    });
  }

  // Refresh button
  const refreshBtn = document.getElementById('refresh-recap-btn');
  if (refreshBtn) {
    refreshBtn.addEventListener('click', () => {
      const selectedDate = document.getElementById('recap-date-selector').value;
      loadDailyRecap(selectedDate);
    });
  }

  // Monthly stats button
  const monthlyBtn = document.getElementById('view-monthly-stats-btn');
  if (monthlyBtn) {
    monthlyBtn.addEventListener('click', () => {
      showMonthlyStatsModal();
    });
  }

  // Close monthly modal
  const modalOverlay = document.getElementById('monthly-summary-modal');
  if (modalOverlay) {
    const closeBtn = modalOverlay.querySelector('.modal-close');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => {
        modalOverlay.style.display = 'none';
      });
    }
    modalOverlay.addEventListener('click', (e) => {
      if (e.target === modalOverlay) {
        modalOverlay.style.display = 'none';
      }
    });
  }

  // Monthly month selector change
  const monthSelector = document.getElementById('monthly-month-selector');
  if (monthSelector) {
    monthSelector.addEventListener('change', () => {
      loadMonthlySummary(monthSelector.value);
    });
  }

  // Listen for section changes to load recap when opened
  document.addEventListener('click', (e) => {
    const menuItem = e.target.closest('[data-section="daily-recap-section"]');
    if (menuItem) {
      // Load yesterday's data by default when section is opened
      setTimeout(() => {
        const dateSelector = document.getElementById('recap-date-selector');
        if (dateSelector && dateSelector.value) {
          loadDailyRecap(dateSelector.value);
        }
      }, 100);
    }
  });
}

// Populate date selector dropdown
function populateRecapDateSelector() {
  const selector = document.getElementById('recap-date-selector');
  if (!selector) return;

  selector.innerHTML = '';

  // Add yesterday and last 7 days
  for (let i = 1; i <= 7; i++) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    const dateStr = date.toISOString().split('T')[0];
    const displayName = i === 1 ? 'Yesterday' : formatDateDisplay(dateStr);

    const option = document.createElement('option');
    option.value = dateStr;
    option.textContent = displayName;
    selector.appendChild(option);
  }
}

// Populate monthly selector
function populateMonthlySelector() {
  const selector = document.getElementById('monthly-month-selector');
  if (!selector) return;

  selector.innerHTML = '';

  // Add last 12 months
  for (let i = 0; i < 12; i++) {
    const date = new Date();
    date.setMonth(date.getMonth() - i);
    const monthStr = date.toISOString().slice(0, 7); // YYYY-MM

    const option = document.createElement('option');
    option.value = monthStr;
    option.textContent = date.toLocaleDateString('en-US', { year: 'numeric', month: 'long' });
    selector.appendChild(option);
  }
}

// Load daily recap summary
function loadDailyRecap(date, retryCount = 0) {
  // Access socket from window or global scope
  const socket = window.socket;

  if (!socket || socket.readyState !== WebSocket.OPEN) {
    console.log('Cannot load recap: WebSocket not connected.');

    // Show loading while waiting for connection (up to 5 retries)
    if (retryCount < 5) {
      document.getElementById('recap-loading').style.display = 'block';
      document.getElementById('recap-no-data').style.display = 'none';
      document.getElementById('recap-summary-container').style.display = 'none';

      // Retry after a short delay
      setTimeout(() => loadDailyRecap(date, retryCount + 1), 1000);
    } else {
      // After 5 retries, show error
      document.getElementById('recap-loading').style.display = 'none';
      document.getElementById('recap-no-data').style.display = 'block';
      document.getElementById('recap-no-data').innerHTML = '<i class="fas fa-exclamation-circle"></i><p>Unable to connect to server. Please refresh the page.</p>';
    }
    return;
  }

  currentRecapDate = date;

  // Show loading state
  document.getElementById('recap-loading').style.display = 'block';
  document.getElementById('recap-no-data').style.display = 'none';
  document.getElementById('recap-summary-container').style.display = 'none';

  // Request summary from backend
  socket.send(JSON.stringify({
    type: 'get_previous_day_summary',
    date: date
  }));
}

// Handle incoming daily summary data
function handleDailySummary(data) {
  document.getElementById('recap-loading').style.display = 'none';

  // If no data, create an empty summary structure
  if (!data || data.error) {
    // Extract date from current selection or use "yesterday"
    const selector = document.getElementById('recap-date-selector');
    const selectedDate = selector ? selector.value : 'yesterday';

    // Create empty data structure
    data = {
      date: selectedDate === 'yesterday' ? getYesterdayDate() : selectedDate,
      day_of_week: getDayOfWeek(selectedDate === 'yesterday' ? getYesterdayDate() : selectedDate),
      alerts_issued: {},
      storm_reports: {},
      notable_events: {
        tornado_warnings_observed: [],
        significant_wind_events: []
      },
      totals: {
        total_alerts: 0,
        total_reports: 0,
        tornado_warnings_observed: 0,
        significant_wind_events: 0
      }
    };
  }

  document.getElementById('recap-no-data').style.display = 'none';
  document.getElementById('recap-summary-container').style.display = 'block';

  // Update date display
  const dateDisplay = document.getElementById('recap-date-display');
  dateDisplay.textContent = `${formatDateDisplay(data.date)} (${data.day_of_week})`;

  // Render alerts issued
  renderRecapAlerts(data.alerts_issued, data.totals.total_alerts);

  // Render storm reports
  renderRecapReports(data.storm_reports, data.totals.total_reports);

  // Render notable events
  renderRecapNotableEvents(data.notable_events);
}

// Render alerts issued grid
function renderRecapAlerts(alerts, total) {
  const grid = document.getElementById('recap-alerts-grid');
  const totalSpan = document.getElementById('recap-total-alerts');

  grid.innerHTML = '';
  totalSpan.textContent = total || 0;

  const alertTypes = {
    'TO': { name: 'Tornado Warnings', icon: 'fa-tornado', color: '#e53e3e' },
    'SV': { name: 'Severe T-Storm Warnings', icon: 'fa-bolt', color: '#dd6b20' },
    'FF': { name: 'Flash Flood Warnings', icon: 'fa-water', color: '#38a169' },
    'SPS': { name: 'Special Weather Statements', icon: 'fa-exclamation', color: '#4299e1' },
    'TOA': { name: 'Tornado Watches', icon: 'fa-eye', color: '#f6ad55' },
    'SVA': { name: 'Severe T-Storm Watches', icon: 'fa-cloud-bolt', color: '#fbb811' },
    'WSW': { name: 'Winter Storm Warnings', icon: 'fa-snowflake', color: '#d946ef' },
    'WW': { name: 'Winter Weather Advisories', icon: 'fa-cloud-snow', color: '#9333ea' }
  };

  if (Object.keys(alerts).length === 0) {
    grid.innerHTML = '<div class="recap-empty-message">No alerts were issued</div>';
    return;
  }

  // Sort by count descending
  const sortedAlerts = Object.entries(alerts).sort((a, b) => b[1] - a[1]);

  sortedAlerts.forEach(([type, count]) => {
    const info = alertTypes[type] || { name: type, icon: 'fa-exclamation-triangle', color: '#718096' };

    const item = document.createElement('div');
    item.className = 'recap-grid-item';
    item.innerHTML = `
      <div class="recap-item-label">
        <i class="fas ${info.icon}" style="color: ${info.color}"></i>
        ${info.name}
      </div>
      <div class="recap-item-value">${count}</div>
    `;
    grid.appendChild(item);
  });
}

// Render storm reports grid
function renderRecapReports(reports, total) {
  const grid = document.getElementById('recap-reports-grid');
  const totalSpan = document.getElementById('recap-total-reports');

  grid.innerHTML = '';
  totalSpan.textContent = total || 0;

  const reportTypes = {
    'tornado': { name: 'Tornado Reports', icon: 'fa-tornado', color: '#e53e3e' },
    'wind': { name: 'Wind Reports', icon: 'fa-wind', color: '#dd6b20' },
    'hail': { name: 'Hail Reports', icon: 'fa-cloud-hail', color: '#38a169' },
    'flood': { name: 'Flood Reports', icon: 'fa-water', color: '#4299e1' },
    'snow': { name: 'Snow Reports', icon: 'fa-snowflake', color: '#d946ef' },
    'marine': { name: 'Marine Reports', icon: 'fa-ship', color: '#718096' }
  };

  if (Object.keys(reports).length === 0) {
    grid.innerHTML = '<div class="recap-empty-message">No storm reports were received</div>';
    return;
  }

  // Sort by count descending
  const sortedReports = Object.entries(reports).sort((a, b) => b[1] - a[1]);

  sortedReports.forEach(([type, count]) => {
    const info = reportTypes[type] || {
      name: type.charAt(0).toUpperCase() + type.slice(1) + ' Reports',
      icon: 'fa-bullhorn',
      color: '#718096'
    };

    const item = document.createElement('div');
    item.className = 'recap-grid-item';
    item.innerHTML = `
      <div class="recap-item-label">
        <i class="fas ${info.icon}" style="color: ${info.color}"></i>
        ${info.name}
      </div>
      <div class="recap-item-value">${count}</div>
    `;
    grid.appendChild(item);
  });
}

// Render notable events
function renderRecapNotableEvents(events) {
  const container = document.getElementById('recap-notable-events');
  container.innerHTML = '';

  const tornadoObserved = events.tornado_warnings_observed || [];
  const windEvents = events.significant_wind_events || [];

  let hasContent = false;

  // Tornado warnings with OBSERVED tag
  if (tornadoObserved.length > 0) {
    hasContent = true;
    const section = document.createElement('div');
    section.className = 'recap-notable-section';
    section.innerHTML = `
      <h4><i class="fas fa-tornado"></i> Tornado Warnings with OBSERVED Tag (${tornadoObserved.length})</h4>
      <ul class="recap-notable-list"></ul>
    `;

    const list = section.querySelector('.recap-notable-list');
    tornadoObserved.forEach(event => {
      const li = document.createElement('li');
      li.className = 'recap-notable-item tornado-observed';
      li.innerHTML = `
        <strong>${event.location}</strong>
        <span class="time">${formatTimeDisplay(event.time)}</span>
        <br><small>${event.product_id} - ${event.issuing_office}</small>
      `;
      list.appendChild(li);
    });

    container.appendChild(section);
  }

  // Significant wind events
  if (windEvents.length > 0) {
    hasContent = true;
    const section = document.createElement('div');
    section.className = 'recap-notable-section';
    section.innerHTML = `
      <h4><i class="fas fa-wind"></i> Significant Wind Events (>= 50 MPH or High Threat) - ${windEvents.length} total</h4>
      <ul class="recap-notable-list"></ul>
    `;

    const list = section.querySelector('.recap-notable-list');
    // Show top 15
    windEvents.slice(0, 15).forEach(event => {
      const li = document.createElement('li');
      li.className = 'recap-notable-item high-wind';

      const sourceBadge = event.source === 'lsr' ? 'LSR' : 'Alert';
      const sourceBadgeClass = event.source === 'lsr' ? 'lsr' : 'alert';

      li.innerHTML = `
        <strong>${event.location}</strong>: ${event.value}
        <span class="time">${formatTimeDisplay(event.time)}</span>
        <span class="source-badge ${sourceBadgeClass}">${sourceBadge}</span>
        ${event.product_id ? `<br><small>${event.product_id}</small>` : ''}
      `;
      list.appendChild(li);
    });

    if (windEvents.length > 15) {
      const moreItem = document.createElement('li');
      moreItem.className = 'recap-notable-item';
      moreItem.style.textAlign = 'center';
      moreItem.style.fontStyle = 'italic';
      moreItem.innerHTML = `<span>... and ${windEvents.length - 15} more</span>`;
      list.appendChild(moreItem);
    }

    container.appendChild(section);
  }

  if (!hasContent) {
    container.innerHTML = '<div class="recap-empty-message">No notable events were recorded</div>';
  }
}

// Show monthly stats modal
function showMonthlyStatsModal() {
  const modal = document.getElementById('monthly-summary-modal');
  modal.style.display = 'flex';

  // Load current month by default
  const monthSelector = document.getElementById('monthly-month-selector');
  loadMonthlySummary(monthSelector.value);
}

// Load monthly summary
function loadMonthlySummary(month) {
  const socket = window.socket;

  if (!socket || socket.readyState !== WebSocket.OPEN) {
    console.log('Cannot load monthly summary: WebSocket not connected');
    const container = document.getElementById('monthly-summary-content');
    container.innerHTML = '<div class="recap-empty-message">Unable to connect to server. Please try again.</div>';
    return;
  }

  socket.send(JSON.stringify({
    type: 'get_monthly_summary',
    month: month
  }));
}

// Handle incoming monthly summary data
function handleMonthlySummary(data) {
  const container = document.getElementById('monthly-summary-content');

  if (!data || data.error) {
    container.innerHTML = '<div class="recap-empty-message">No data available for this month</div>';
    return;
  }

  container.innerHTML = `
    <h4>${data.month_name}</h4>
    <div class="monthly-stats-grid">
      <div class="monthly-stat-card">
        <div class="monthly-stat-label">Total Alerts</div>
        <div class="monthly-stat-value">${data.totals.total_alerts || 0}</div>
      </div>
      <div class="monthly-stat-card">
        <div class="monthly-stat-label">Total Reports</div>
        <div class="monthly-stat-value">${data.totals.total_reports || 0}</div>
      </div>
      <div class="monthly-stat-card ${data.totals.busiest_day ? 'busiest-day-highlight' : ''}">
        <div class="monthly-stat-label">Busiest Day</div>
        <div class="monthly-stat-value" style="font-size: 1.2em;">
          ${data.totals.busiest_day ? formatDateDisplay(data.totals.busiest_day) : 'N/A'}
        </div>
        ${data.totals.busiest_day_alerts ? `<small>(${data.totals.busiest_day_alerts} alerts)</small>` : ''}
      </div>
      <div class="monthly-stat-card">
        <div class="monthly-stat-label">Tornado Warnings<br>with OBSERVED</div>
        <div class="monthly-stat-value">${data.totals.tornado_warnings_observed || 0}</div>
      </div>
      <div class="monthly-stat-card">
        <div class="monthly-stat-label">Significant Wind Events</div>
        <div class="monthly-stat-value">${data.totals.significant_wind_events || 0}</div>
      </div>
    </div>
  `;
}

// Helper: Format date for display
function formatDateDisplay(dateStr) {
  try {
    const date = new Date(dateStr + 'T00:00:00');
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  } catch {
    return dateStr;
  }
}

// Helper: Format time for display
function formatTimeDisplay(isoTime) {
  try {
    const date = new Date(isoTime);
    return date.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  } catch {
    return isoTime;
  }
}

// Helper: Get yesterday's date in YYYY-MM-DD format
function getYesterdayDate() {
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  return yesterday.toISOString().split('T')[0];
}

// Helper: Get day of week from date string
function getDayOfWeek(dateStr) {
  try {
    const date = new Date(dateStr + 'T00:00:00');
    return date.toLocaleDateString('en-US', { weekday: 'long' });
  } catch {
    return 'Unknown';
  }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initDailyRecap);
} else {
  initDailyRecap();
}
