# config_manager.py
# ==================================================================================
# CONFIGURATION MANAGEMENT MODULE
# ==================================================================================
# This module provides centralized access to configuration settings.
# It wraps the config.json file and provides type-safe access methods.
# Future enhancement: Add validation, environment variable support, and reloading.
# ==================================================================================

import json
import sys
from typing import Any, Optional


class ConfigManager:
    """
    Manages application configuration loaded from config.json.
    Provides type-safe access to configuration values with defaults.
    """

    def __init__(self, config_path: str = 'config.json'):
        """
        Initializes the ConfigManager and loads configuration from file.

        Args:
            config_path: Path to the configuration JSON file

        Raises:
            SystemExit: If config file is not found
        """
        self.config_path = config_path
        self._config = {}
        self.load()

    def load(self) -> None:
        """Loads configuration from the JSON file."""
        try:
            with open(self.config_path, 'r') as f:
                self._config = json.load(f)
        except FileNotFoundError:
            sys.exit(f"FATAL: {self.config_path} not found!")
        except json.JSONDecodeError as e:
            sys.exit(f"FATAL: Invalid JSON in {self.config_path}: {e}")

    def reload(self) -> bool:
        """
        Reloads configuration from file.
        Returns True if config changed, False otherwise.
        """
        try:
            with open(self.config_path, 'r') as f:
                new_config = json.load(f)

            # Check if config actually changed
            if new_config != self._config:
                self._config = new_config
                return True
            return False
        except (FileNotFoundError, json.JSONDecodeError) as e:
            print(f"⚠️ Error reloading config: {e}. Keeping previous configuration.")
            return False

    def get(self, key: str, default: Any = None) -> Any:
        """
        Gets a configuration value by key.

        Args:
            key: The configuration key
            default: Default value if key doesn't exist

        Returns:
            The configuration value or default
        """
        return self._config.get(key, default)

    def get_nested(self, *keys: str, default: Any = None) -> Any:
        """
        Gets a nested configuration value.

        Example:
            config.get_nested('nwws_credentials', 'username')

        Args:
            *keys: Sequence of keys to navigate nested dict
            default: Default value if path doesn't exist

        Returns:
            The nested value or default
        """
        value = self._config
        for key in keys:
            if isinstance(value, dict):
                value = value.get(key)
                if value is None:
                    return default
            else:
                return default
        return value

    def as_dict(self) -> dict:
        """Returns the entire configuration as a dictionary."""
        return self._config.copy()

    def __getitem__(self, key: str) -> Any:
        """Allows dict-style access: config['key']"""
        return self._config[key]

    def __contains__(self, key: str) -> bool:
        """Allows 'in' operator: 'key' in config"""
        return key in self._config

    # ==================================================================================
    # CONVENIENCE METHODS FOR COMMON CONFIG VALUES
    # ==================================================================================

    @property
    def alert_source(self) -> str:
        """Returns the alert source (nwws or nws_api)."""
        return self.get("alert_source", "nwws")

    @property
    def nwws_username(self) -> Optional[str]:
        """Returns NWWS username from credentials."""
        return self.get_nested("nwws_credentials", "username")

    @property
    def nwws_password(self) -> Optional[str]:
        """Returns NWWS password from credentials."""
        return self.get_nested("nwws_credentials", "password")

    @property
    def filters(self) -> dict:
        """Returns alert filters configuration."""
        return self.get("filters", {})

    @property
    def ticker_rotation_speed_ms(self) -> int:
        """Returns ticker rotation speed in milliseconds."""
        return self.get("ticker_rotation_speed_ms", 10000)

    @property
    def ticker_no_alerts_message(self) -> str:
        """Returns the message to display when no alerts are active."""
        return self.get("ticker_no_alerts_message", "No Active Alerts")

    @property
    def dashboard_password(self) -> Optional[str]:
        """Returns the dashboard password."""
        return self.get("dashboard_password")

    @property
    def restart_interval_hours(self) -> int:
        """Returns the scheduled restart interval in hours."""
        return self.get("restart_interval_hours", 24)

    @property
    def send_google_chat_alerts(self) -> bool:
        """Returns whether Google Chat alerts are enabled."""
        return self.get("send_google_chat_alerts", False)

    @property
    def google_chat_webhook_url(self) -> Optional[str]:
        """Returns Google Chat webhook URL."""
        return self.get("google_chat_webhook_url")

    @property
    def enable_storm_threat(self) -> bool:
        """Returns whether storm threat data polling is enabled."""
        return self.get("enable_storm_threat", False)

    @property
    def ticker_sponsor(self) -> Optional[str]:
        """Returns ticker sponsor text."""
        return self.get("ticker_sponsor")

    @property
    def ticker_suppress_sps_on_outbreak(self) -> bool:
        """Returns whether to suppress SPS during outbreak situations."""
        return self.get("ticker_suppress_sps_on_outbreak", False)

    @property
    def ticker_theme(self) -> str:
        """Returns the ticker theme name."""
        return self.get("ticker_theme", "classic")


# ==================================================================================
# GLOBAL CONFIG INSTANCE
# ==================================================================================
# For backward compatibility, provide a global instance
# This allows gradual migration from direct dict access to ConfigManager
# ==================================================================================

config = ConfigManager()
