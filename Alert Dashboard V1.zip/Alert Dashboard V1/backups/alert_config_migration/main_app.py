# main_app.py
# ==================================================================================
# NWS ALERT DASHBOARD - MAIN APPLICATION
# ==================================================================================
# This is the core backend server that:
# 1. Connects to NWS Weather Wire (NWWS-OI) via XMPP for real-time alerts
# 2. Fetches initial alert state from NWS API
# 3. Manages active alerts, tracks updates/cancellations
# 4. Broadcasts alert data to connected dashboard clients via WebSocket
# 5. Handles alert map rendering by fetching zone geometries
# 6. Provides test alert injection for development/testing
# ==================================================================================

import asyncio
import collections
import json
import logging
import re
import sys
from html import unescape
from xml.etree import ElementTree
import aiohttp
from ugc_parser import load_ugc_database
from datetime import datetime, timedelta, timezone
from ugc_parser import UGC_TO_COUNTY

import slixmpp
import websockets
import weatherwise_control
import aiofiles

import http.server
import socketserver
import threading
import uuid

from google.oauth2 import service_account
from googleapiclient.discovery import build

from alert import Alert
from alert_parser import parse_alert, get_location_string
from constants import (
    NWS_EVENT_TO_PHENOMENON,
    TARGET_PHENOMENA,
    HIGH_PRIORITY_ALERTS,
    WFO_TIMEZONES,
    STATE_FIPS_MAP,
    TARGET_AFD_OFFICES,
    ALERT_PRIORITY
)
from patterns import PATTERN_AFD_ID, PATTERN_VTEC_TIMESTAMP, PATTERN_UGC_EXPIRATION
from zone_geometry_service import ZoneGeometryService
from alert_manager import AlertManager
from message_broker import MessageBroker
from daily_stats import get_daily_stats_tracker
import pytz
from earthquake_manager import get_earthquake_manager
from logger import get_logger, set_log_level

import os
import signal
import schedule


GOOGLE_CHAT_SPACE_ID = "spaces/AAAAVWPv5-E" 

last_message_timestamp = None
user_cache = {} # ADD THIS LINE
latest_storm_threats = []
UGC_TO_FIPS_MAP = {}

try:
    from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
except ImportError:
    # For Python < 3.9, you would need to pip install tzdata
    from backports.zoneinfo import ZoneInfo, ZoneInfoNotFoundError


def to_json(self):
        return self.__dict__


from config_manager import ConfigManager

# Initialize configuration manager
config_manager = ConfigManager('config.json')
# Keep backward compatibility by providing dict-like access
config = config_manager.as_dict()


_ALERT_CACHE_FILE = "active_alerts.json"
_SERVER_START_TIME = datetime.now()
_RESTART_INTERVAL_HOURS = config.get("restart_interval_hours", 24)


NWWS_USERNAME = config.get('nwws_credentials', {}).get('username')
NWWS_PASSWORD = config.get('nwws_credentials', {}).get('password')

if config.get("alert_source") == "nwws" and (not NWWS_USERNAME or not NWWS_PASSWORD):
    sys.exit("FATAL: 'username' or 'password' not found in config.json for NWWS mode")

WEBSOCKET_HOST = "0.0.0.0"
WEBSOCKET_PORT = 8765

HTTP_PORT = 8080

# Initialize services
zone_geometry_service = ZoneGeometryService()
alert_manager = AlertManager(_ALERT_CACHE_FILE)
message_broker = MessageBroker()

# Backward compatibility references (these will be gradually removed)
active_alerts = alert_manager.active_alerts
recent_products = alert_manager.recent_products
latest_afds = alert_manager.latest_afds
manual_lsrs = alert_manager.manual_lsrs
connected_clients = message_broker.connected_clients


# ==================================================================================
# TEST ALERT TIMESTAMP MANAGEMENT
# ==================================================================================
# Functions to update timestamps in test alerts to prevent them from being
# rejected as expired when injected during testing
# ==================================================================================


def update_test_alert_timestamps(alert_text: str, hours_from_now: int = 1) -> str:
    """
    Updates timestamps in test alert text to be current/future.
    This allows test alerts to pass the expiration check.

    Args:
        alert_text: Raw alert text with old timestamps
        hours_from_now: How many hours in the future to set expiration (default 1)

    Returns:
        Alert text with updated timestamps
    """
    now = datetime.now(timezone.utc)
    issue_time = now
    expire_time = now + timedelta(hours=hours_from_now)

    # Format for VTEC timestamps (YYMMDDTHHMM)
    vtec_issue = issue_time.strftime('%y%m%dT%H%MZ')
    vtec_expire = expire_time.strftime('%y%m%dT%H%MZ')

    # Update VTEC string issue time using compiled pattern
    alert_text = PATTERN_VTEC_TIMESTAMP.sub(rf'\g<1>{vtec_issue}-{vtec_expire}/', alert_text)

    # Update UGC line expiration (DDHHMM format)
    ugc_expire = expire_time.strftime('%d%H%M')
    alert_text = PATTERN_UGC_EXPIRATION.sub(rf'\g<1>{ugc_expire}\g<3>', alert_text)

    return alert_text


def update_test_alert_json_timestamps(alert_json: dict, hours_from_now: int = 1) -> dict:
    """
    Updates timestamps in API/JSON test alerts to be current/future.

    Args:
        alert_json: Alert JSON object
        hours_from_now: How many hours in the future to set expiration (default 1)

    Returns:
        Updated alert JSON object
    """
    import copy

    # Create a deep copy to avoid modifying the original
    alert = copy.deepcopy(alert_json)

    now = datetime.now(timezone.utc)
    issue_time = now
    expire_time = now + timedelta(hours=hours_from_now)

    # Format with timezone offset (e.g., "2025-10-20T14:35:00-04:00")
    # Use local timezone for realistic display
    local_now = datetime.now()
    tz_offset = local_now.astimezone().strftime('%z')
    tz_offset_formatted = f"{tz_offset[:3]}:{tz_offset[3:]}"

    issue_str = issue_time.strftime(f'%Y-%m-%dT%H:%M:%S{tz_offset_formatted}')
    expire_str = expire_time.strftime(f'%Y-%m-%dT%H:%M:%S{tz_offset_formatted}')

    # Update all time fields in properties
    if 'properties' in alert:
        props = alert['properties']
        props['sent'] = issue_str
        props['effective'] = issue_str
        props['onset'] = issue_str
        props['expires'] = expire_str
        props['ends'] = expire_str

        # Update VTEC in parameters if present
        if 'parameters' in props and 'VTEC' in props['parameters']:
            vtec_old = props['parameters']['VTEC'][0]
            vtec_issue = issue_time.strftime('%y%m%dT%H%MZ')
            vtec_expire = expire_time.strftime('%y%m%dT%H%MZ')

            # Replace timestamps in VTEC string
            vtec_new = re.sub(r'\d{6}T\d{4}Z', vtec_issue, vtec_old, count=1)
            vtec_new = re.sub(r'-\d{6}T\d{4}Z/', f'-{vtec_expire}/', vtec_new)
            props['parameters']['VTEC'][0] = vtec_new

    return alert


USER_TO_IMPERSONATE = 'zach@belparkweather.org'


def load_ugc_to_fips_map():
    """Loads the UGC-to-FIPS JSON map into memory."""
    global UGC_TO_FIPS_MAP
    try:
        with open('ugc_to_fips.json', 'r') as f:
            UGC_TO_FIPS_MAP = json.load(f)
        print(f"✅ Successfully loaded {len(UGC_TO_FIPS_MAP)} UGC-to-FIPS mappings.")
    except FileNotFoundError:
        print("❌ CRITICAL: ugc_to_fips.json not found. Run build_ugc_map.py to create it.")
    except Exception as e:
        print(f"❌ Error loading ugc_to_fips.json: {e}")


async def poll_storm_threat_data():
    """Periodically checks for and loads storm threat data from the processor."""
    global latest_storm_threats
    print("🌪️ Storm Threat polling service started.")
    while True:
        if not config.get("enable_storm_threat", False):
            print("Storm threat system is disabled in config.json. Waiting...")
            await asyncio.sleep(120)
            continue # This will skip the rest of the loop and start the next iteration
        
        try:
            # Use aiofiles for non-blocking file I/O
            async with aiofiles.open('storm_data.json', mode='r') as f:
                contents = await f.read()
                latest_storm_threats = json.loads(contents)
                print(f"✅ Loaded {len(latest_storm_threats)} storm threat objects.")
                # After loading new data, trigger a broadcast to all clients
                await broadcast_updates()
        except FileNotFoundError:
            # This is normal if the processor hasn't run yet
            latest_storm_threats = []
        except json.JSONDecodeError:
            print("⚠️ Error decoding storm_data.json. File might be partially written.")
        except Exception as e:
            print(f"❌ Error in storm threat poller: {e}")
        
        # Wait 2 minutes before checking again
        await asyncio.sleep(30)


async def poll_earthquake_data():
    """Periodically fetches earthquake data from USGS API."""
    earthquake_manager = get_earthquake_manager()
    print("🌍 Earthquake polling service started.")

    while True:
        try:
            earthquakes = await earthquake_manager.fetch_earthquakes()

            if earthquakes is not None:
                new_count = 0
                for eq in earthquakes:
                    is_new = earthquake_manager.add_or_update_earthquake(eq)
                    if is_new:
                        new_count += 1
                        print(f"🆕 New earthquake detected: M{eq.magnitude} - {eq.place}")

                # Remove earthquakes older than 24 hours
                earthquake_manager.remove_old_earthquakes(max_age_hours=24)

                # Broadcast updates to all clients
                await broadcast_updates()

                if new_count > 0:
                    print(f"✅ Processed {len(earthquakes)} earthquakes ({new_count} new)")

        except Exception as e:
            print(f"❌ Error in earthquake poller: {e}")
            import traceback
            traceback.print_exc()

        # Wait before next poll (default 2 minutes)
        await asyncio.sleep(earthquake_manager.poll_interval)


def save_alerts_to_disk():
    """Saves the current state of active_alerts, recent_products, and daily stats to disk."""
    print(f"💾 Saving {len(active_alerts)} alerts and {len(recent_products)} products to disk.")
    try:
        with open(_ALERT_CACHE_FILE, 'w') as f:
            data_to_save = {
                "active_alerts": {
                    alert_id: alert.to_json() for alert_id, alert in active_alerts.items()
                },
                "recent_products": list(recent_products),
                "latest_afds": latest_afds
            }
            json.dump(data_to_save, f, indent=2)

        # Also save daily stats state
        stats_tracker = get_daily_stats_tracker()
        stats_tracker.save_state()
    except Exception as e:
        print(f"❌ Error saving alerts to disk: {e}")

def load_alerts_from_disk():
    """Loads the state of active_alerts and recent_products from a JSON file."""
    global active_alerts, recent_products, latest_afds
    if not os.path.exists(_ALERT_CACHE_FILE):
        print("🗄️ No existing alert cache file found.")
        return

    try:
        with open(_ALERT_CACHE_FILE, 'r') as f:
            data = json.load(f)

        # Restore active_alerts
        active_alerts.clear()
        for alert_id, alert_data in data.get("active_alerts", {}).items():
            # ✅ FIX: Check for and pass 'raw_text' to the constructor
            raw_text_from_cache = alert_data.get("raw_text")
            if not raw_text_from_cache:
                print(f"⚠️ Skipping alert {alert_id} from cache, missing raw_text.")
                continue

            # Instantiate the Alert with the required text, then update it
            alert = Alert(raw_text_from_cache)
            alert.__dict__.update(alert_data)

            # Ensure datetime objects are properly restored
            if isinstance(alert.issue_time, str):
                alert.issue_time = datetime.fromisoformat(alert.issue_time)
            if isinstance(alert.expiration_time, str):
                alert.expiration_time = datetime.fromisoformat(alert.expiration_time)
            active_alerts[alert_id] = alert

        # Restore recent_products
        recent_products.clear()
        for product in data.get("recent_products", []):
            recent_products.append(product)

        # Restore AFD data
        latest_afds.update(data.get("latest_afds", {}))

        print(f"✅ Loaded {len(active_alerts)} alerts and {len(recent_products)} products from disk.")
    except Exception as e:
        print(f"❌ Error loading alerts from disk: {e}")
        # Clean up corrupted file
        if os.path.exists(_ALERT_CACHE_FILE):
            os.remove(_ALERT_CACHE_FILE)
            print("⚠️ Removed corrupted alert cache file.")

async def initial_api_state_load():
    """
    Performs a one-time poll of the NWS API on startup, parsing the
    JSON responses directly into Alert objects.
    """
    print("🛰️ Performing one-time startup poll of NWS API to get current state...")
    
    states_to_query = config.get("filters", {}).get("states", [])
    api_url = "https://api.weather.gov/alerts/active?status=actual"

    if states_to_query:
        api_url = f"https://api.weather.gov/alerts/active?status=actual&area={','.join(states_to_query)}"
        print(f"   -> Querying API for configured states: {states_to_query}")
    else:
        print("   -> No state filters found. Querying API for all active alerts nationwide.")

    async with aiohttp.ClientSession(headers={"User-Agent": "WeatherWiseDashboard/1.0"}) as session:
        try:
            async with session.get(api_url) as response:
                if response.status != 200:
                    print(f"❌ Initial API poll failed: {response.status}")
                    return

                data = await response.json()
                alert_features = data.get("features", [])
                print(f"   -> API response contains {len(alert_features)} alert features.")

                tasks = [fetch_and_process_api_alert(session, feature.get("properties", {}).get('@id')) for feature in alert_features if feature.get("properties", {}).get('@id')]
                
                parsed_alerts = await asyncio.gather(*tasks)
                
                alerts_added = 0
                stats_tracker = get_daily_stats_tracker()
                for alert in parsed_alerts:
                    if alert and alert.phenomenon in TARGET_PHENOMENA:
                        if alert.product_id not in active_alerts:
                             active_alerts[alert.product_id] = alert
                             alerts_added += 1
                             # Track alert for daily statistics
                             try:
                                 stats_tracker.record_alert(alert)
                             except Exception as e:
                                 print(f"⚠️ Error tracking initial alert for daily stats: {e}")

                print(f"✅ Initial state load complete. Added {alerts_added} new alerts to the system.")

        except Exception as e:
            print(f"❌ An error occurred during initial API state load: {e}")

async def poll_google_chat_messages():
    """Periodically polls Google Chat for new messages."""
    global last_message_timestamp, user_cache
    
    print("💬 Google Chat polling service started.")
    
    try:
        # --- 📍 CHANGE #1: ADD NEW SCOPE ---
        # We now need scopes for BOTH the Chat API and the People API.
        creds = service_account.Credentials.from_service_account_file(
            'service-account.json',
            scopes=[
                'https://www.googleapis.com/auth/chat.messages.readonly',
                'https://www.googleapis.com/auth/directory.readonly' # <-- New scope for People API
            ],
            subject=USER_TO_IMPERSONATE
        )
        # --- 📍 CHANGE #2: BUILD TWO SEPARATE SERVICES ---
        chat_service = build('chat', 'v1', credentials=creds)
        people_service = build('people', 'v1', credentials=creds) # <-- New service for People API
        
    except Exception as e:
        print(f"❌ FATAL: Could not build Google services. Check service-account.json and permissions. Error: {e}")
        return

    while True:
        try:
            results = chat_service.spaces().messages().list(
                parent=GOOGLE_CHAT_SPACE_ID,
                pageSize=25,
                orderBy="createTime DESC"
            ).execute()

            messages = results.get('messages', [])
            messages.reverse()

            messages_to_send = []
            if not messages:
                pass
            elif last_message_timestamp is None:
                messages_to_send = messages
            else:
                for msg in messages:
                    if msg['createTime'] > last_message_timestamp:
                        messages_to_send.append(msg)

            if messages_to_send:
                print(f"  ✅ Found {len(messages_to_send)} new messages. Looking up authors...")
                for msg in messages_to_send:
                    if msg.get('sender', {}).get('type') != 'HUMAN':
                        continue
                    
                    author_name = "Unknown Sender"
                    user_id_from_chat = msg.get('sender', {}).get('name') # This will be 'users/12345...'

                    if user_id_from_chat in user_cache:
                         author_name = user_cache[user_id_from_chat]
                    elif user_id_from_chat:
                        try:
                            # --- 📍 CHANGE #3: USE THE PEOPLE API FOR LOOKUP ---
                            # The People API needs the numeric ID, not the "users/" prefix.
                            person_id = user_id_from_chat.replace("users/", "")
                            
                            print(f"    -> Preparing to look up user via People API: {person_id}")

                            # Call the People API to get the user's name
                            user_info = people_service.people().get(
                                resourceName=f"people/{person_id}",
                                personFields='names' # We only need the name fields
                            ).execute()
                            
                            # Extract the display name from the People API response
                            display_name = "Unknown Sender"
                            names = user_info.get('names', [])
                            if names:
                                display_name = names[0].get('displayName', 'Unknown Sender')
                            
                            print(f"    -> Successfully fetched info for {display_name}")
                            author_name = display_name
                            user_cache[user_id_from_chat] = author_name
                            
                        except Exception as e:
                            print(f"!!! An unexpected error occurred during user lookup for {user_id_from_chat}: {e}")
                            author_name = "Error: See Console"

                    message_payload = {
                        "type": "chat_message",
                        "author": author_name,
                        "text": msg.get('text', '[Attachment or non-text message]')
                    }
                    await broadcast_message(json.dumps(message_payload))
                
                last_message_timestamp = messages_to_send[-1]['createTime']
                
        except Exception as e:
            print(f"❌ Error during polling loop: {e}")
        
        await asyncio.sleep(10)


class NWWSBot(slixmpp.ClientXMPP):
    """The main bot class to connect to the NWWS-OI service."""
    def __init__(self, jid, password):
        super().__init__(jid, password, sasl_mech='PLAIN')
        self.add_event_handler("session_start", self.on_session_start)
        self.add_event_handler("groupchat_message", self.on_muc_message)
        self.add_event_handler("disconnected", self.on_disconnected)
        
        # This will hold our reconnection task to ensure we don't run duplicates
        self.reconnect_task = None

    async def on_session_start(self, event):
        # When a session starts, it means we are connected.
        # We must cancel any pending reconnection task.
        if self.reconnect_task and not self.reconnect_task.done():
            self.reconnect_task.cancel()
            print("✅ Reconnection successful. Reconnect task cancelled.")
        self.reconnect_task = None

        print("🚀 Session started. Joining alert channel...")
        await self.get_roster()
        self.send_presence()
        await self.plugin['xep_0045'].join_muc('nwws@conference.nwws-oi.weather.gov', 'WeatherWiseBot')

    def on_muc_message(self, msg):
        if msg['type'] != 'groupchat' or msg['mucnick'] == 'WeatherWiseBot':
            return

        alert_body = msg.xml.find('{nwws-oi}x')
        if alert_body is not None and alert_body.text:
            raw_text = unescape(alert_body.text).strip()

            match = PATTERN_AFD_ID.search(raw_text)
            if match:
                product_id = match.group(1).upper()
                office = product_id[3:]
                if office in TARGET_AFD_OFFICES:
                    print(f"✅ Captured AFD for {office}.")
                    latest_afds[office] = raw_text
                    # Save AFDs to disk immediately to prevent loss on restart
                    alert_manager.save_to_disk()
                    # Broadcast the update and stop further processing for this product
                    asyncio.create_task(broadcast_updates())
                    return

            recent_products.appendleft({'text': raw_text, 'id': raw_text})
            asyncio.create_task(broadcast_updates())
            asyncio.create_task(handle_incoming_alert(raw_text))
            return

        if msg['body']:
            print(f"Received summary line (no full text found): {msg['body']}")

    def on_disconnected(self, event):
        """Handles disconnection and schedules a persistent reconnection task."""
        print("🔌 INFO: Disconnected from the NWWS-OI server.")
        
        # Start the reconnect task only if it's not already running.
        if self.reconnect_task is None or self.reconnect_task.done():
            print("   -> Scheduling persistent reconnection task.")
            self.reconnect_task = asyncio.create_task(self.attempt_reconnect())
        else:
            print("   -> Reconnection task is already active.")

    async def attempt_reconnect(self):
        """Continuously attempts to reconnect with an incremental backoff."""
        wait_time = 5  # Initial wait time in seconds
        while True:
            try:
                print(f"   -> Attempting to reconnect in {wait_time} seconds...")
                await asyncio.sleep(wait_time)
                # The connect() coroutine will re-run the entire connection flow
                await self.connect()
                # If connect() succeeds, the session_start event will fire
                # and cancel this task. We break the loop here.
                break 
            except Exception as e:
                print(f"   -> Reconnect attempt failed: {e}")
                # Increase wait time for the next attempt (exponential backoff)
                # but cap it at 5 minutes (300 seconds)
                wait_time = min(wait_time * 2, 300) 

def filter_api_alert(alert_properties, filters):
    if not filters:
        return True
    states = filters.get("states", [])
    if states and not any(state in alert_properties.get("areaDesc", "") for state in states):
        return False
    offices = filters.get("offices", [])
    if offices and alert_properties.get("senderName") in offices:
        return True
    ugc_codes = filters.get("ugc_codes", [])
    if ugc_codes:
        alert_ugc = alert_properties.get("geocode", {}).get("UGC", [])
        if any(code in ugc_codes for code in alert_ugc):
            return True
    if offices or ugc_codes:
        return False
    return True

async def poll_nws_api():
    """
    Periodically polls the NWS API for active alerts and sends them
    through the same handling pipeline as NWWS alerts.
    """
    states_to_query = config.get("filters", {}).get("states", [])
    if not states_to_query:
        print("⚠️ No states listed in config.json filters. API polling will not run.")
        return

    # Use a set to keep track of alert IDs we've already processed
    processed_ids = set()

    api_url = f"https://api.weather.gov/alerts/active?status=actual&area={','.join(states_to_query)}"
    print(f"📡 Polling NWS API for states: {states_to_query}")

    async with aiohttp.ClientSession(headers={"User-Agent": "WeatherDashboard/1.0"}) as session:
        while True:
            try:
                async with session.get(api_url) as response:
                    if response.status != 200:
                        print(f"❌ Error fetching from NWS API: {response.status}")
                        await asyncio.sleep(60)
                        continue

                    data = await response.json()
                    alert_features = data.get("features", [])
                    print(f"API poll found {len(alert_features)} active features.")

                    # Get the full text for each new alert
                    for feature in alert_features:
                        alert_id = feature.get("properties", {}).get("id")
                        if alert_id and alert_id not in processed_ids:
                            # The '@id' field contains the URL to the full alert text
                            full_text_url = feature.get('@id')
                            if full_text_url:
                                async with session.get(full_text_url) as text_response:
                                    if text_response.status == 200:
                                        # The response is a JSON object containing the raw text
                                        alert_data = await text_response.json()
                                        raw_text = alert_data.get("properties", {}).get("productText")
                                        if raw_text:
                                            # Send the full text to our universal handler
                                            await handle_incoming_alert(raw_text)
                                            processed_ids.add(alert_id)
                                    else:
                                        print(f"❌ Failed to fetch full text for {alert_id}")
            except Exception as e:
                print(f"An error occurred during API polling: {e}")

            # Wait for the next poll
            await asyncio.sleep(60)
            
def filter_nwws_alert(parsed_alert, filters):
    """
    Checks if an alert from NWWS should be kept based on the provided filters.
    The logic is an OR: if any filter is defined, the alert must match at least one.
    """
    # If no filters are defined, or all filter lists within are empty, pass everything.
    if not filters or all(not v for v in filters.values()):
        return True

    # If any filter type is defined, the alert must match at least one of the criteria below.
    # We start by assuming it doesn't match.
    matches_criteria = False
    
    # --- Check State Filter ---
    states = filters.get("states", [])
    if states:
        # Get the 2-letter state codes from the alert's UGCs (e.g., 'OH' from 'OHC123')
        alert_states = {ugc[:2] for ugc in parsed_alert.affected_areas}
        if any(state in alert_states for state in states):
            matches_criteria = True
            
    # --- Check Office Filter ---
    offices = filters.get("offices", [])
    if not matches_criteria and offices:
        if parsed_alert.issuing_office in offices:
            matches_criteria = True

    # --- Check UGC Filter ---
    ugc_codes = filters.get("ugc_codes", [])
    if not matches_criteria and ugc_codes:
        if any(code in ugc_codes for code in parsed_alert.affected_areas):
            matches_criteria = True
            
    # The function returns True only if one of the checks flipped the flag.
    return matches_criteria


# Zone geometry fetching is now handled by ZoneGeometryService
# See zone_geometry_service.py for implementation


def populate_fips_codes_from_ugc(alert: Alert):
    """
    Uses the pre-built UGC_TO_FIPS_MAP to find all FIPS codes associated
    with an alert's UGCs (both county and zone types).
    This is critical for zone-based alerts that need FIPS codes for mapping.
    """
    if not alert.affected_areas:
        return

    all_fips = set(alert.fips_codes) if alert.fips_codes else set()

    for ugc in alert.affected_areas:
        # Look up the UGC code in our new map. The map returns a LIST of FIPS codes.
        found_fips_list = UGC_TO_FIPS_MAP.get(ugc)

        if found_fips_list:
            # Add all found FIPS codes to our set
            for fips in found_fips_list:
                all_fips.add(fips.zfill(5))

    alert.fips_codes = sorted(list(all_fips))

async def send_alert_to_google_chat(alert: Alert):
    """Formats and sends a new alert notification to a Google Chat webhook."""
    
    if not config.get("send_google_chat_alerts", False):
        return
    
    webhook_url = config.get("google_chat_webhook_url")
    if not webhook_url:
        return # Do nothing if the URL isn't configured

    alert_type_map = {
        "TO": "Tornado Warning",
        "SV": "Severe Thunderstorm Warning",
        "SVR": "Severe Thunderstorm Warning",
        "FF": "Flash Flood Warning",
        "FFW": "Flash Flood Warning",
        "WSW": "Winter Storm Warning",
        "WW": "Winter Weather Advisory",
        "WSA": "Winter Storm Watch",
        "SQW": "Snow Squall Warning",
        "SS": "Storm Surge Warning",
        "TOA": "Tornado Watch",
        "SVA": "Severe Thunderstorm Watch",
        "FFA": "Flash Flood Watch"
    }
    alert_name = alert_type_map.get(alert.phenomenon, "Weather Alert")
    
    # Add a prefix for high-impact events
    if alert.is_emergency:
        alert_name = f"🚨 **TORNADO EMERGENCY** 🚨"
    elif alert.damage_threat in ["DESTRUCTIVE", "CATASTROPHIC"]:
        alert_name = f"**{alert.damage_threat.upper()}** {alert_name}"
    elif alert.tornado_observed:
        alert_name = f"**OBSERVED** {alert_name}"
        
    expires_text = "N/A"
    if alert.expiration_time:
        try:
            # Look up the IANA timezone name from the WFO ID, default to New York (Eastern)
            iana_tz_name = WFO_TIMEZONES.get(alert.issuing_office, "America/New_York")
            target_tz = ZoneInfo(iana_tz_name)
            
            # Convert the UTC time to the target timezone
            local_time = alert.expiration_time.astimezone(target_tz)
            
            # Format the string with the correct local time and timezone abbreviation
            expires_text = local_time.strftime('%I:%M %p %Z')

        except ZoneInfoNotFoundError:
            # Fallback for rare cases where a timezone isn't found
            expires_text = alert.expiration_time.strftime('%I:%M %p UTC')
        except Exception as e:
            print(f"Error converting timezone for alert {alert.product_id}: {e}")
            expires_text = "Error"

    # Prepare the message payload for Google Chat
    message = {
        "cardsV2": [{
            "cardId": "weatherAlertCard",
            "card": {
                "header": {
                    "title": f"New {alert_name}",
                    "subtitle": f"For: {alert.display_locations}"
                },
                "sections": [{
                    "widgets": [
                        
                        { "textParagraph": { "text": f"<b>Expires:</b> {expires_text}" } },
                        { "textParagraph": { "text": f"<b>Threats:</b> Wind: {alert.max_wind_gust or 'N/A'}, Hail: {alert.max_hail_size or 'N/A'}" } }
                    ]
                }]
            }
        }]
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(webhook_url, json=message) as response:
                if response.status == 200:
                    print(f"✅ Successfully sent alert {alert.product_id} to Google Chat.")
                else:
                    print(f"❌ Failed to send alert to Google Chat. Status: {response.status}, Response: {await response.text()}")
    except Exception as e:
        print(f"❌ An error occurred while sending alert to Google Chat: {e}")
        
        
def create_statewide_summary(alerts):
    """
    Processes all active alerts and returns a dictionary mapping
    each FIPS code to its highest-priority alert phenomenon.
    Includes all phenomenon types in TARGET_PHENOMENA.
    """
    county_threats = {}

    for alert in alerts:
        alert_phenomenon = alert.get("phenomenon")
        alert_priority = ALERT_PRIORITY.get(alert_phenomenon, 99)

        fips_codes = alert.get("fips_codes", [])

        # CRITICAL FIX: If alert has no fips_codes, skip it entirely
        # This prevents zone-based alerts without FIPS from being invisible
        if not fips_codes:
            print(f"⚠️ Alert {alert.get('product_id')} has no FIPS codes, cannot add to statewide summary")
            continue

        for fips in fips_codes:
            if fips not in county_threats or alert_priority < ALERT_PRIORITY.get(county_threats[fips], 99):
                county_threats[fips] = alert_phenomenon

    return county_threats

async def fetch_and_process_api_alert(session, url):
    """
    Fetches the full JSON for a single alert from the API, passes the entire
    feature to the parser, and returns a complete Alert object.
    Includes zone geometry fetching for zone-based alerts without polygons.
    """
    try:
        async with session.get(url) as response:
            if response.status == 200:
                # The entire response is the feature JSON we need to parse
                feature_json = await response.json()
                if feature_json:
                    # MODIFICATION: Call the universal parse_alert function
                    alert = parse_alert(feature_json)

                    # If this alert has zone codes but no polygon, fetch zone geometries
                    if alert:
                        await zone_geometry_service.populate_alert_with_zone_geometry(alert, session)

                    return alert
    except Exception as e:
        print(f"Failed to fetch or parse alert from {url}: {e}")
    return None


# ==================================================================================
# ALERT PROCESSING AND MANAGEMENT
# ==================================================================================
# Core function that handles incoming alerts from NWWS, performs intelligent
# merging of updates, handles cancellations, fetches zone geometries, and
# broadcasts changes to connected clients.
# ==================================================================================

async def handle_incoming_alert(raw_text: str, is_test: bool = False):
    """
    Parses, manages, and broadcasts alerts. Now intelligently merges updates
    and ignores already-expired incoming products.

    Args:
        raw_text: The raw alert text to parse
        is_test: If True, marks this alert as a test alert that can be cleared
    """
    parsed_alert = parse_alert(raw_text)

    # If parsing returns None (e.g., filtered out non-thunderstorm SPS), skip processing
    if parsed_alert is None:
        return

    # Mark as test alert if specified
    if is_test:
        parsed_alert.is_test = True

    try:
        if '$$' in parsed_alert.raw_text and parsed_alert.product_id:
            main_block = parsed_alert.raw_text.split('$$')[0]
            text_parts = main_block.split(parsed_alert.product_id)
            if len(text_parts) > 1:
                parsed_alert.text = text_parts[1].strip()
    except Exception as e:
        print(f"Could not automatically extract plain text for {parsed_alert.product_id}: {e}")
        if not hasattr(parsed_alert, 'text'):
            parsed_alert.text = parsed_alert.raw_text

    if parsed_alert.expiration_time and parsed_alert.expiration_time < datetime.now(timezone.utc):
        print(f"Ignoring stale, already-expired product: {parsed_alert.product_id or 'Unknown ID'}")
        return

    if not parsed_alert.product_id or parsed_alert.phenomenon not in TARGET_PHENOMENA:
        return

    # DEBUG: Log all SV warnings with their status flags for troubleshooting stats tracking
    if parsed_alert.phenomenon == "SV":
        print(f"[DEBUG-SV] {parsed_alert.product_id}: is_update={parsed_alert.is_update}, is_cancellation={parsed_alert.is_cancellation}")

    filters = config.get("filters", {})
    if not filter_nwws_alert(parsed_alert, filters):
        return

    # CRITICAL FIX: Always populate FIPS codes from UGC codes for zone-based alerts
    # This ensures zone-based alerts (Winter Weather Advisories, Special Weather Statements, etc.)
    # have the necessary FIPS codes for map rendering
    if parsed_alert.affected_areas:
        populate_fips_codes_from_ugc(parsed_alert)

    # NEW: If alert has zone codes but no polygon, fetch zone geometries from NWS API
    async with aiohttp.ClientSession() as session:
        await zone_geometry_service.populate_alert_with_zone_geometry(parsed_alert, session)

    alert_id_to_manage = parsed_alert.product_id
    broadcast_needed = False

    if parsed_alert.is_cancellation:
        if alert_id_to_manage in active_alerts:
            print(f"❌ CANCELLATION: Removing {alert_id_to_manage}.")
            del active_alerts[alert_id_to_manage]
            broadcast_needed = True
    
    elif alert_id_to_manage in active_alerts:
        print(f"🔄 Merging update for alert: {alert_id_to_manage}")
        existing_alert = active_alerts[alert_id_to_manage]

        # --- START OF FIX ---
        # Overwrite text and times unconditionally with the latest data
        existing_alert.raw_text = parsed_alert.raw_text
        existing_alert.expiration_time = parsed_alert.expiration_time

        # Preserve test flag (once a test, always a test)
        if parsed_alert.is_test:
            existing_alert.is_test = True

        # If the new alert has a polygon, use it.
        if parsed_alert.polygon:
            existing_alert.polygon = parsed_alert.polygon

        # Combine UGC and FIPS codes, ensuring no duplicates
        existing_alert.affected_areas = sorted(list(set(existing_alert.affected_areas + parsed_alert.affected_areas)))
        existing_alert.fips_codes = sorted(list(set(existing_alert.fips_codes + parsed_alert.fips_codes)))

        # Re-generate the display location string with the updated county list
        if existing_alert.affected_areas:
             existing_alert.display_locations = get_location_string(existing_alert.affected_areas)

        # Update storm motion if present in the new data
        if parsed_alert.storm_motion:
            existing_alert.storm_motion = parsed_alert.storm_motion

        # --- MERGE THREATS ---
        # Use the highest threat level found in any version of the alert
        existing_alert.is_emergency = existing_alert.is_emergency or parsed_alert.is_emergency
        existing_alert.tornado_observed = existing_alert.tornado_observed or parsed_alert.tornado_observed
        existing_alert.tornado_possible = existing_alert.tornado_possible or parsed_alert.tornado_possible

        # Compare and set the highest damage threat level
        threat_levels = {'NONE': 0, 'BASE': 1, 'CONSIDERABLE': 2, 'DESTRUCTIVE': 3, 'CATASTROPHIC': 4}
        existing_threat_val = threat_levels.get(existing_alert.damage_threat, 0)
        new_threat_val = threat_levels.get(parsed_alert.damage_threat, 0)
        if new_threat_val > existing_threat_val:
            existing_alert.damage_threat = parsed_alert.damage_threat
        # --- END OF FIX ---

        # Track alert for daily statistics (even if it's an update, in case we missed the original)
        try:
            stats_tracker = get_daily_stats_tracker()
            stats_tracker.record_alert(existing_alert)
        except Exception as e:
            print(f"⚠️ Error tracking alert update for daily stats: {e}")

        broadcast_needed = True

    else:
        if parsed_alert.phenomenon in HIGH_PRIORITY_ALERTS:
            # Only send chime and Google Chat for NEW alerts, not updates/continuations
            if not parsed_alert.is_update:
                print(f"🔔 New high-priority alert: {alert_id_to_manage}. Triggering chime.")
                chime_message = json.dumps({
                    "type": "new_alert",
                    "alert_data": parsed_alert.to_json()
                })
                asyncio.create_task(broadcast_message(chime_message))
                asyncio.create_task(send_alert_to_google_chat(parsed_alert))
            else:
                print(f"⏭️  Skipping chime/Google Chat for alert update (CON): {alert_id_to_manage}")

        print(f"➕ New alert added: {alert_id_to_manage}")
        active_alerts[alert_id_to_manage] = parsed_alert

        # Track alert for daily statistics
        try:
            stats_tracker = get_daily_stats_tracker()
            stats_tracker.record_alert(parsed_alert)
        except Exception as e:
            print(f"⚠️ Error tracking alert for daily stats: {e}")

        broadcast_needed = True

    if await clear_expired_alerts():
        broadcast_needed = True

    if broadcast_needed:
        await broadcast_updates()


async def clear_expired_alerts():
    """
    Performs a single pass to remove expired alerts from the global list.
    Returns True if alerts were removed, False otherwise.
    """
    now_utc = datetime.now(timezone.utc)
    initial_count = len(active_alerts)
    
    unexpired_alerts = {
        alert_id: alert for alert_id, alert in active_alerts.items()
        if not (alert.expiration_time and alert.expiration_time < now_utc)
    }
    
    if len(unexpired_alerts) < initial_count:
        print(f"🧹 Cleared {initial_count - len(unexpired_alerts)} expired alert(s).")
        active_alerts.clear()
        active_alerts.update(unexpired_alerts)
        return True
    return False

async def background_cleanup_task():
    """The background task that periodically clears expired alerts."""
    while True:
        await asyncio.sleep(60)
        # If the cleanup removed any alerts, broadcast the changes to all clients.
        if await clear_expired_alerts():
            await broadcast_updates()


async def periodic_state_save_task():
    """Periodically saves alerts and daily stats state to disk (every 5 minutes)."""
    while True:
        await asyncio.sleep(300)  # Save every 5 minutes
        save_alerts_to_disk()


async def broadcast_updates():
    """Broadcasts complete state update to all connected clients."""
    earthquake_manager = get_earthquake_manager()
    earthquake_data = earthquake_manager.to_json()

    await message_broker.broadcast_update(
        alert_manager,
        config,
        latest_storm_threats,
        create_statewide_summary,
        earthquake_data
    )

async def broadcast_message(message: str):
    """Broadcasts a raw message string to all connected clients."""
    await message_broker.broadcast_message(message)

async def client_handler(websocket):
    message_broker.add_client(websocket)
    try:
        # First, clean up any expired alerts before sending the initial state.
        await clear_expired_alerts()
        # Then, send the clean list to the new client.
        await broadcast_updates()

        async for message in websocket:
            try:
                data = json.loads(message)
                if data.get('type') == 'feature_alert':
                    print(f"Featuring alert: {data.get('alert_data', {}).get('product_id')}")
                    # Re-broadcast this message to all clients (including the new widget)
                    await broadcast_message(message)
                    
                elif data.get('type') == 'manual_lsr':
                    report_payload = data.get('payload', {})
                    if 'lat' in report_payload and 'lng' in report_payload:
                        # Add server-side info to the report
                        report_payload['id'] = str(uuid.uuid4())
                        report_payload['timestamp'] = datetime.now(timezone.utc).isoformat()
                        print(f"📝 Received manual storm report: {report_payload['typeText']}")
                        manual_lsrs.append(report_payload)

                        # Track for daily statistics
                        try:
                            stats_tracker = get_daily_stats_tracker()
                            # Convert manual LSR format to standardized format
                            report_data = {
                                'type': report_payload.get('type', 'unknown'),
                                'magnitude': report_payload.get('magnitude', ''),
                                'location': report_payload.get('location', 'Unknown'),
                                'time': report_payload['timestamp'],
                                'geometry': {
                                    'coordinates': [report_payload['lng'], report_payload['lat']]
                                }
                            }
                            stats_tracker.record_storm_report(report_data)
                        except Exception as e:
                            print(f"⚠️ Error tracking manual LSR for daily stats: {e}")

                        # Immediately broadcast the update so everyone sees it
                        await broadcast_updates()
                
                elif data.get('type') == 'feature_camera':
                    print(f"Featuring ODOT Camera: {data.get('camera_data', {}).get('title')}")
                    # Re-broadcast this message to all clients (including our new camera widget)
                    await broadcast_message(message)
                    
                elif data.get('type') == 'hide_camera_widget':
                    print("Broadcasting request to hide camera widget.")
                    await broadcast_message(message)
                    
                elif data.get('type') == 'clear_manual_lsrs':
                    print("🗑️ Clearing all manual storm reports.")
                    manual_lsrs.clear() # This empties the list
                    await broadcast_updates() # This tells everyone the list is now empty
                    
                elif data.get('type') == 'update_ticker_settings':
                    settings = data.get('settings', {})
                    print(f"⚙️ Received ticker settings to broadcast: {settings}")

                    # Save ticker theme to config.json if provided
                    if 'theme' in settings:
                        try:
                            with open('config.json', 'r') as f:
                                config_data = json.load(f)
                            config_data['ticker_theme'] = settings['theme']
                            with open('config.json', 'w') as f:
                                json.dump(config_data, f, indent=2)
                            print(f"💾 Saved ticker theme to config.json: {settings['theme']}")
                            # Reload config
                            config.reload()
                        except Exception as e:
                            print(f"❌ Error saving ticker theme: {e}")

                    # Prepare the message to send out to all ticker clients
                    broadcast_payload = {
                        "type": "ticker_settings_update",
                        "settings": settings
                    }

                    # Use the existing broadcast function to send to all clients
                    await broadcast_message(json.dumps(broadcast_payload))
                    
                elif data.get('type') in ['show_lower_third', 'hide_lower_third']:
                    print(f"Broadcasting command: {data.get('type')}")
                    await broadcast_message(message)
                
                elif data.get('type') == 'zoom':
                    # Support both coordinate-based and location-based zoom
                    if 'latitude' in data and 'longitude' in data:
                        lat = data['latitude']
                        lon = data['longitude']
                        print(f"🔎 Received zoom request for coordinates: ({lat}, {lon})")
                        loop = asyncio.get_running_loop()
                        await loop.run_in_executor(
                            None,
                            lambda: weatherwise_control.zoom_to_location(latitude=lat, longitude=lon)
                        )
                    elif 'location' in data:
                        location = data['location']
                        print(f"🔎 Received zoom request for location: {location}")
                        loop = asyncio.get_running_loop()
                        await loop.run_in_executor(
                            None,
                            lambda: weatherwise_control.zoom_to_location(location_name=location)
                        )

                # === TEST ALERT INJECTION ===
                elif data.get('type') == 'inject_test_alert':
                    print("🧪 TEST ALERT INJECTION RECEIVED")
                    alert_data = data.get('alert_data')
                    alert_source = data.get('source', 'nwws')

                    if not alert_data:
                        print("❌ No alert data provided")
                        continue

                    try:
                        if alert_source == 'api':
                            # Update timestamps to be current/future
                            print(f"🧪 Updating API alert timestamps to current time...")
                            alert_data_updated = update_test_alert_json_timestamps(alert_data, hours_from_now=1)

                            # Simulate API alert processing
                            print(f"🧪 Injecting TEST API alert: {alert_data_updated.get('properties', {}).get('headline', 'Unknown')}")
                            parsed_alert = parse_alert(alert_data_updated)

                            # Mark as test alert
                            if parsed_alert:
                                parsed_alert.product_id = f"TEST.{parsed_alert.product_id or 'UNKNOWN'}"

                                # Process zone geometry if needed
                                async with aiohttp.ClientSession() as session:
                                    await zone_geometry_service.populate_alert_with_zone_geometry(parsed_alert, session)

                                # Populate FIPS codes
                                if parsed_alert.affected_areas:
                                    populate_fips_codes_from_ugc(parsed_alert)

                                # Mark as test alert
                                parsed_alert.is_test = True

                                # Add to active alerts
                                active_alerts[parsed_alert.product_id] = parsed_alert

                                # Track alert for daily statistics
                                try:
                                    stats_tracker = get_daily_stats_tracker()
                                    stats_tracker.record_alert(parsed_alert)
                                except Exception as e:
                                    print(f"⚠️ Error tracking test alert for daily stats: {e}")

                                print(f"✅ TEST alert added: {parsed_alert.product_id} ({parsed_alert.phenomenon})")
                                await broadcast_updates()

                        elif alert_source == 'nwws':
                            # Update timestamps to be current/future
                            print(f"🧪 Updating NWWS alert timestamps to current time...")
                            alert_data_updated = update_test_alert_timestamps(alert_data, hours_from_now=1)

                            # Simulate NWWS/Weather Wire text alert (mark as test)
                            print(f"🧪 Injecting TEST NWWS alert (first 80 chars): {alert_data_updated[:80]}...")
                            await handle_incoming_alert(alert_data_updated, is_test=True)
                            print(f"✅ TEST NWWS alert processed")

                        else:
                            print(f"❌ Unknown alert source: {alert_source}")

                    except Exception as e:
                        print(f"❌ Error injecting test alert: {e}")
                        import traceback
                        traceback.print_exc()

                elif data.get('type') == 'clear_test_alerts':
                    # Remove all alerts marked as test alerts
                    test_alert_ids = [alert_id for alert_id, alert in active_alerts.items() if alert.is_test]
                    for alert_id in test_alert_ids:
                        del active_alerts[alert_id]
                    print(f"✅ Cleared {len(test_alert_ids)} test alert(s)")
                    await broadcast_updates()

                elif data.get('type') == 'clear_alert':
                    # Manually clear a specific alert by product_id
                    product_id = data.get('product_id')
                    if product_id and product_id in active_alerts:
                        removed_alert = active_alerts[product_id]
                        del active_alerts[product_id]
                        print(f"🗑️ Manually cleared alert: {product_id} ({removed_alert.phenomenon})")
                        await broadcast_updates()
                    else:
                        print(f"⚠️ Alert not found for manual clearing: {product_id}")

                # === DAILY RECAP / SUMMARY HANDLERS ===
                elif data.get('type') == 'get_daily_summary':
                    # Return current day's running statistics
                    try:
                        stats_tracker = get_daily_stats_tracker()
                        summary = stats_tracker.generate_summary()
                        await websocket.send(json.dumps({
                            'type': 'daily_summary',
                            'data': summary
                        }))
                    except Exception as e:
                        print(f"❌ Error getting daily summary: {e}")

                elif data.get('type') == 'get_previous_day_summary':
                    # Return yesterday's finalized summary
                    try:
                        stats_tracker = get_daily_stats_tracker()
                        date = data.get('date')  # Optional: specific date in YYYY-MM-DD format
                        if not date:
                            yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
                            date = yesterday

                        summary = stats_tracker.load_daily_summary(date)
                        if summary:
                            await websocket.send(json.dumps({
                                'type': 'previous_day_summary',
                                'data': summary
                            }))
                        else:
                            await websocket.send(json.dumps({
                                'type': 'previous_day_summary',
                                'data': None,
                                'error': f'No summary found for {date}'
                            }))
                    except Exception as e:
                        print(f"❌ Error getting previous day summary: {e}")

                elif data.get('type') == 'get_summary_history':
                    # Return list of recent daily summaries
                    try:
                        stats_tracker = get_daily_stats_tracker()
                        days = data.get('days', 7)
                        summaries = stats_tracker.load_recent_summaries(days)
                        await websocket.send(json.dumps({
                            'type': 'summary_history',
                            'data': summaries
                        }))
                    except Exception as e:
                        print(f"❌ Error getting summary history: {e}")

                elif data.get('type') == 'get_monthly_summary':
                    # Return monthly aggregated stats
                    try:
                        stats_tracker = get_daily_stats_tracker()
                        month = data.get('month')  # Format: YYYY-MM
                        if not month:
                            month = datetime.now().strftime('%Y-%m')

                        summary = stats_tracker.load_monthly_summary(month)
                        if summary:
                            await websocket.send(json.dumps({
                                'type': 'monthly_summary',
                                'data': summary
                            }))
                        else:
                            await websocket.send(json.dumps({
                                'type': 'monthly_summary',
                                'data': None,
                                'error': f'No summary found for {month}'
                            }))
                    except Exception as e:
                        print(f"❌ Error getting monthly summary: {e}")

            except json.JSONDecodeError:
                print(f"Received non-JSON message: {message}")
            except Exception as e:
                print(f"Error processing client message: {e}")
    except websockets.exceptions.ConnectionClosed:
        print("Client connection closed.")
    finally:
        message_broker.remove_client(websocket)

def start_http_server():
        """Starts a simple HTTP server in a separate thread."""
    # This handler will serve files from the directory where you run the script
        handler = http.server.SimpleHTTPRequestHandler
    
    # Create and start the server
        with socketserver.TCPServer(("", HTTP_PORT), handler) as httpd:
            print(f"✅ HTTP server started on http://{WEBSOCKET_HOST}:{HTTP_PORT}")
            print(f"   View your dashboard at http://<Your_Remote_IP>:{HTTP_PORT}/index.html")
            httpd.serve_forever()
            
async def watch_config_file():
    """Periodically checks the config file for changes and reloads it without a restart."""
    global config
    print("⚙️ Configuration watcher started. Checking for changes every 60 seconds.")
    while True:
        await asyncio.sleep(60)
        try:
            # Use ConfigManager's reload method
            if config_manager.reload():
                print("⚙️ Detected change in config.json. Reloading configuration...")
                # Update the config dict reference
                config = config_manager.as_dict()

                # Broadcast updates to clients so they get the new settings
                await broadcast_updates()

        except Exception as e:
            print(f"An unexpected error occurred while watching config file: {e}")


async def check_for_restart():
    """Checks if the configured restart interval has passed and triggers a graceful restart."""
    print(f"⏲️ Scheduled restart enabled. Checking every 60 minutes for a restart after {_RESTART_INTERVAL_HOURS} hours.")
    while True:
        await asyncio.sleep(3600)  # Check every 60 minutes
        elapsed_time = datetime.now() - _SERVER_START_TIME
        if elapsed_time.total_seconds() > _RESTART_INTERVAL_HOURS * 3600:
            print("⏳ Scheduled restart initiated. Saving state and restarting server...")
            save_alerts_to_disk()
            # Find and terminate the current process to trigger the restart mechanism
            os.kill(os.getpid(), signal.SIGINT)


def finalize_daily_summary():
    """
    Called at midnight Eastern time to finalize the previous day's summary.
    Generates summary files and resets counters for the new day.
    """
    try:
        stats_tracker = get_daily_stats_tracker()

        # Use Eastern timezone for daily boundaries
        eastern = pytz.timezone('America/New_York')
        now_eastern = datetime.now(eastern)
        yesterday = (now_eastern - timedelta(days=1)).strftime('%Y-%m-%d')

        print(f"📊 Finalizing daily summary for {yesterday} (Eastern Time)...")
        stats_tracker.save_daily_summary(yesterday)

        # Reset for new day
        stats_tracker.current_date = now_eastern.strftime('%Y-%m-%d')
        stats_tracker.reset_for_new_day()

        print(f"✅ Daily summary finalized. Ready for {stats_tracker.current_date}")
    except Exception as e:
        print(f"❌ Error finalizing daily summary: {e}")
        import traceback
        traceback.print_exc()


async def daily_summary_scheduler():
    """
    Background task that runs the scheduler to finalize daily summaries at midnight.
    """
    print("📅 Daily summary scheduler started. Will finalize summaries at midnight.")

    # Schedule midnight task
    schedule.every().day.at("00:00").do(finalize_daily_summary)

    # Check for pending tasks every minute
    while True:
        schedule.run_pending()
        await asyncio.sleep(60)  # Check every minute


def check_and_finalize_previous_day():
    """
    On startup, check if yesterday's summary exists. If not, create it.
    This handles cases where the app was offline at midnight.
    Uses Eastern timezone for daily boundaries.
    """
    try:
        stats_tracker = get_daily_stats_tracker()

        # Use Eastern timezone for daily boundaries
        eastern = pytz.timezone('America/New_York')
        now_eastern = datetime.now(eastern)
        yesterday = (now_eastern - timedelta(days=1)).strftime('%Y-%m-%d')
        summary_path = os.path.join(stats_tracker.daily_dir, f"summary_{yesterday}.json")

        if not os.path.exists(summary_path):
            print(f"⚠️ No summary found for {yesterday} (Eastern Time). Creating placeholder summary...")
            # Create a summary with current data (might be incomplete if app was down)
            stats_tracker.save_daily_summary(yesterday)
        else:
            print(f"✅ Summary for {yesterday} already exists.")

        # Ensure we're tracking for today
        today = now_eastern.strftime('%Y-%m-%d')
        if stats_tracker.current_date != today:
            print(f"⚠️ Resetting stats tracker to today's date: {today} (Eastern Time)")
            stats_tracker.current_date = today
            stats_tracker.reset_for_new_day()

    except Exception as e:
        print(f"❌ Error checking previous day summary: {e}")


async def main():
    # Initialize logger with config setting
    log_level = config.get("log_level", "normal")
    set_log_level(log_level)

    # Start the HTTP server in a daemon thread so it doesn't block the main app
    http_thread = threading.Thread(target=start_http_server, daemon=True)
    http_thread.start()
    load_ugc_database()
    load_ugc_to_fips_map()

    # Check and finalize previous day's summary if needed
    check_and_finalize_previous_day()

    load_alerts_from_disk()
    await initial_api_state_load()


    asyncio.create_task(background_cleanup_task())
    asyncio.create_task(periodic_state_save_task())  # Periodic save of alerts and stats
    asyncio.create_task(watch_config_file())
    asyncio.create_task(poll_google_chat_messages())
    asyncio.create_task(poll_storm_threat_data())
    asyncio.create_task(poll_earthquake_data())  # Start earthquake polling
    asyncio.create_task(daily_summary_scheduler())  # Start daily recap scheduler


    if _RESTART_INTERVAL_HOURS > 0:
        asyncio.create_task(check_for_restart())
    
    
    async with websockets.serve(client_handler, WEBSOCKET_HOST, WEBSOCKET_PORT):
        print(f"✅ WebSocket server started on ws://{WEBSOCKET_HOST}:{WEBSOCKET_PORT}")

        if config.get("alert_source") == "nws_api":
            print("✅ Running in NWS API mode.")
            await poll_nws_api()
        else:
            print("✅ Running in NWWS (XMPP) mode.")
            jid = f"{NWWS_USERNAME}@nwws-oi.weather.gov"
            xmpp = NWWSBot(jid, NWWS_PASSWORD)
            xmpp.register_plugin('xep_0045')
            xmpp.connect()
            await asyncio.Event().wait()

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format='%(levelname)-8s %(message)s')
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nShutting down...")