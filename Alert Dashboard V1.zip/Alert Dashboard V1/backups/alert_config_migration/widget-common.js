/**
 * widget-common.js
 * Shared utilities and constants for all weather alert widgets
 *
 * This file provides common functionality to reduce code duplication
 * and ensure consistency across all widgets.
 */

// ==================================================================================
// CONSTANTS
// ==================================================================================

/**
 * Map of weather phenomenon codes to display names and icons
 */
const ALERT_TYPE_MAP = {
    // Warnings
    "TO": { name: "Tornado Warning", icon: "fa-wind" },
    "SV": { name: "Severe T-Storm Warning", icon: "fa-cloud-bolt" },
    "SVR": { name: "Severe T-Storm Warning", icon: "fa-cloud-bolt" },
    "FF": { name: "Flash Flood Warning", icon: "fa-cloud-showers-heavy" },
    "FFW": { name: "Flash Flood Warning", icon: "fa-cloud-showers-heavy" },
    "SPS": { name: "Special Weather Statement", icon: "fa-info-circle" },

    // Watches
    "TOA": { name: "Tornado Watch", icon: "fa-wind" },
    "SVA": { name: "Severe Thunderstorm Watch", icon: "fa-cloud-bolt" },
    "FFA": { name: "Flash Flood Watch", icon: "fa-cloud-showers-heavy" },

    // Winter Weather
    "WSA": { name: "Winter Storm Watch", icon: "fa-snowflake" },
    "WSW": { name: "Winter Storm Warning", icon: "fa-snowflake" },
    "SQW": { name: "Snow Squall Warning", icon: "fa-wind" },
    "WW": { name: "Winter Weather Advisory", icon: "fa-snowflake" },
    "WWY": { name: "Winter Weather Advisory", icon: "fa-snowflake" }
};

/**
 * Map of state abbreviations to full state names
 */
const STATE_MAP = {
    'AL': 'Alabama', 'AK': 'Alaska', 'AZ': 'Arizona', 'AR': 'Arkansas',
    'CA': 'California', 'CO': 'Colorado', 'CT': 'Connecticut', 'DE': 'Delaware',
    'FL': 'Florida', 'GA': 'Georgia', 'HI': 'Hawaii', 'ID': 'Idaho',
    'IL': 'Illinois', 'IN': 'Indiana', 'IA': 'Iowa', 'KS': 'Kansas',
    'KY': 'Kentucky', 'LA': 'Louisiana', 'ME': 'Maine', 'MD': 'Maryland',
    'MA': 'Massachusetts', 'MI': 'Michigan', 'MN': 'Minnesota', 'MS': 'Mississippi',
    'MO': 'Missouri', 'MT': 'Montana', 'NE': 'Nebraska', 'NV': 'Nevada',
    'NH': 'New Hampshire', 'NJ': 'New Jersey', 'NM': 'New Mexico', 'NY': 'New York',
    'NC': 'North Carolina', 'ND': 'North Dakota', 'OH': 'Ohio', 'OK': 'Oklahoma',
    'OR': 'Oregon', 'PA': 'Pennsylvania', 'RI': 'Rhode Island', 'SC': 'South Carolina',
    'SD': 'South Dakota', 'TN': 'Tennessee', 'TX': 'Texas', 'UT': 'Utah',
    'VT': 'Vermont', 'VA': 'Virginia', 'WA': 'Washington', 'WV': 'West Virginia',
    'WI': 'Wisconsin', 'WY': 'Wyoming',
    'AS': 'American Samoa', 'DC': 'District of Columbia', 'FM': 'Micronesia',
    'GU': 'Guam', 'MH': 'Marshall Islands', 'MP': 'Northern Mariana Islands',
    'PW': 'Palau', 'PR': 'Puerto Rico', 'VI': 'U.S. Virgin Islands'
};

/**
 * Map of phenomenon codes to Leaflet polygon styles for map display
 */
const ALERT_STYLE_MAP = {
    TO: { color: "#f7768e", weight: 3, fillOpacity: 0.5 },
    SV: { color: "#e0af68", weight: 2, fillOpacity: 0.5 },
    SVR: { color: "#e0af68", weight: 2, fillOpacity: 0.5 },
    FF: { color: "#9ece6a", weight: 2, fillOpacity: 0.5 },
    FFW: { color: "#9ece6a", weight: 2, fillOpacity: 0.5 },
    SPS: { color: "#7dcfff", weight: 1, dashArray: "5, 5", fillOpacity: 0.4 },
    TOA: { color: "#f7768e", weight: 3, fillOpacity: 0.2 },
    SVA: { color: "#e0af68", weight: 2, fillOpacity: 0.2 },
    FFA: { color: "#9ece6a", weight: 2, fillOpacity: 0.2 },
    WSA: { color: "#4682B4", weight: 2, fillOpacity: 0.2 },
    WSW: { color: "#bb9af7", weight: 3, fillOpacity: 0.5 },
    SQW: { color: "#C71585", weight: 3, fillOpacity: 0.5 },
    WW: { color: "#7B68EE", weight: 2, fillOpacity: 0.4 },
    WWY: { color: "#7B68EE", weight: 2, fillOpacity: 0.4 },
    DEFAULT: { color: "#7dcfff", weight: 2, fillOpacity: 0.3 }
};

// ==================================================================================
// UTILITY FUNCTIONS
// ==================================================================================

/**
 * Gets formatted display information for an alert
 * Handles emergency alerts, damage threats, and state name extraction
 *
 * @param {Object} alert - The alert object
 * @returns {Object} Object with name, icon, and stateName properties
 */
function getAlertDisplayInfo(alert) {
    let info = {
        ...(ALERT_TYPE_MAP[alert.phenomenon] || { name: alert.phenomenon, icon: 'fa-exclamation-triangle' }),
        stateName: ''
    };

    let threatPrefix = '';

    // Handle emergency alerts
    if (alert.is_emergency) {
        info.name = alert.phenomenon === 'TO' ? "Tornado Emergency" : "Flash Flood Emergency";
    } else {
        // Add damage threat prefix
        if (alert.damage_threat === 'DESTRUCTIVE' || alert.damage_threat === 'CATASTROPHIC') {
            threatPrefix = `${alert.damage_threat} `;
        } else if (alert.damage_threat === 'CONSIDERABLE') {
            threatPrefix = `CONSIDERABLE `;
        }
        info.name = threatPrefix + info.name;

        // Add "Observed" prefix for confirmed tornadoes
        if (alert.tornado_observed && alert.phenomenon === 'TO') {
            info.name = "Observed " + info.name;
        }
    }

    // Extract state name from alert data
    if (alert.affected_areas && alert.affected_areas.length > 0) {
        const stateAbbr = alert.affected_areas[0].substring(0, 2).toUpperCase();
        info.stateName = STATE_MAP[stateAbbr];
    } else if (alert.display_locations) {
        const match = alert.display_locations.match(/,\s*([A-Z]{2})/);
        if (match) info.stateName = STATE_MAP[match[1].toUpperCase()];
    }

    return info;
}

/**
 * Formats an alert expiration time as a readable string
 *
 * @param {string} expirationTime - ISO 8601 datetime string
 * @returns {string} Formatted time string (e.g., "3:45 PM") or "N/A"
 */
function formatExpirationTime(expirationTime) {
    if (!expirationTime) return 'N/A';

    try {
        return new Date(expirationTime).toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit'
        });
    } catch (e) {
        console.error('Error formatting expiration time:', e);
        return 'N/A';
    }
}

/**
 * Creates a WebSocket connection with automatic reconnection
 *
 * @param {string} url - WebSocket URL (typically CONFIG.websocket_url)
 * @param {Object} handlers - Object containing handler functions
 * @param {Function} handlers.onMessage - Called when message received (required)
 * @param {Function} [handlers.onOpen] - Called when connection opens
 * @param {Function} [handlers.onClose] - Called when connection closes
 * @param {Function} [handlers.onError] - Called on error
 * @param {number} [reconnectDelay=5000] - Milliseconds to wait before reconnecting
 * @returns {WebSocket} The WebSocket instance
 */
function createWebSocketConnection(url, handlers, reconnectDelay = 5000) {
    let socket;

    function connect() {
        try {
            socket = new WebSocket(url);

            socket.onopen = () => {
                console.log(`WebSocket connected to ${url}`);
                if (handlers.onOpen) handlers.onOpen();
            };

            socket.onclose = (event) => {
                console.log(`WebSocket closed. Reconnecting in ${reconnectDelay}ms...`);
                if (handlers.onClose) handlers.onClose(event);
                setTimeout(connect, reconnectDelay);
            };

            socket.onerror = (error) => {
                console.error('WebSocket error:', error);
                if (handlers.onError) handlers.onError(error);
                socket.close();
            };

            socket.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    handlers.onMessage(data);
                } catch (e) {
                    console.error('Error parsing WebSocket message:', e);
                }
            };
        } catch (e) {
            console.error('Error creating WebSocket:', e);
            setTimeout(connect, reconnectDelay);
        }
    }

    connect();
    return socket;
}

/**
 * Gets the Leaflet style for an alert's polygon
 *
 * @param {string} phenomenon - The alert phenomenon code (e.g., "TO", "SVR")
 * @returns {Object} Leaflet style object with color, weight, fillOpacity
 */
function getAlertStyle(phenomenon) {
    return ALERT_STYLE_MAP[phenomenon] || ALERT_STYLE_MAP.DEFAULT;
}

/**
 * Calculates the centroid of a polygon
 *
 * @param {Array} polygon - Array of [lat, lng] coordinate pairs
 * @returns {Array} [lat, lng] of the centroid
 */
function getPolygonCentroid(polygon) {
    if (!polygon || polygon.length === 0) return null;

    let latSum = 0;
    let lngSum = 0;

    polygon.forEach(coord => {
        latSum += coord[0];
        lngSum += coord[1];
    });

    return [latSum / polygon.length, lngSum / polygon.length];
}

// ==================================================================================
// THEME MANAGEMENT
// ==================================================================================

/**
 * Available widget themes
 */
const AVAILABLE_THEMES = ['classic', 'atmospheric', 'storm-chaser', 'meteorologist', 'winter'];

/**
 * Current active theme (defaults to classic)
 */
let currentWidgetTheme = 'storm-chaser';

/**
 * Applies a theme to the widget
 * Works for both ticker-specific and general widget themes
 *
 * @param {string} themeName - Name of the theme to apply
 * @param {string} [themeType='widget'] - Type of theme ('widget' or 'ticker')
 */
function applyWidgetTheme(themeName, themeType = 'widget') {
    if (!themeName) {
        console.warn('No theme name provided');
        return;
    }

    if (!AVAILABLE_THEMES.includes(themeName)) {
        console.warn(`Unknown theme: ${themeName}, available themes:`, AVAILABLE_THEMES);
        return;
    }

    console.log(`Applying widget theme: ${themeName}, current: ${currentWidgetTheme}`);

    const body = document.body;
    const html = document.documentElement;
    const prefix = themeType === 'ticker' ? 'ticker-theme-' : 'theme-';

    // Remove all theme classes from body and html
    AVAILABLE_THEMES.forEach(theme => {
        body.classList.remove(`${prefix}${theme}`);
        html.classList.remove(`${prefix}${theme}`);
        // Also remove the other type's prefix
        const otherPrefix = themeType === 'ticker' ? 'theme-' : 'ticker-theme-';
        body.classList.remove(`${otherPrefix}${theme}`);
        html.classList.remove(`${otherPrefix}${theme}`);
    });

    // Add new theme class
    body.classList.add(`${prefix}${themeName}`);
    html.classList.add(`${prefix}${themeName}`);
    console.log(`Added classes: ${prefix}${themeName} to body and html`);

    // Enable/disable theme stylesheets
    AVAILABLE_THEMES.forEach(theme => {
        // Check both ticker and widget theme stylesheet IDs
        const tickerLinkElement = document.getElementById(`ticker-theme-${theme}`);
        const widgetLinkElement = document.getElementById(`widget-theme-${theme}`);

        if (tickerLinkElement) {
            tickerLinkElement.disabled = (theme !== themeName);
            console.log(`Ticker theme ${theme}: ${tickerLinkElement.disabled ? 'disabled' : 'enabled'}`);
        }
        if (widgetLinkElement) {
            widgetLinkElement.disabled = (theme !== themeName);
            console.log(`Widget theme ${theme}: ${widgetLinkElement.disabled ? 'disabled' : 'enabled'}`);
        }
    });

    currentWidgetTheme = themeName;
    console.log(`✓ Widget theme successfully applied: ${themeName}`);
}

/**
 * Gets the current widget theme
 *
 * @returns {string} Current theme name
 */
function getCurrentWidgetTheme() {
    return currentWidgetTheme;
}

/**
 * Initializes theme support for a widget
 * Looks for theme in WebSocket data or uses default
 *
 * @param {Object} data - WebSocket message data
 * @param {string} [defaultTheme='classic'] - Default theme if none specified
 * @param {string} [themeType='widget'] - Type of theme ('widget' or 'ticker')
 */
function initializeWidgetTheme(data, defaultTheme = 'classic', themeType = 'widget') {
    // Check for theme in various possible properties
    const theme = data.widget_theme || data.ticker_theme || data.theme || defaultTheme;
    applyWidgetTheme(theme, themeType);
}
