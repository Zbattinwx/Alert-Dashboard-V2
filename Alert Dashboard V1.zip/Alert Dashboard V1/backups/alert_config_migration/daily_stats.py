# daily_stats.py
# ==================================================================================
# DAILY STATISTICS TRACKER MODULE
# ==================================================================================
# Tracks weather alerts, storm reports, and notable events throughout each day.
# Generates comprehensive daily summaries at midnight and monthly aggregates.
# ==================================================================================

import json
import os
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from collections import defaultdict
import pytz


class DailyStatsTracker:
    """
    Tracks daily weather statistics including alerts issued, storm reports,
    and notable events (tornado observed, significant winds).
    """

    def __init__(self, base_dir: str = "daily_summaries", timezone: str = "America/New_York"):
        """
        Initialize the daily stats tracker.

        Args:
            base_dir: Base directory for storing summary files
            timezone: Timezone for daily boundaries (default: America/New_York for Eastern)
        """
        self.base_dir = base_dir
        self.daily_dir = os.path.join(base_dir, "daily")
        self.monthly_dir = os.path.join(base_dir, "monthly")

        # Set timezone for daily boundaries
        self.timezone = pytz.timezone(timezone)

        # Create directories if they don't exist
        os.makedirs(self.daily_dir, exist_ok=True)
        os.makedirs(self.monthly_dir, exist_ok=True)

        # Initialize current day tracking (using local timezone)
        self.current_date = datetime.now(self.timezone).strftime('%Y-%m-%d')

        # Setup file logger for stats tracking
        self._setup_logger()

        self.reset_for_new_day()

    def _setup_logger(self):
        """Setup a dedicated file logger for daily stats tracking."""
        # Create logs directory if it doesn't exist
        os.makedirs("logs", exist_ok=True)

        # Create logger
        self.logger = logging.getLogger('DailyStats')
        self.logger.setLevel(logging.DEBUG)

        # Remove any existing handlers to avoid duplicates
        self.logger.handlers.clear()

        # Create file handler - one file per day
        log_filename = f"logs/daily_stats_{self.current_date}.log"
        file_handler = logging.FileHandler(log_filename, encoding='utf-8')
        file_handler.setLevel(logging.DEBUG)

        # Create formatter
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)

        # Add handler to logger
        self.logger.addHandler(file_handler)

        self.logger.info(f"Daily stats tracker initialized for {self.current_date}")

    def reset_for_new_day(self):
        """Reset all counters and lists for a new day."""
        self.alerts_issued = defaultdict(int)  # {phenomenon: count}
        self.storm_reports = defaultdict(int)  # {type: count}
        self.tornado_warnings_observed = []    # List of observed tornado warnings
        self.significant_wind_events = []      # List of significant wind events
        self.tracked_product_ids = set()       # Prevent double-counting alerts

    def record_alert(self, alert) -> bool:
        """
        Record a new alert issuance.

        Args:
            alert: Alert object to record

        Returns:
            True if alert was recorded, False if it was skipped (duplicate/update)
        """
        # Skip updates, cancellations, and duplicates
        if alert.is_update:
            msg = f"Skipping update/continuation: {alert.product_id} ({alert.phenomenon})"
            print(f"[STATS] {msg}")
            self.logger.info(msg)
            return False

        if alert.is_cancellation:
            msg = f"Skipping cancellation: {alert.product_id} ({alert.phenomenon})"
            print(f"[STATS] {msg}")
            self.logger.info(msg)
            return False

        if alert.product_id in self.tracked_product_ids:
            msg = f"Skipping duplicate: {alert.product_id} ({alert.phenomenon}) - already tracked"
            print(f"[STATS] {msg}")
            self.logger.warning(msg)
            return False

        # Record this alert
        msg = f"Recording NEW alert: {alert.product_id} ({alert.phenomenon})"
        print(f"[STATS] ✅ {msg}")
        self.logger.info(f"✓ {msg}")
        self.tracked_product_ids.add(alert.product_id)
        self.alerts_issued[alert.phenomenon] += 1

        # Check for tornado warnings with OBSERVED tag
        if alert.phenomenon == "TO" and alert.tornado_observed:
            self.tornado_warnings_observed.append({
                "product_id": alert.product_id,
                "location": alert.display_locations or "Unknown",
                "time": alert.issue_time.isoformat() if alert.issue_time else datetime.now().isoformat(),
                "issuing_office": alert.issuing_office or "Unknown"
            })

        # Check for CONSIDERABLE or CATASTROPHIC damage threats (high wind warnings)
        if alert.damage_threat in ["CONSIDERABLE", "CATASTROPHIC"]:
            self.significant_wind_events.append({
                "location": alert.display_locations or "Unknown",
                "value": f"{alert.damage_threat} DAMAGE THREAT",
                "time": alert.issue_time.isoformat() if alert.issue_time else datetime.now().isoformat(),
                "source": "alert",
                "type": "threat_tag",
                "product_id": alert.product_id,
                "phenomenon": alert.phenomenon
            })

        return True

    def record_storm_report(self, report: dict) -> bool:
        """
        Record a storm report (LSR).

        Args:
            report: Dictionary containing report data with keys:
                    - type: Report type (tornado, wind, hail, flood, etc.)
                    - magnitude: Value (e.g., wind speed)
                    - location: Location string
                    - time: Timestamp
                    - geometry: GeoJSON geometry (optional)

        Returns:
            True if report was recorded
        """
        report_type = report.get('type', 'unknown').lower()

        # Increment report count
        self.storm_reports[report_type] += 1

        # Track significant wind reports (≥ 50 MPH)
        if report_type == 'wind':
            magnitude_str = report.get('magnitude', '')

            # Try to extract numeric wind speed
            try:
                # Handle formats like "68 MPH", "68", "M68"
                wind_speed = None
                if 'MPH' in magnitude_str.upper():
                    wind_speed = int(magnitude_str.upper().split('MPH')[0].strip())
                elif magnitude_str.startswith('M'):
                    wind_speed = int(magnitude_str[1:])
                else:
                    wind_speed = int(magnitude_str)

                if wind_speed >= 50:
                    self.significant_wind_events.append({
                        "location": report.get('location', 'Unknown'),
                        "value": f"{wind_speed} MPH",
                        "time": report.get('time', datetime.now().isoformat()),
                        "source": "lsr",
                        "type": "measured",
                        "wind_speed_mph": wind_speed
                    })
            except (ValueError, TypeError):
                # Could not parse wind speed, skip
                pass

        return True

    def generate_summary(self) -> dict:
        """
        Generate a summary of the current day's statistics.

        Returns:
            Dictionary containing all tracked statistics
        """
        # Calculate totals
        total_alerts = sum(self.alerts_issued.values())
        total_reports = sum(self.storm_reports.values())

        # Sort wind events by speed (if available) or by time
        sorted_wind_events = sorted(
            self.significant_wind_events,
            key=lambda x: x.get('wind_speed_mph', 0),
            reverse=True
        )

        return {
            "date": self.current_date,
            "day_of_week": datetime.strptime(self.current_date, '%Y-%m-%d').strftime('%A'),
            "alerts_issued": dict(self.alerts_issued),
            "storm_reports": dict(self.storm_reports),
            "notable_events": {
                "tornado_warnings_observed": self.tornado_warnings_observed,
                "significant_wind_events": sorted_wind_events
            },
            "totals": {
                "total_alerts": total_alerts,
                "total_reports": total_reports,
                "tornado_warnings_observed": len(self.tornado_warnings_observed),
                "significant_wind_events": len(self.significant_wind_events)
            }
        }

    def save_daily_summary(self, date: Optional[str] = None) -> str:
        """
        Save the current day's summary to JSON and text files.

        Args:
            date: Date to save (YYYY-MM-DD). If None, uses current_date.

        Returns:
            Path to the saved JSON file
        """
        if date is None:
            date = self.current_date

        summary = self.generate_summary()
        summary['date'] = date  # Ensure correct date

        # Save JSON file
        json_path = os.path.join(self.daily_dir, f"summary_{date}.json")
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(summary, f, indent=2)

        # Save human-readable text file
        text_path = os.path.join(self.daily_dir, f"summary_{date}.txt")
        with open(text_path, 'w', encoding='utf-8') as f:
            f.write(self._format_summary_text(summary))

        # Update monthly aggregate
        self._update_monthly_aggregate(date, summary)

        msg = f"Daily summary saved for {date}: {summary['totals']['total_alerts']} total alerts"
        print(f"✅ {msg}")
        self.logger.info(msg)

        # Log breakdown
        for phenom, count in sorted(summary['alerts_issued'].items(), key=lambda x: x[1], reverse=True):
            self.logger.info(f"  {phenom}: {count}")

        return json_path

    def _format_summary_text(self, summary: dict) -> str:
        """
        Format summary as human-readable text.

        Args:
            summary: Summary dictionary

        Returns:
            Formatted text string
        """
        lines = []
        lines.append("=" * 80)
        lines.append(f"DAILY WEATHER SUMMARY - {summary['date']} ({summary['day_of_week']})")
        lines.append("=" * 80)
        lines.append("")

        # Alerts Issued
        lines.append("ALERTS ISSUED (First Issuance Only):")
        alerts = summary['alerts_issued']
        if alerts:
            # Define alert names
            alert_names = {
                'TO': 'Tornado Warnings',
                'SV': 'Severe Thunderstorm Warnings',
                'FF': 'Flash Flood Warnings',
                'SPS': 'Special Weather Statements',
                'TOA': 'Tornado Watches',
                'SVA': 'Severe Thunderstorm Watches',
                'WSW': 'Winter Storm Warnings',
                'WW': 'Winter Weather Advisories',
                'SS': 'Storm Surge Warnings',
                'SQW': 'Snow Squall Warnings'
            }

            for phenom, count in sorted(alerts.items(), key=lambda x: x[1], reverse=True):
                name = alert_names.get(phenom, phenom)
                lines.append(f"  • {name}: {count}")

            lines.append("  " + "─" * 40)
            lines.append(f"  TOTAL ALERTS: {summary['totals']['total_alerts']}")
        else:
            lines.append("  No alerts issued")

        lines.append("")

        # Storm Reports
        lines.append("STORM REPORTS:")
        reports = summary['storm_reports']
        if reports:
            report_names = {
                'tornado': 'Tornado Reports',
                'wind': 'Wind Reports',
                'hail': 'Hail Reports',
                'flood': 'Flood Reports',
                'marine': 'Marine Reports',
                'snow': 'Snow Reports'
            }

            for rtype, count in sorted(reports.items(), key=lambda x: x[1], reverse=True):
                name = report_names.get(rtype, rtype.title() + ' Reports')
                lines.append(f"  • {name}: {count}")

            lines.append("  " + "─" * 40)
            lines.append(f"  TOTAL REPORTS: {summary['totals']['total_reports']}")
        else:
            lines.append("  No storm reports")

        lines.append("")

        # Notable Events
        lines.append("NOTABLE EVENTS:")
        lines.append("")

        # Tornado warnings with OBSERVED
        tornado_observed = summary['notable_events']['tornado_warnings_observed']
        if tornado_observed:
            lines.append("  Tornado Warnings with OBSERVED Tag:")
            for event in tornado_observed:
                time_str = self._format_time(event['time'])
                lines.append(f"    ✓ {event['location']} - {time_str} ({event['product_id']})")
        else:
            lines.append("  No tornado warnings with OBSERVED tag")

        lines.append("")

        # Significant wind events
        wind_events = summary['notable_events']['significant_wind_events']
        if wind_events:
            lines.append(f"  Significant Wind Events (≥ 50 MPH or High Threat): {len(wind_events)} total")
            # Show top 15
            for event in wind_events[:15]:
                time_str = self._format_time(event['time'])
                source_str = "LSR" if event['source'] == 'lsr' else f"Alert ({event.get('product_id', 'N/A')})"
                lines.append(f"    • {event['location']}: {event['value']} at {time_str} [{source_str}]")

            if len(wind_events) > 15:
                lines.append(f"    ... and {len(wind_events) - 15} more")
        else:
            lines.append("  No significant wind events")

        lines.append("")
        lines.append("=" * 80)

        return "\n".join(lines)

    def _format_time(self, iso_time: str) -> str:
        """Format ISO timestamp to readable time."""
        try:
            dt = datetime.fromisoformat(iso_time.replace('Z', '+00:00'))
            return dt.strftime('%I:%M %p %Z').replace('  ', ' ')
        except:
            return iso_time

    def _update_monthly_aggregate(self, date: str, daily_summary: dict):
        """
        Update the monthly aggregate statistics.

        Args:
            date: Date in YYYY-MM-DD format
            daily_summary: The daily summary to add to monthly stats
        """
        month = date[:7]  # Extract YYYY-MM
        monthly_path = os.path.join(self.monthly_dir, f"summary_{month}.json")

        # Load existing monthly data or create new
        if os.path.exists(monthly_path):
            with open(monthly_path, 'r', encoding='utf-8') as f:
                monthly_data = json.load(f)
        else:
            dt = datetime.strptime(month, '%Y-%m')
            monthly_data = {
                "month": month,
                "month_name": dt.strftime('%B %Y'),
                "daily_summaries": [],
                "totals": {
                    "total_alerts": 0,
                    "total_reports": 0,
                    "tornado_warnings_observed": 0,
                    "significant_wind_events": 0
                },
                "alerts_by_type": {},
                "reports_by_type": {}
            }

        # Add/update daily entry
        daily_entry = {
            "date": date,
            "total_alerts": daily_summary['totals']['total_alerts'],
            "total_reports": daily_summary['totals']['total_reports'],
            "notable_event_count": (
                daily_summary['totals']['tornado_warnings_observed'] +
                daily_summary['totals']['significant_wind_events']
            )
        }

        # Remove existing entry for this date if present (for updates)
        monthly_data['daily_summaries'] = [
            d for d in monthly_data['daily_summaries'] if d['date'] != date
        ]
        monthly_data['daily_summaries'].append(daily_entry)
        monthly_data['daily_summaries'].sort(key=lambda x: x['date'])

        # Recalculate monthly totals
        monthly_data['totals']['total_alerts'] = sum(
            d['total_alerts'] for d in monthly_data['daily_summaries']
        )
        monthly_data['totals']['total_reports'] = sum(
            d['total_reports'] for d in monthly_data['daily_summaries']
        )

        # Aggregate alerts by type
        for phenom, count in daily_summary['alerts_issued'].items():
            monthly_data['alerts_by_type'][phenom] = (
                monthly_data['alerts_by_type'].get(phenom, 0) + count
            )

        # Aggregate reports by type
        for rtype, count in daily_summary['storm_reports'].items():
            monthly_data['reports_by_type'][rtype] = (
                monthly_data['reports_by_type'].get(rtype, 0) + count
            )

        # Update notable events count
        monthly_data['totals']['tornado_warnings_observed'] += daily_summary['totals']['tornado_warnings_observed']
        monthly_data['totals']['significant_wind_events'] += daily_summary['totals']['significant_wind_events']

        # Find busiest day
        if monthly_data['daily_summaries']:
            busiest = max(monthly_data['daily_summaries'], key=lambda x: x['total_alerts'])
            monthly_data['totals']['busiest_day'] = busiest['date']
            monthly_data['totals']['busiest_day_alerts'] = busiest['total_alerts']

        # Save updated monthly file
        with open(monthly_path, 'w', encoding='utf-8') as f:
            json.dump(monthly_data, f, indent=2)

        print(f"✅ Monthly aggregate updated: {monthly_path}")

    def load_daily_summary(self, date: str) -> Optional[dict]:
        """
        Load a daily summary from disk.

        Args:
            date: Date in YYYY-MM-DD format

        Returns:
            Summary dictionary or None if not found
        """
        json_path = os.path.join(self.daily_dir, f"summary_{date}.json")
        if os.path.exists(json_path):
            with open(json_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return None

    def load_recent_summaries(self, days: int = 7) -> List[dict]:
        """
        Load the most recent daily summaries.

        Args:
            days: Number of days to load

        Returns:
            List of summary dictionaries, most recent first
        """
        summaries = []
        for i in range(1, days + 1):
            date = (datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d')
            summary = self.load_daily_summary(date)
            if summary:
                summaries.append(summary)

        return summaries

    def load_monthly_summary(self, month: str) -> Optional[dict]:
        """
        Load a monthly aggregate summary.

        Args:
            month: Month in YYYY-MM format

        Returns:
            Monthly summary dictionary or None if not found
        """
        monthly_path = os.path.join(self.monthly_dir, f"summary_{month}.json")
        if os.path.exists(monthly_path):
            with open(monthly_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return None

    def save_state(self, filepath: str = "daily_stats_state.json"):
        """
        Save the current state of the tracker to a JSON file.
        This allows the tracker to persist across server restarts.

        Args:
            filepath: Path to save the state file
        """
        try:
            state = {
                "current_date": self.current_date,
                "alerts_issued": dict(self.alerts_issued),
                "storm_reports": dict(self.storm_reports),
                "tornado_warnings_observed": self.tornado_warnings_observed,
                "significant_wind_events": self.significant_wind_events,
                "tracked_product_ids": list(self.tracked_product_ids)
            }
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(state, f, indent=2)
            total_alerts = sum(self.alerts_issued.values())
            msg = f"State saved: {total_alerts} alerts tracked for {self.current_date}"
            print(f"[STATS] 💾 {msg}")
            self.logger.info(msg)
        except Exception as e:
            error_msg = f"Error saving daily stats state: {e}"
            print(f"❌ {error_msg}")
            self.logger.error(error_msg)

    def load_state(self, filepath: str = "daily_stats_state.json"):
        """
        Load the tracker state from a JSON file.
        This allows the tracker to resume after a server restart.

        Args:
            filepath: Path to the state file
        """
        if not os.path.exists(filepath):
            return

        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                state = json.load(f)

            # Only restore state if it's for the current date
            # If the date has changed, we should start fresh
            eastern = pytz.timezone('America/New_York')
            current_date_eastern = datetime.now(eastern).strftime('%Y-%m-%d')

            if state.get("current_date") == current_date_eastern:
                self.current_date = state["current_date"]
                self.alerts_issued = defaultdict(int, state.get("alerts_issued", {}))
                self.storm_reports = defaultdict(int, state.get("storm_reports", {}))
                self.tornado_warnings_observed = state.get("tornado_warnings_observed", [])
                self.significant_wind_events = state.get("significant_wind_events", [])
                self.tracked_product_ids = set(state.get("tracked_product_ids", []))
                msg = f"Restored daily stats state for {self.current_date}: {sum(self.alerts_issued.values())} alerts tracked"
                print(f"[STATS] {msg}")
                self.logger.info(msg)
            else:
                msg = f"Saved state is for {state.get('current_date')}, but today is {current_date_eastern}. Starting fresh."
                print(f"[STATS] {msg}")
                self.logger.info(msg)
        except Exception as e:
            error_msg = f"Error loading daily stats state: {e}"
            print(f"[STATS] {error_msg}")
            self.logger.error(error_msg)
            import traceback
            traceback.print_exc()


# Global instance
_daily_stats_tracker = None


def get_daily_stats_tracker() -> DailyStatsTracker:
    """
    Get or create the global daily stats tracker instance.
    On first initialization, attempts to load saved state from disk.
    """
    global _daily_stats_tracker
    if _daily_stats_tracker is None:
        _daily_stats_tracker = DailyStatsTracker()
        # Try to load saved state from previous run
        _daily_stats_tracker.load_state()
    return _daily_stats_tracker
