# Snow Report Visualization Features

## Overview
Enhanced the Local Storm Reports (LSR) system with improved snow report visualization, including snowflake icons, magnitude display, and an interactive snow accumulation heatmap.

## Features Implemented

### 1. Snowflake Icon for Snow Reports
- **Changed from:** Megaphone icon (generic report icon)
- **Changed to:** Snowflake icon (`fa-snowflake`)
- **Applies to:** "SNOW" and "HEAVY SNOW" report types
- **Color:** Purple (#d946ef) to match winter weather themes

### 2. Magnitude Display on Icons
- Snow reports now display the reported accumulation directly on the map icon
- Format: Shows inches with unit (e.g., "3.5in")
- Appears as a small label below the snowflake icon
- Only displays when magnitude data is available

### 3. Snow Accumulation Heatmap Mode
A toggleable visualization mode that shows snow totals using graduated circles instead of icons.

#### Toggle Button
- Location: Top-right corner of LSR map
- Button text: "Snow Totals" (icon mode) / "Snow Icons" (heatmap mode)
- Visual feedback: Button turns purple when heatmap mode is active

#### Heatmap Visualization
When enabled, snow reports are shown as:
- **Graduated circles** with radius proportional to accumulation amount
- **Color-coded by accumulation:**
  - Almost White Purple (#e9d5ff): Trace to 1"
  - Very Light Purple (#ddd6fe): 1-2"
  - Pale Purple (#c4b5fd): 2-4"
  - Light Purple (#f0abfc): 4-6"
  - Pink Purple (#e879f9): 6-8"
  - Bright Purple (#d946ef): 8-12"
  - Dark Purple (#8b008b): 12"+
- **Numeric labels** showing exact accumulation in inches
- **Interactive popups** with full report details (same as icon mode)

## How It Works

### Default Mode (Icon View)
- Snow reports appear as purple snowflake icons
- Magnitude is shown as a small label on each icon
- Standard clustering behavior applies
- Can be toggled on/off via layer control

### Heatmap Mode (Snow Totals View)
- Click "Snow Totals" button in top-right
- Regular snow icons are hidden
- Graduated circles appear, scaled and colored by accumulation
- Numeric labels show exact amounts
- Click "Snow Icons" to return to default view

## Technical Details

### Files Modified
1. **dashboard.js**
   - Added `SNOW` and `HEAVY SNOW` cases to LSR icon switch
   - Added `snowHeatmapLayer` and `snowHeatmapMode` global variables
   - Created `toggleSnowVisualization()` function
   - Enhanced `fetchLSRs()` to build both icon and heatmap layers
   - Added snow toggle control to `initializeLsrMap()`

2. **dashboard.css**
   - Added `.lsr-snow` class for snow icon styling
   - Added `.snow-magnitude` class for magnitude labels on icons
   - Added `.snow-amount-label` and `.snow-label-text` for heatmap labels
   - Added `.snow-toggle-btn` styles with hover and active states

### Color Scheme Rationale
- Uses purple tones to align with existing winter weather alert colors
- Gradient from light to dark purple indicates increasing accumulation
- High contrast labels ensure readability on all backgrounds

## User Benefits

1. **Immediate Visual Recognition:** Snowflake icon immediately identifies snow reports
2. **At-a-Glance Accumulation:** See exact amounts without opening popups
3. **Spatial Analysis:** Heatmap mode reveals accumulation patterns across regions
4. **Flexibility:** Toggle between detailed icons and overview visualization
5. **Consistency:** Matches the color scheme of winter weather alerts

## Future Enhancements (Potential)

- Add interpolation between snow reports for true heatmap
- Include time-series animation of accumulation
- Export snow total data for analysis
- Add contour lines for accumulation zones
- Filter by accumulation threshold (e.g., "Show only 4+ inches")
