document.addEventListener('DOMContentLoaded', () => {
    const WEBSOCKET_URL = CONFIG.websocket_url;
    const NEW_ALERT_DURATION_MS = 15000;
    const newAlertContainer = document.getElementById('new-alert-notification');
    let seenAlertProductIDs = new Set();

    const alertSound = document.getElementById('alertTone');

    function connect() {
        createWebSocketConnection(WEBSOCKET_URL, {
            onMessage: (data) => {
                // Apply theme from ANY message that contains it
                if (data.ticker_theme || data.widget_theme || data.theme) {
                    applyWidgetTheme(data.ticker_theme || data.widget_theme || data.theme, 'widget');
                }

                if (data.type === 'new_alert' && data.alert_data) {
                    showNewAlertNotification(data.alert_data);
                }
            }
        });
    }

    function showNewAlertNotification(alert) {
        const alertInfo = getAlertDisplayInfo(alert);
        document.getElementById('new-alert-title').textContent = `JUST ISSUED: ${alertInfo.name}`;
        document.getElementById('new-alert-location').textContent = alert.display_locations;
        newAlertContainer.className = `widget-container ${alert.phenomenon}`;
        if (alert.is_emergency) newAlertContainer.classList.add('EMERGENCY');
        newAlertContainer.classList.add('visible');

        const soundEnabled = localStorage.getItem('soundEnabled');
        if (alertSound && soundEnabled !== 'false') { // Defaults to ON if not set
            alertSound.play().catch(e => console.error("Error playing sound:", e));
        }
        
        setTimeout(() => newAlertContainer.classList.remove('visible'), NEW_ALERT_DURATION_MS);
    }

    connect();
});