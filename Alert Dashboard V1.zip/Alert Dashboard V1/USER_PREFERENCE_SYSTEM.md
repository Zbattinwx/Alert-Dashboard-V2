# User Preference System - Implementation Summary

## Overview
A browser-based user preference system has been implemented for the dashboard. Each user can now customize their dashboard settings without affecting other users.

## How It Works

### First Time Login (Per Browser)
1. User enters the dashboard password (`ONW2025!`)
2. System prompts for a username (one-time setup per browser)
3. Username is saved in browser's localStorage
4. User's preferences are now stored under their username

### Subsequent Logins
1. User enters the dashboard password
2. System automatically detects saved username
3. User's personalized settings are loaded
4. **No username prompt** (seamless experience)

## What's Saved Per User?

Each user has their own personalized settings for:
- **Sound notifications** (on/off)
- **Dashboard theme** (Classic, Atmospheric, Storm Chaser, Meteorologist, Winter)
- **Alert type filters** (which alert types to show)
- **State filters** (which states to show alerts for)
- **Mesoscale Discussion state filters** (MD filtering by state)

## Features Implemented

### 1. UserPreferences Class
- Manages all localStorage operations
- Stores data with user-specific keys
- Automatic migration of old global preferences
- Export/import functionality for backing up preferences

### 2. Automatic State Restoration
- When a user logs in, all their filters and settings are restored
- Filter buttons automatically show the correct active state
- Checkboxes are pre-checked based on saved preferences
- Theme is applied immediately

### 3. Console Commands
Power users can use these commands in the browser console:

```javascript
// See who you're logged in as
dashboardUser.whoami()

// Switch to a different user profile
dashboardUser.switchUser("NewUsername")

// Export your preferences (for backup)
const backup = dashboardUser.exportPreferences()

// Import preferences from backup
dashboardUser.importPreferences(backup)

// Show help
dashboardUser.help()
```

## Technical Details

### Storage Format
Preferences are stored in localStorage with keys like:
- `dashboard_global_current_user` - Current username
- `dashboard_user_John_soundEnabled` - John's sound preference
- `dashboard_user_Jane_selectedTheme` - Jane's theme preference
- `dashboard_user_John_activeFilters` - John's active alert filters

### Migration
Old global preferences (if they exist) are automatically migrated to the first user's profile on first login.

## Usage Examples

### Scenario 1: Multiple People, Same Computer
- **Person A** logs in first time → prompted for username → enters "Alex"
- Alex customizes filters and theme
- Alex logs out
- **Person B** logs in → uses same password → system still has "Alex" as user
- Person B can run `dashboardUser.switchUser("Bailey")` in console
- Now Bailey has their own separate preferences

### Scenario 2: One Person, Multiple Browsers
- **User** logs in on Chrome → prompted for username → enters "John"
- John sets up preferences
- **Same user** logs in on Firefox → prompted again → enters "John"
- Firefox now has John's settings (if using same computer and browser sync)
- Settings are browser/device specific

### Scenario 3: Resetting to Fresh Start
```javascript
// In console:
dashboardUser.switchUser("NewProfile_" + Date.now())
// Page reloads with clean slate
```

## Backup and Restore

### Created Backup
A full backup was created at:
`c:\Users\zbattin\Documents\WorkBranch\backups\user-system-backup-20251119-135418\`

This includes:
- `dashboard.js` (original version)
- `dashboard.css`
- `config.json`
- `RESTORE_INSTRUCTIONS.txt`

### To Restore Original Version
1. Stop the dashboard server
2. Copy files from backup folder to main WorkBranch directory
3. Restart server
4. Clear browser localStorage (F12 → Application → Local Storage → Clear)
5. Refresh browser

## Browser Compatibility
- Works in all modern browsers (Chrome, Firefox, Edge, Safari)
- Requires JavaScript localStorage support (available since IE8+)
- Each browser maintains its own user profile

## Limitations
- Settings are stored **per browser/device** (not synced across devices)
- If browser cache is cleared, username prompt will appear again
- Private/Incognito mode will always prompt for username

## Future Enhancements (Optional)
Possible improvements that could be added later:
- Server-side user database for cross-device sync
- User login with passwords (instead of shared dashboard password)
- User management panel in the dashboard UI
- Preference sharing between users
- Admin panel to manage users

## Testing Recommendations
1. Test login with new username
2. Change theme and filters
3. Refresh page - verify settings persist
4. Test `dashboardUser.switchUser("TestUser2")`
5. Verify different users have different settings
6. Test export/import functionality
