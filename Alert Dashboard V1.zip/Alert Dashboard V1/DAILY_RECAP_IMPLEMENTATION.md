# Daily Recap Feature - Implementation Plan

## Overview
Automated daily weather summary system that tracks alerts, storm reports, and notable events throughout each day, generating comprehensive summaries at midnight.

## Requirements Confirmed
- **Finalization Time**: Midnight (12:00 AM) local time
- **Time Zone**: Local time (Eastern Time)
- **Wind Gust Tracking**:
  - LSR wind reports ≥ 50 MPH
  - Thunderstorm warnings with CONSIDERABLE or CATASTROPHIC damage threat tags
- **History Retention**:
  - Last 7 days easily accessible in UI
  - Monthly aggregated statistics (for year-end comparison)
- **Section Name**: "Daily Recap"

---

## Data to Track

### 1. Alerts Issued (First Issuance Only)
- Count by phenomenon type: TO, SV, FF, SPS, TOA, SVA, WSW, WW, etc.
- Filter out updates/continuations (check `is_update` flag)
- Track unique `product_id` to prevent double-counting

### 2. Storm Reports by Type
- Tornado reports
- Wind reports (all speeds tracked)
- Hail reports
- Flood/flash flood reports
- Other report types

### 3. Notable Events
- **Tornado Warnings with OBSERVED Tag**:
  - Store: product_id, location, time, issuing_office

- **Significant Wind Events**:
  - LSR wind reports ≥ 50 MPH
  - Severe/Tornado warnings with CONSIDERABLE or CATASTROPHIC damage threat
  - Store: location, speed/threat level, time, source type

---

## File Structure

```
WorkBranch/
├── daily_stats.py                    # NEW: Core statistics tracking module
├── daily_summaries/                  # NEW: Summary storage directory
│   ├── daily/                        # Daily summaries
│   │   ├── summary_2025-10-22.json
│   │   ├── summary_2025-10-22.txt
│   │   └── summary_2025-10-23.json
│   └── monthly/                      # Monthly aggregated stats
│       ├── summary_2025-10.json
│       └── summary_2025-11.json
├── alert_manager.py                  # MODIFY: Add tracking hooks
├── main_app.py                       # MODIFY: Add WebSocket handlers & scheduler
├── dashboard.js                      # MODIFY: Add Daily Recap UI
├── dashboard.css                     # MODIFY: Add styling for recap section
└── index.html                        # MODIFY: Add menu item & section
```

---

## Implementation Phases

### Phase 1: Core Data Collection Module

#### File: `daily_stats.py`

**Class: `DailyStatsTracker`**

Properties:
```python
- current_date: str                    # YYYY-MM-DD format
- alerts_issued: dict[str, int]        # {phenomenon: count}
- storm_reports: dict[str, int]        # {type: count}
- tornado_warnings_observed: list[dict]
- significant_wind_events: list[dict]
- tracked_product_ids: set[str]        # Prevent double-counting
```

Methods:
```python
- record_alert(alert: Alert) -> None
  # Check if new (not in tracked_product_ids)
  # Skip if is_update or is_cancellation
  # Increment count for phenomenon type
  # Track tornado observed events
  # Track CONSIDERABLE/CATASTROPHIC warnings

- record_storm_report(report: dict) -> None
  # Increment count by report type
  # Track wind reports ≥ 50 MPH

- generate_summary() -> dict
  # Compile all statistics
  # Return structured summary dict

- save_daily_summary(date: str) -> None
  # Generate JSON summary file
  # Generate human-readable text file
  # Update monthly aggregate

- reset_for_new_day() -> None
  # Clear all counters and lists
  # Update current_date
  # Keep historical data reference
```

---

### Phase 2: Integration Points

#### 2.1 Alert Manager Integration (`alert_manager.py`)

Add to `AlertManager.add_alert()`:
```python
# After successfully adding new alert
if not alert.is_update and not alert.is_cancellation:
    daily_stats_tracker.record_alert(alert)
```

#### 2.2 LSR Tracking Integration (`main_app.py`)

Add to LSR ingestion:
```python
# When processing new LSR
daily_stats_tracker.record_storm_report(report)
```

#### 2.3 Manual LSR Tracking

Add to manual LSR submission:
```python
# When user submits manual report
daily_stats_tracker.record_storm_report(manual_report)
```

---

### Phase 3: Automated Scheduling

#### File: `main_app.py`

**Add Scheduler**:
```python
import schedule
import threading

def finalize_daily_summary():
    """Called at midnight to finalize previous day"""
    yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
    daily_stats_tracker.save_daily_summary(yesterday)
    daily_stats_tracker.reset_for_new_day()

# Schedule for midnight local time
schedule.every().day.at("00:00").do(finalize_daily_summary)

# Run scheduler in background thread
def run_scheduler():
    while True:
        schedule.run_pending()
        time.sleep(60)  # Check every minute

threading.Thread(target=run_scheduler, daemon=True).start()
```

**Startup Recovery**:
```python
# On app startup
def check_and_finalize_previous_day():
    """Check if yesterday's summary exists, create if missing"""
    yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
    summary_path = f"daily_summaries/daily/summary_{yesterday}.json"
    if not os.path.exists(summary_path):
        # Generate summary from available data
        daily_stats_tracker.finalize_previous_day(yesterday)
```

---

### Phase 4: Backend API (WebSocket Handlers)

#### Add to `main_app.py` WebSocket handler:

```python
elif data.get('type') == 'get_daily_summary':
    # Return current day's running statistics
    summary = daily_stats_tracker.generate_summary()
    await websocket.send(json.dumps({
        'type': 'daily_summary',
        'data': summary
    }))

elif data.get('type') == 'get_previous_day_summary':
    # Return yesterday's finalized summary
    yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
    summary = load_daily_summary(yesterday)
    await websocket.send(json.dumps({
        'type': 'previous_day_summary',
        'data': summary
    }))

elif data.get('type') == 'get_summary_history':
    # Return list of last 7 days
    days = data.get('days', 7)
    summaries = load_recent_summaries(days)
    await websocket.send(json.dumps({
        'type': 'summary_history',
        'data': summaries
    }))

elif data.get('type') == 'get_monthly_summary':
    # Return monthly aggregated stats
    month = data.get('month')  # Format: YYYY-MM
    summary = load_monthly_summary(month)
    await websocket.send(json.dumps({
        'type': 'monthly_summary',
        'data': summary
    }))
```

---

### Phase 5: Frontend UI

#### 5.1 Add Menu Item (`index.html`)

```html
<a href="#" class="menu-item" data-section="daily-recap-section">
  <i class="fas fa-calendar-day"></i> Daily Recap
</a>
```

#### 5.2 Add Dashboard Section (`index.html`)

```html
<section id="daily-recap-section" class="dashboard-section">
  <h2>Daily Recap</h2>

  <!-- Date selector for last 7 days -->
  <div id="recap-date-selector"></div>

  <!-- Summary display -->
  <div id="recap-summary-container">
    <!-- Alerts Issued -->
    <div class="recap-card">
      <h3>Alerts Issued</h3>
      <div id="recap-alerts-grid"></div>
      <div class="recap-total">Total: <span id="recap-total-alerts">0</span></div>
    </div>

    <!-- Storm Reports -->
    <div class="recap-card">
      <h3>Storm Reports</h3>
      <div id="recap-reports-grid"></div>
      <div class="recap-total">Total: <span id="recap-total-reports">0</span></div>
    </div>

    <!-- Notable Events -->
    <div class="recap-card">
      <h3>Notable Events</h3>
      <div id="recap-notable-events"></div>
    </div>
  </div>

  <!-- Monthly stats link -->
  <button id="view-monthly-stats-btn">View Monthly Statistics</button>
</section>
```

#### 5.3 JavaScript Functions (`dashboard.js`)

```javascript
// Request daily summary when section is opened
function loadDailyRecap(date = null) {
  const requestDate = date || getYesterdayDate();
  socket.send(JSON.stringify({
    type: 'get_previous_day_summary',
    date: requestDate
  }));
}

// Handle incoming summary data
function handleDailySummary(data) {
  renderAlertsIssued(data.alerts_issued);
  renderStormReports(data.storm_reports);
  renderNotableEvents(data.notable_events);
  updateTotals(data.totals);
}

// Render alerts issued grid
function renderAlertsIssued(alerts) {
  // Display count by phenomenon type with icons/colors
}

// Render storm reports
function renderStormReports(reports) {
  // Display count by report type
}

// Render notable events
function renderNotableEvents(events) {
  // List tornado warnings with OBSERVED tag
  // List significant wind events
}
```

---

## Data Structure Formats

### Daily Summary JSON
```json
{
  "date": "2025-10-22",
  "day_of_week": "Wednesday",
  "alerts_issued": {
    "TO": 5,
    "SV": 23,
    "FF": 3,
    "SPS": 12,
    "TOA": 2,
    "SVA": 1
  },
  "storm_reports": {
    "tornado": 2,
    "wind": 45,
    "hail": 18,
    "flood": 3
  },
  "notable_events": {
    "tornado_warnings_observed": [
      {
        "product_id": "TO.KILN.0045",
        "location": "Franklin, OH",
        "time": "2025-10-22T15:30:00-04:00",
        "issuing_office": "ILN"
      }
    ],
    "significant_wind_events": [
      {
        "location": "Columbus Airport",
        "value": "68 MPH",
        "time": "2025-10-22T16:15:00-04:00",
        "source": "lsr",
        "type": "measured"
      },
      {
        "location": "Delaware, OH",
        "value": "CONSIDERABLE DAMAGE THREAT",
        "time": "2025-10-22T16:20:00-04:00",
        "source": "alert",
        "type": "threat_tag",
        "product_id": "SV.KILN.0123"
      }
    ]
  },
  "totals": {
    "total_alerts": 46,
    "total_reports": 68,
    "tornado_warnings_observed": 1,
    "significant_wind_events": 12
  }
}
```

### Monthly Summary JSON
```json
{
  "month": "2025-10",
  "month_name": "October 2025",
  "daily_summaries": [
    {
      "date": "2025-10-22",
      "total_alerts": 46,
      "total_reports": 68,
      "notable_event_count": 13
    }
  ],
  "totals": {
    "total_alerts": 234,
    "total_reports": 456,
    "busiest_day": "2025-10-22",
    "tornado_warnings_observed": 5,
    "significant_wind_events": 67
  },
  "alerts_by_type": {
    "TO": 25,
    "SV": 156,
    "FF": 18,
    "SPS": 35
  },
  "reports_by_type": {
    "tornado": 8,
    "wind": 289,
    "hail": 134,
    "flood": 25
  }
}
```

---

## Implementation Steps (In Order)

### Step 1: Create `daily_stats.py`
- Define `DailyStatsTracker` class
- Implement all tracking methods
- Add summary generation logic
- Add file I/O for JSON and text formats

### Step 2: Create directory structure
```bash
mkdir -p daily_summaries/daily
mkdir -p daily_summaries/monthly
```

### Step 3: Integrate tracking into `alert_manager.py`
- Import `daily_stats` module
- Add tracking call in `add_alert()` method
- Ensure proper filtering of updates/cancellations

### Step 4: Add LSR tracking in `main_app.py`
- Track LSRs from API feed
- Track manual LSR submissions
- Filter for wind reports ≥ 50 MPH

### Step 5: Implement scheduler in `main_app.py`
- Add `schedule` library import
- Create midnight finalization function
- Add startup recovery check
- Start background scheduler thread

### Step 6: Add WebSocket handlers in `main_app.py`
- Handle `get_daily_summary` request
- Handle `get_previous_day_summary` request
- Handle `get_summary_history` request
- Handle `get_monthly_summary` request

### Step 7: Build frontend UI
- Add menu item in `index.html`
- Add dashboard section HTML
- Implement JavaScript functions in `dashboard.js`
- Add CSS styling for recap cards

### Step 8: Testing
- Test alert tracking (ensure no duplicates)
- Test LSR tracking
- Test tornado observed detection
- Test damage threat tracking
- Test midnight finalization (may need to adjust time for testing)
- Test UI display and date selection
- Test monthly aggregation

---

## Dependencies Required

```python
# Add to requirements.txt (if not already present)
schedule>=1.2.0  # For automated daily tasks
```

---

## Testing Checklist

- [ ] Alert tracking works (first issuance only)
- [ ] Updates/cancellations are properly filtered
- [ ] Storm reports are counted correctly
- [ ] Tornado OBSERVED tags are captured
- [ ] CONSIDERABLE/CATASTROPHIC damage threats are tracked
- [ ] Wind gusts ≥ 50 MPH from LSRs are tracked
- [ ] Daily summary files are created at midnight
- [ ] Monthly aggregates are updated
- [ ] UI displays previous day's summary correctly
- [ ] Date selector works for last 7 days
- [ ] Monthly view displays aggregated statistics
- [ ] App recovery works after restart

---

## Future Enhancements (Post-Implementation)

- Export summaries to PDF/CSV
- Email daily summary to distribution list
- Compare current day to historical averages
- Year-end "busiest day" / "busiest month" statistics
- Graphs/charts for monthly trends
- Integration with social media for automated posts

---

## Notes

- All times stored in ISO 8601 format with timezone
- File names use YYYY-MM-DD format for easy sorting
- Monthly files use YYYY-MM format
- Summary generation is idempotent (can be run multiple times)
- Startup recovery prevents lost data from app restarts
- Consider backup/archival strategy for long-term storage

---

**Status**: Ready to implement
**Last Updated**: 2025-10-22
**Implementation Started**: [To be filled in]
**Implementation Completed**: [To be filled in]
