# Storm Report IP Blocking System

## Overview

This system allows you to block IP addresses from submitting storm reports through the public [submit_report.html](submit_report.html) form. This is useful for preventing spam or abuse from bad actors making false reports.

## Features

- **IP-based blocking**: Block specific IP addresses from submitting reports
- **Automatic logging**: All blocked submission attempts are logged with details
- **Recent submissions monitoring**: View all recent successful submissions with IP addresses
- **Web-based admin interface**: Easy-to-use interface for managing the blocklist
- **Persistent storage**: Blocked IPs are stored in `blocked_ips.json`

## How It Works

### 1. Automatic IP Capture
When someone submits a storm report via [submit_report.html](submit_report.html), their IP address is automatically captured and stored with the report data.

### 2. IP Checking
Before accepting any submission, the server checks if the submitter's IP is on the blocklist. If blocked, the submission is rejected with a 403 Forbidden error.

### 3. Blocked Attempt Logging
Every blocked submission attempt is logged with:
- IP address
- Timestamp
- Report type
- Location
- Submitter name (if provided)

The system keeps the last 100 blocked attempts for review.

## Using the Admin Interface

### Access the Admin Panel
Navigate to:
```
https://atmosphericx.ddns.net:8000/admin_blocklist.html
```

### Dashboard Statistics
The admin panel shows:
- **Blocked IPs**: Total number of blocked IP addresses
- **Blocked Attempts**: Number of submission attempts from blocked IPs
- **Recent Submissions**: Count of recent successful submissions

### Blocking an IP

**Method 1: Manual Entry**
1. Enter the IP address in the "Block New IP Address" field
2. Click "Block IP"
3. The IP will be immediately added to the blocklist

**Method 2: From Recent Submissions**
1. Scroll to the "Recent Successful Submissions" section
2. Find the submission from the problematic user
3. Click the "Block This IP" button next to their submission
4. Confirm the action

### Unblocking an IP

1. Scroll to the "Currently Blocked IPs" section
2. Find the IP you want to unblock
3. Click the "Unblock" button
4. Confirm the action

### Monitoring

The admin interface auto-refreshes every 5 seconds, so you can:
- Watch for new submissions in real-time
- Monitor blocked submission attempts
- Track patterns of abuse

## Files

### [blocked_ips.json](blocked_ips.json)
Stores the blocklist data:
```json
{
    "blocked_ips": [
        "192.168.1.100",
        "10.0.0.50"
    ],
    "blocked_submissions": [
        {
            "ip": "192.168.1.100",
            "timestamp": "2025-12-03T12:34:56.789Z",
            "data": {
                "type": "TORNADO",
                "location": "Springfield, OH",
                "submitter": "BadActor"
            }
        }
    ]
}
```

**Note**: This file is in `.gitignore` and should not be committed to version control.

### [admin_blocklist.html](admin_blocklist.html)
The web-based admin interface for managing the blocklist.

### [main_app.py](main_app.py)
Contains the IP blocking logic:
- `load_blocked_ips()` - Load blocklist from file
- `save_blocked_ips()` - Save blocklist to file
- `is_ip_blocked()` - Check if an IP is blocked
- `add_blocked_ip()` - Add an IP to the blocklist
- `remove_blocked_ip()` - Remove an IP from the blocklist
- `log_blocked_submission()` - Log a blocked attempt

## API Endpoints

### GET /api/blocklist
Returns current blocklist data:
```json
{
    "blocked_ips": ["192.168.1.100"],
    "blocked_submissions": [...]
}
```

### GET /api/recent_submissions
Returns last 50 successful submissions:
```json
{
    "submissions": [
        {
            "id": "uuid",
            "typeText": "TORNADO",
            "location": "City, State",
            "submitter": "Name",
            "ip_address": "192.168.1.50",
            ...
        }
    ]
}
```

### POST /api/blocklist/add
Add an IP to the blocklist:
```json
{
    "ip": "192.168.1.100"
}
```

### POST /api/blocklist/remove
Remove an IP from the blocklist:
```json
{
    "ip": "192.168.1.100"
}
```

### POST /api/submit_storm_report
When a blocked IP tries to submit:
```json
{
    "error": "Your IP address has been blocked from submitting reports"
}
```
Response: **403 Forbidden**

## Security Considerations

### IP Spoofing
This system blocks by IP address. Note that:
- Users behind the same NAT/proxy share an IP (be careful blocking entire organizations)
- IP addresses can change (mobile users, ISP rotation)
- Advanced users can use VPNs/proxies to bypass IP blocks

### Recommended Practices
1. **Monitor before blocking**: Review multiple reports from an IP before blocking
2. **Document reasons**: Keep notes on why IPs were blocked
3. **Periodic review**: Regularly review the blocklist and remove stale entries
4. **Combine with reCAPTCHA**: The form already uses reCAPTCHA as a first line of defense

### Privacy
- IP addresses are considered personally identifiable information (PII)
- Store `blocked_ips.json` securely
- Do not share or publish IP addresses publicly
- Consider data retention policies for blocked IPs and logs

## Troubleshooting

### "IP already blocked" error
The IP is already in the blocklist. Check the "Currently Blocked IPs" section.

### "IP not found in blocklist" error
The IP you're trying to unblock doesn't exist in the blocklist.

### Admin page not loading
1. Ensure the server is running ([main_app.py](main_app.py))
2. Check that port 8000 is accessible
3. Verify [frontend_config.js](frontend_config.js) has the correct server URL

### Blocked IPs can still submit
1. Restart [main_app.py](main_app.py) to ensure the code changes are loaded
2. Verify the IP is correctly formatted (e.g., `192.168.1.100`)
3. Check server console for error messages

## Example Workflow

### Scenario: Someone is submitting fake tornado reports

1. **Identify the problem**:
   - Open [admin_blocklist.html](admin_blocklist.html)
   - Review "Recent Successful Submissions"
   - Notice multiple fake reports from IP `203.0.113.50`

2. **Block the IP**:
   - Click "Block This IP" next to one of their submissions
   - Confirm the action

3. **Verify**:
   - The IP now appears in "Currently Blocked IPs"
   - Future submissions from this IP will be rejected
   - Blocked attempts appear in "Recent Blocked Attempts"

4. **Later, if needed**:
   - If it was a mistake or the user apologizes, click "Unblock"
   - The IP can submit reports again

## Integration with Dashboard

Blocked submissions do NOT appear on:
- The main alert dashboard
- The storm report map
- Google Sheets (if integrated)

They are only logged in `blocked_ips.json` for administrative review.

## Future Enhancements

Potential improvements:
- Temporary blocks with automatic expiration
- Block by IP range (CIDR notation)
- Rate limiting (submissions per IP per hour)
- Email notifications for blocked attempts
- Reason tracking for each blocked IP
- Export blocklist to CSV
- Integration with external threat databases
