// alerts_embed.js
// ==================================================================================
// WEBSITE ALERT WIDGET - UPDATED FOR DYNAMIC CONFIG
// ==================================================================================

document.addEventListener("DOMContentLoaded", () => {
    // --- WebSocket and Global State ---
    const WEBSOCKET_URL = CONFIG.websocket_url;
    let socket;
    let activeAlertsCache = [];
    const activeFilters = new Set();
    let activeStateFilters = new Set();
    let odotCameraCache = [];
    const countyFipsMap = new Map();

    // --- DOM Elements ---
    const countersBar = document.getElementById("counters-bar");
    const lastCheckedEl = document.getElementById("lastChecked");
    const alertSourceEl = document.getElementById("alertSource");
    const filterControls = document.getElementById("filterControls");

    // --- Initialization ---
    async function init() {
        console.log("🚀 Initializing Embedded Alert Widget...");

        // 1. Apply Winter Mode
        if (CONFIG.winter_mode_enabled) {
            document.body.classList.add("winter-mode-active");
        }

        // 2. Load Global Alert Configuration (Colors, Types, Priorities)
        if (window.alertConfig) {
            try {
                await window.alertConfig.load();
            } catch (e) {
                console.error("⚠️ Failed to load alert config:", e);
            }
        }

        // 3. Initialize UI Components
        initializeStateFilters();
        setupEventListeners();
        
        // 4. Load Data
        fetchOdotCameras();
        await loadCountyData();

        // 5. Connect to WebSocket
        connect();
    }

    function connect() {
        socket = new WebSocket(WEBSOCKET_URL);

        socket.onopen = () => {
            if (alertSourceEl) alertSourceEl.textContent = "Connected";
        };

        socket.onclose = () => {
            console.log("❌ WebSocket disconnected. Reconnecting in 5s...");
            setTimeout(connect, 5000);
        };

        socket.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                if (data.type === "update") {
                    if (data.source && alertSourceEl) {
                        alertSourceEl.textContent = data.source.replace("_", " ").toUpperCase();
                    }
                    activeAlertsCache = data.alerts || [];
                    updateAllData(activeAlertsCache);
                }
            } catch (e) {
                console.error("Error processing message:", e);
            }
        };
    }

    function updateAllData(alerts) {
        updateCounters(alerts);
        updateAlertsGrid(alerts);
        updateCamerasInWarnings(alerts, odotCameraCache);
        if (lastCheckedEl) lastCheckedEl.textContent = new Date().toLocaleTimeString();
    }

    // --- Dynamic Counters ---
    function updateCounters(alerts) {
        if (!countersBar) return;

        // 1. Tally up raw counts by phenomenon code
        const rawCounts = {};
        alerts.forEach(alert => {
            const code = alert.phenomenon;
            rawCounts[code] = (rawCounts[code] || 0) + 1;
        });

        // 2. Define the EXACT counter structure with Styles
        // We include 'background' to force the colors even if CSS is missing
        const counterConfig = [
            { 
                id: 'toa', 
                title: 'Tornado Watch', 
                cssClass: 'tor-watch', 
                codes: ['TOA'],
                background: 'linear-gradient(to top, #cccc00, #FFFF00)'
            },
            { 
                id: 'sva', 
                title: 'Svr T-Storm Watch', 
                cssClass: 'svr-watch', 
                codes: ['SVA'],
                background: 'linear-gradient(to top, #b85c7a, #DB7093)'
            },
            { 
                id: 'ffa', 
                title: 'Flash Flood Watch', 
                cssClass: 'ffw-watch', 
                codes: ['FFA'],
                background: 'linear-gradient(to top, #256f45, #2E8B57)'
            },
            { 
                id: 'tor', 
                title: 'Tornado Wrn.', 
                cssClass: 'tor', 
                codes: ['TO'],
                background: 'linear-gradient(to top, #c43147, #ff002f)'
            },
            { 
                id: 'svr', 
                title: 'Svr. T-Storm Wrn.', 
                cssClass: 'svr', 
                codes: ['SV', 'SVR'],
                background: 'linear-gradient(to top, #b87c0a, #FFA500)'
            },
            { 
                id: 'ffw', 
                title: 'Flash Flood Wrn.', 
                cssClass: 'ffw', 
                codes: ['FF', 'FFW'],
                background: 'linear-gradient(to top, #5c8d3d, #84ff00)'
            },
            { 
                id: 'wsw', 
                title: 'Winter Storm Wrn.', 
                cssClass: 'wsw-warn', 
                codes: ['WSW'],
                background: 'linear-gradient(to top, #b84c8d, #FF69B4)' // Pink gradient
            },
            { 
                id: 'sqw', 
                title: 'Snow Squall Wrn.', 
                cssClass: 'sqw-warn', 
                codes: ['SQW'],
                background: 'linear-gradient(to top, #8b0a50, #C71585)' // Magenta gradient
            },
            { 
                id: 'wsa', 
                title: 'Winter Storm Watch', 
                cssClass: 'wsa-watch', 
                codes: ['WSA'],
                background: 'linear-gradient(to top, #2b567a, #4682B4)' // Steel Blue gradient
            },
            { 
                id: 'ww',  
                title: 'Winter Wx Advisory', 
                cssClass: 'ww-advisory', 
                codes: ['WW', 'WWY'],
                background: 'linear-gradient(to top, #7d5c9e, #9f75cf)' // Purple gradient
            },
            { 
                id: 'sps', 
                title: 'Special Wx.', 
                cssClass: 'sps', 
                codes: ['SPS'],
                background: 'linear-gradient(to top, #417b9c, #7dcfff)'
            }
        ];

        // 3. Render the Counters
        countersBar.innerHTML = "";

        counterConfig.forEach(config => {
            // Calculate total count for this specific counter
            let count = 0;
            config.codes.forEach(code => {
                count += (rawCounts[code] || 0);
            });

            const counterItem = document.createElement("div");
            
            // Apply class for standard CSS
            counterItem.className = `counter-item ${config.cssClass}`;
            
            // Apply INLINE styles to guarantee colors appear
            counterItem.style.backgroundImage = config.background;
            counterItem.style.color = '#ffffff';
            counterItem.style.textShadow = '1px 1px 2px rgba(0,0,0,0.5)';
            counterItem.style.borderTop = '1px solid rgba(255,255,255,0.3)';
            
            counterItem.innerHTML = `
                <span class="counter-title">${config.title}</span>
                <span class="counter-value">${count}</span>
            `;
            
            counterItem.style.cursor = "pointer";
            counterItem.addEventListener("click", () => {
            });

            countersBar.appendChild(counterItem);
        });
    }

    // --- Alert Grid ---
    function updateAlertsGrid(alerts) {
        const container = document.getElementById("activeAlerts");
        if (!container) return;
        container.innerHTML = "";

        let filteredAlerts = alerts;

        // Filter by Type
        if (activeFilters.size > 0) {
            const phenomenaToDisplay = new Set();
            activeFilters.forEach((filter) => {
                if (filter === "SV") { phenomenaToDisplay.add("SV").add("SVR").add("SVA"); }
                else if (filter === "FF") { phenomenaToDisplay.add("FF").add("FFW").add("FFA"); }
                else if (filter === "TO") { phenomenaToDisplay.add("TO").add("TOA"); }
                else if (filter === "WINTER") { 
                    phenomenaToDisplay.add("WW").add("WWY").add("WSW").add("WSA").add("SQW").add("LE"); 
                }
                else { phenomenaToDisplay.add(filter); }
            });
            filteredAlerts = alerts.filter((alert) => phenomenaToDisplay.has(alert.phenomenon));
        }

        // Filter by State
        if (activeStateFilters.size > 0) {
            filteredAlerts = filteredAlerts.filter((alert) => {
                if (!alert.affected_areas || alert.affected_areas.length === 0) return false;
                return alert.affected_areas.some((ugc) => activeStateFilters.has(ugc.substring(0, 2)));
            });
        }

        if (filteredAlerts.length === 0) {
            container.innerHTML = '<p class="no-alerts">No active alerts match this filter.</p>';
            return;
        }

        // Sort
        filteredAlerts.sort((a, b) => {
            const pA = window.alertPriority?.[a.phenomenon] || 99;
            const pB = window.alertPriority?.[b.phenomenon] || 99;
            if (pA !== pB) return pA - pB;
            return new Date(b.issue_time) - new Date(a.issue_time);
        });

        // --- NEW TIME FORMATTING LOGIC (From your Dashboard.js) ---
        const formatExpiration = (isoString) => {
            if (!isoString) return "Until Further Notice";
            
            const expirationDate = new Date(isoString);
            const now = new Date();
            
            // Normalize to start of day
            const expDay = new Date(expirationDate.getFullYear(), expirationDate.getMonth(), expirationDate.getDate());
            const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
            
            const isToday = expDay.getTime() === today.getTime();

            if (isToday) {
                return expirationDate.toLocaleString('en-US', {
                    hour: 'numeric',
                    minute: '2-digit',
                    timeZoneName: 'short'
                });
            } else {
                return expirationDate.toLocaleString('en-US', {
                    weekday: 'short',
                    month: 'short',
                    day: 'numeric',
                    hour: 'numeric',
                    minute: '2-digit',
                    timeZoneName: 'short'
                });
            }
        };

        // Render Cards
        filteredAlerts.forEach((alert) => {
            const config = window.ALERT_TYPE_MAP?.[alert.phenomenon] || { name: alert.phenomenon, icon: "fas fa-circle" };
            
            // Build Tags
            let tagsHTML = "";
            if (alert.is_emergency) tagsHTML += `<span class="tag emergency">EMERGENCY</span>`;
            if (alert.tornado_observed) tagsHTML += `<span class="tag emergency">OBSERVED</span>`;
            else if (alert.tornado_detection) tagsHTML += `<span class="tag">${alert.tornado_detection}</span>`;
            if (alert.damage_threat === "DESTRUCTIVE") tagsHTML += `<span class="tag emergency">DESTRUCTIVE</span>`;
            if (alert.damage_threat === "CATASTROPHIC") tagsHTML += `<span class="tag emergency">CATASTROPHIC</span>`;
            if (alert.damage_threat === "CONSIDERABLE") tagsHTML += `<span class="tag">CONSIDERABLE</span>`;

            // Build Details
            let detailsHTML = "";
            if (alert.max_wind_gust) detailsHTML += `<span class="threat-detail"><i class="fas fa-wind"></i> ${alert.max_wind_gust}</span>`;
            if (alert.max_hail_size) detailsHTML += `<span class="threat-detail"><i class="far fa-circle"></i> ${alert.max_hail_size}</span>`;
            if (alert.snow_amount) detailsHTML += `<span class="threat-detail"><i class="fas fa-snowflake"></i> ${alert.snow_amount}</span>`;
            if (alert.storm_motion) detailsHTML += `<span class="threat-detail"><i class="far fa-compass"></i> ${alert.storm_motion}</span>`;

            const card = document.createElement("div");
            let threatClass = "";
            if (alert.is_emergency) threatClass = "emergency";
            else if (alert.tornado_observed) threatClass = "tornado-observed";

            card.className = `alert-card ${alert.phenomenon.toLowerCase()} ${threatClass}`;
            
            // FIX: Use alert.expiration_time based on your dashboard.js snippet
            const timeString = formatExpiration(alert.expiration_time);

            card.innerHTML = `
                <div class="alert-header">
                    <i class="${config.icon}"></i>
                    <h3>${config.name}</h3>
                </div>
                <div class="alert-body">
                    <p>${alert.display_locations}</p>
                    <div class="alert-threats-container">
                        <div class="alert-threat-details">${detailsHTML}</div>
                        <div class="alert-tags">${tagsHTML}</div>
                    </div>
                    <div class="alert-footer" style="margin-top: 10px; font-size: 0.85em; opacity: 0.8;">
                        <i class="far fa-clock"></i> Expires: ${timeString}
                    </div>
                </div>
            `;
            container.appendChild(card);
        });
    }

    // --- Helpers (State Filter, ODOT, Turf) ---
    function initializeStateFilters() {
        const dropdown = document.getElementById("stateFilterDropdown");
        if (!dropdown) return;
        const button = dropdown.querySelector(".state-filter-button");
        const panel = dropdown.querySelector(".state-filter-panel");
        const states = ["AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA", "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY"];
        
        panel.innerHTML = states.map(state => 
            `<label class="state-filter-label"><input type="checkbox" class="state-filter-checkbox" value="${state}">${state}</label>`
        ).join("");

        button.addEventListener("click", (e) => {
            e.stopPropagation();
            panel.style.display = panel.style.display === "grid" ? "none" : "grid";
        });

        document.addEventListener("click", (e) => {
            if (!dropdown.contains(e.target)) panel.style.display = "none";
        });

        panel.addEventListener("change", (e) => {
            if (e.target.classList.contains("state-filter-checkbox")) {
                const state = e.target.value;
                if (e.target.checked) activeStateFilters.add(state);
                else activeStateFilters.delete(state);
                
                updateAlertsGrid(activeAlertsCache);
                
                if (activeStateFilters.size === 0) button.textContent = "Filter by State";
                else if (activeStateFilters.size === 1) button.textContent = `${activeStateFilters.values().next().value} Selected`;
                else button.textContent = `${activeStateFilters.size} States Selected`;
            }
        });
    }

    function setupEventListeners() {
        if (!filterControls) return;
        filterControls.addEventListener("click", (e) => {
            if (!e.target.matches(".filter-btn")) return;
            const clickedFilter = e.target.dataset.filter;
            const allButton = filterControls.querySelector('[data-filter="ALL"]');
            
            if (clickedFilter === "ALL") {
                activeFilters.clear();
                filterControls.querySelectorAll(".filter-btn").forEach(btn => btn.classList.remove("active"));
                allButton.classList.add("active");
            } else {
                allButton.classList.remove("active");
                if (activeFilters.has(clickedFilter)) {
                    activeFilters.delete(clickedFilter);
                    e.target.classList.remove("active");
                } else {
                    activeFilters.add(clickedFilter);
                    e.target.classList.add("active");
                }
                if (activeFilters.size === 0) allButton.classList.add("active");
            }
            updateAlertsGrid(activeAlertsCache);
        });
    }

    async function fetchOdotCameras() {
        if (!CONFIG.odot_api_key || CONFIG.odot_api_key === "YOUR_API_KEY_HERE") return;
        try {
            const response = await fetch("https://publicapi.ohgo.com/api/v1/cameras?page-all=true", {
                headers: { Authorization: `APIKEY ${CONFIG.odot_api_key}` }
            });
            if (response.ok) {
                const data = await response.json();
                odotCameraCache = data.results.map(c => ({
                    id: c.id,
                    location: c.location,
                    latitude: c.latitude,
                    longitude: c.longitude,
                    imageUrl: c.cameraViews[0]?.largeUrl
                })).filter(c => c.imageUrl);
            }
        } catch (e) { console.error("Error fetching ODOT cameras", e); }
    }

    const loadCountyData = async () => {
        try {
            const response = await fetch("counties.geojson");
            if (response.ok) {
                const countyData = await response.json();
                countyData.features.forEach(f => countyFipsMap.set(f.properties.GEOID, f));
            }
        } catch (e) { console.error("Error loading county data", e); }
    };

    function updateCamerasInWarnings(alerts, cameras) {
        const container = document.getElementById("camerasInWarningList");
        if (!container) return;
        container.innerHTML = "";
        
        const camerasFound = [];
        
        // Use turf to find cameras in polygons
        alerts.forEach(alert => {
            if (!alert.polygon) return;
            // Handle potentially nested polygon arrays from API
            let polygons = (Array.isArray(alert.polygon[0]) && typeof alert.polygon[0][0] === 'number') 
                ? [alert.polygon] : alert.polygon;

            polygons.forEach(poly => {
                if (poly.length < 4) return;
                // Close polygon if needed
                const ring = (poly[0][0] !== poly[poly.length-1][0]) ? [...poly, poly[0]] : poly;
                const coords = ring.map(p => [p[1], p[0]]); // Swap to lon, lat for Turf
                try {
                    const polyGeo = turf.polygon([coords]);
                    cameras.forEach(cam => {
                        if (turf.booleanPointInPolygon(turf.point([cam.longitude, cam.latitude]), polyGeo)) {
                            if (!camerasFound.find(c => c.id === cam.id)) {
                                // FIX: Lookup the human-readable name using the global map
                                const config = window.ALERT_TYPE_MAP?.[alert.phenomenon];
                                const readableName = config ? config.name : alert.phenomenon;
                                
                                camerasFound.push({ ...cam, alertName: readableName, alertCode: alert.phenomenon });
                            }
                        }
                    });
                } catch(e) {}
            });
        });

        if (camerasFound.length === 0) {
            container.innerHTML = '<p class="no-alerts">No cameras are currently within an active warning polygon.</p>';
            return;
        }

        camerasFound.forEach(cam => {
            const card = document.createElement("div");
            // Add alert code to class list so we can style the camera card border/header if we want
            const alertCodeClass = cam.alertCode ? cam.alertCode.toLowerCase() : '';
            card.className = `alert-card camera-in-warning ${alertCodeClass}`;
            
            card.innerHTML = `
                <div class="alert-header">
                    <i class="fas fa-video"></i>
                    <h3>${cam.location}</h3>
                </div>
                <div class="alert-body">
                    <p>Inside <b style="color: inherit;">${cam.alertName}</b></p>
                    <img src="${cam.imageUrl}" alt="${cam.location}" style="width: 100%; border-radius: 4px; margin-top: 5px;">
                </div>`;
            container.appendChild(card);
        });
    }

    init();
});