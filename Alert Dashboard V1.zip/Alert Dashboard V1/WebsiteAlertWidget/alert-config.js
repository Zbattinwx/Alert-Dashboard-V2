/**
 * alert-config.js
 * ==================================================================================
 * CENTRALIZED ALERT CONFIGURATION LOADER
 * ==================================================================================
 * Dynamically loads alert type configurations from the backend API.
 * All alert types, colors, icons, priorities, etc. are loaded from a single
 * JSON configuration file on the server (alert_types_config.json).
 *
 * To add a new alert type: Edit alert_types_config.json and restart the server.
 * No code changes needed!
 * ==================================================================================
 */

class AlertConfig {
    constructor() {
        this.config = null;
        this.alertTypes = [];
        this.loaded = false;
        this.loadPromise = null;

        // Cached lookups (built after loading)
        this.ALERT_TYPE_MAP = {};
        this.ALERT_SHORT_NAMES = {};
        this.ALERT_STYLE_MAP = {};
        this.ALERT_PRIORITY = {};
        this.THREAT_COLORS = {};
        this.THREAT_INFO = {};
        this.DISPLAY_WARNINGS = new Set();
        this.DAILY_RECAP_MAP = {};
        this.PHENOMENON_CODES = new Set();
        this.HIGH_PRIORITY_CODES = new Set();
    }

    /**
     * Load configuration from the backend API
     * Returns a promise that resolves when config is loaded
     */
    async load() {
        // If already loading, return the existing promise
        if (this.loadPromise) {
            return this.loadPromise;
        }

        // If already loaded, return immediately
        if (this.loaded) {
            return Promise.resolve();
        }

        this.loadPromise = this._fetchConfig();
        return this.loadPromise;
    }

    async _fetchConfig() {
        try {
            console.log('📡 Loading alert configuration from server...');
            const baseUrl = (typeof CONFIG !== 'undefined' && CONFIG.api_url) 
                ? CONFIG.api_url 
                : '';
            
            const response = await fetch(`${baseUrl}/api/alert_config`);
            // ---------------------

            if (!response.ok) {
                throw new Error(`Failed to load alert config: ${response.status} ${response.statusText}`);
            }

            this.config = await response.json();
            this.alertTypes = this.config.alert_types || [];

            // Build lookup tables
            this._buildLookups();

            this.loaded = true;
            console.log(`✅ Loaded ${this.alertTypes.length} alert types from server`);
            console.log('Alert configuration:', this);

            return this.config;

        } catch (error) {
            console.error('❌ Failed to load alert configuration:', error);
            console.error('   This is normal if you opened the page as a local file (file://)');
            console.error('   To use dynamic config, serve pages through the Python web server');
            console.warn('⚠️ Falling back to hardcoded CSS colors from theme files');
            this.alertTypes = [];
            this.loaded = false;
            // Don't re-throw - let the page continue with fallback styles
            return null;
        }
    }

    /**
     * Build cached lookup tables from the loaded configuration
     */
    _buildLookups() {
        this.ALERT_TYPE_MAP = {};
        this.ALERT_SHORT_NAMES = {};
        this.ALERT_STYLE_MAP = {};
        this.ALERT_PRIORITY = {};
        this.THREAT_COLORS = {};
        this.THREAT_INFO = {};
        this.DISPLAY_WARNINGS = new Set();
        this.DAILY_RECAP_MAP = {};
        this.PHENOMENON_CODES = new Set();
        this.HIGH_PRIORITY_CODES = new Set();
        this.DASHBOARD_ALERTS = new Set();
        this.TICKER_ALERTS = new Set();

        for (const alert of this.alertTypes) {
            const code = alert.phenomenon_code;

            // Track all phenomenon codes
            this.PHENOMENON_CODES.add(code);

            // High priority codes
            if (alert.high_priority) {
                this.HIGH_PRIORITY_CODES.add(code);
            }

            // Track which alerts to show on dashboard vs ticker
            if (alert.show_on_dashboard !== false) {  // Default to true if not specified
                this.DASHBOARD_ALERTS.add(code);
            }
            if (alert.show_on_ticker !== false) {  // Default to true if not specified
                this.TICKER_ALERTS.add(code);
            }

            // Alert type map (name + icon) - include color for ticker
            this.ALERT_TYPE_MAP[code] = {
                name: alert.display_name,
                icon: alert.icon,
                color: alert.colors.primary  // Add color for ticker background
            };

            // Short names (for ticker, etc.)
            this.ALERT_SHORT_NAMES[code] = alert.short_name;

            // Map style (Leaflet polygon styling)
            this.ALERT_STYLE_MAP[code] = {
                color: alert.map_style.color,
                weight: alert.map_style.weight,
                fillOpacity: alert.map_style.fillOpacity
            };

            // Priority values
            this.ALERT_PRIORITY[code] = alert.priority;

            // Threat colors (for state map)
            this.THREAT_COLORS[code] = alert.colors.state_map;

            // Threat info (for state map hover)
            this.THREAT_INFO[code] = {
                name: alert.display_name,
                color: alert.colors.state_map
            };

            // Daily recap map
            this.DAILY_RECAP_MAP[code] = {
                name: alert.display_name,
                icon: alert.icon.replace('fas fa-', 'fa-'), // Strip 'fas fa-' prefix
                color: alert.colors.daily_recap
            };

            // Display warnings (map widgets)
            if (alert.show_on_map) {
                this.DISPLAY_WARNINGS.add(code);
            }
        }

        console.log('Built lookup tables:', {
            types: Object.keys(this.ALERT_TYPE_MAP).length,
            priorities: Object.keys(this.ALERT_PRIORITY).length,
            displayWarnings: this.DISPLAY_WARNINGS.size
        });
    }

    /**
     * Get CSS color variable name for a phenomenon code
     */
    getCSSColorVar(phenomenonCode) {
        const alert = this.getAlertByCode(phenomenonCode);
        return alert?.colors?.css_var || '#cccccc';
    }

    /**
     * Get full alert configuration by phenomenon code
     */
    getAlertByCode(phenomenonCode) {
        return this.alertTypes.find(a => a.phenomenon_code === phenomenonCode);
    }

    /**
     * Get all phenomenon codes
     */
    getAllPhenomenonCodes() {
        return Array.from(this.PHENOMENON_CODES);
    }

    /**
     * Check if a phenomenon code is high priority
     */
    isHighPriority(phenomenonCode) {
        return this.HIGH_PRIORITY_CODES.has(phenomenonCode);
    }

    /**
     * Get configuration for special handling (SPS filters, etc.)
     */
    getSpecialHandling() {
        return this.config?.special_handling || {};
    }

    /**
     * Reload configuration from server (for live updates)
     */
    async reload() {
        console.log('🔄 Reloading alert configuration...');
        this.loaded = false;
        this.loadPromise = null;
        await this.load();
    }
}

// ==================================================================================
// GLOBAL INSTANCE
// ==================================================================================
// Create a single global instance that can be used across all JavaScript files

const alertConfig = new AlertConfig();
window.alertConfig = alertConfig;

/**
 * Initialize and populate global variables for backwards compatibility
 * This allows existing code to continue working without major refactoring
 */
async function initializeGlobalAlertConfig() {
    try {
        await alertConfig.load();

        // Populate global variables that existing JavaScript code expects
        // This maintains backwards compatibility with dashboard.js, etc.

        // ALERT_TYPE_MAP - used by dashboard.js, widget-common.js
        window.ALERT_TYPE_MAP = alertConfig.ALERT_TYPE_MAP;

        // ALERT_SHORT_NAMES - used for ticker display
        window.TICKER_FILTERABLE_ALERTS = alertConfig.ALERT_SHORT_NAMES;

        // ALERT_STYLE_MAP - used for Leaflet polygon styling
        window.ALERT_STYLE_MAP = alertConfig.ALERT_STYLE_MAP;

        // ALERT_PRIORITY - used for sorting alerts
        window.alertPriority = alertConfig.ALERT_PRIORITY;

        // THREAT_COLORS - used by state_map.js
        window.threatColors = alertConfig.THREAT_COLORS;

        // THREAT_INFO - used by state_map.js
        window.threatInfo = alertConfig.THREAT_INFO;

        // DISPLAY_WARNINGS - used by alert_map.js
        window.DISPLAY_WARNINGS = alertConfig.DISPLAY_WARNINGS;

        // DAILY_RECAP_MAP - used by daily_recap.js
        window.DAILY_RECAP_MAP = alertConfig.DAILY_RECAP_MAP;

        // DASHBOARD_ALERTS and TICKER_ALERTS - control visibility
        window.DASHBOARD_ALERTS = alertConfig.DASHBOARD_ALERTS;
        window.TICKER_ALERTS = alertConfig.TICKER_ALERTS;

        // Create counters object dynamically from all phenomenon codes
        window.counters = {};
        for (const code of alertConfig.getAllPhenomenonCodes()) {
            window.counters[code] = 0;
        }

        // Create styleMapping for dashboard.js map styling
        window.styleMapping = alertConfig.ALERT_STYLE_MAP;

        console.log('✅ Global alert configuration variables initialized');
        console.log(`   - ${Object.keys(window.ALERT_TYPE_MAP).length} alert types loaded`);
        console.log(`   - Dashboard: ${alertConfig.DASHBOARD_ALERTS.size} alerts`);
        console.log(`   - Ticker: ${alertConfig.TICKER_ALERTS.size} alerts`);
        console.log(`   - Ready for: ${alertConfig.getAllPhenomenonCodes().join(', ')}`);

        // Dispatch event to let other scripts know config is ready
        window.dispatchEvent(new CustomEvent('alertConfigReady', {
            detail: { config: alertConfig }
        }));

    } catch (error) {
        console.error('❌ Failed to initialize global alert configuration:', error);
        console.error('Dashboard may not function correctly!');

        // Initialize empty objects to prevent errors
        window.ALERT_TYPE_MAP = {};
        window.TICKER_FILTERABLE_ALERTS = {};
        window.ALERT_STYLE_MAP = {};
        window.alertPriority = {};
        window.threatColors = {};
        window.threatInfo = {};
        window.DISPLAY_WARNINGS = new Set();
        window.DAILY_RECAP_MAP = {};
        window.counters = {};
        window.styleMapping = {};
    }
}

// Auto-initialize on script load
initializeGlobalAlertConfig();

// Export for use in other modules (if using ES6 modules)
// Otherwise it's available as a global variable
if (typeof module !== 'undefined' && module.exports) {
    module.exports = alertConfig;
}
