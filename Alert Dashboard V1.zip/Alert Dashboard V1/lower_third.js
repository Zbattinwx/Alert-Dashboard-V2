document.addEventListener('DOMContentLoaded', () => {
    const WEBSOCKET_URL = CONFIG.websocket_url;
    const container = document.getElementById('lower-third-container');
    const nameEl = document.querySelector('#name span');
    const titleEl = document.querySelector('#title span');

    function connect() {
        createWebSocketConnection(WEBSOCKET_URL, {
            onMessage: (data) => {
                // Apply theme from ANY message that contains it
                if (data.ticker_theme || data.widget_theme || data.theme) {
                    applyWidgetTheme(data.ticker_theme || data.widget_theme || data.theme, 'widget');
                }

                if (data.type === 'show_lower_third') {
                    // Update the text content from the data payload
                    nameEl.textContent = data.name || 'Default Name';
                    titleEl.textContent = data.title || 'Default Title';

                    // Animate it in
                    // Using requestAnimationFrame ensures the text is updated before the animation starts
                    requestAnimationFrame(() => {
                        container.classList.add('active');
                    });

                } else if (data.type === 'hide_lower_third') {
                    // Remove the 'active' class to trigger the reverse transition
                    container.classList.remove('active');
                }
            }
        });
    }

    connect();
});