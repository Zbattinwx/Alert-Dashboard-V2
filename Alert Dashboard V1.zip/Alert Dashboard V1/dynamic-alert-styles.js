/**
 * dynamic-alert-styles.js
 * ==================================================================================
 * DYNAMIC ALERT STYLING FROM CONFIG
 * ==================================================================================
 * Automatically applies alert colors from alert_types_config.json to CSS
 * so you never have to manually update theme CSS files when adding new alerts.
 * ==================================================================================
 */

/**
 * Apply dynamic alert colors from the loaded configuration
 * This runs after alert-config.js has loaded the configuration
 */
let retryCount = 0;
const MAX_RETRIES = 50; // Max 5 seconds of retrying

function applyDynamicAlertStyles() {
    // Check if alertConfig exists and has loaded data
    if (!window.alertConfig || !window.alertConfig.alertTypes || window.alertConfig.alertTypes.length === 0) {
        retryCount++;
        if (retryCount >= MAX_RETRIES) {
            console.error('❌ Failed to load alert config after 5 seconds.');
            console.error('Debug info:', {
                alertConfigExists: !!window.alertConfig,
                hasAlertTypes: window.alertConfig?.alertTypes !== undefined,
                alertTypesLength: window.alertConfig?.alertTypes?.length,
                configObject: window.alertConfig
            });
            console.warn('⚠️ Dynamic alert styles will not be applied. Falling back to hardcoded CSS colors.');
            return;
        }
        // Silently retry - don't spam console
        setTimeout(applyDynamicAlertStyles, 100);
        return;
    }

    console.log('🎨 Applying dynamic alert styles from configuration...');

    const config = window.alertConfig;
    retryCount = 0; // Reset for future calls
    const root = document.documentElement;
    const styleTag = document.createElement('style');
    styleTag.id = 'dynamic-alert-styles';

    let css = '/* Dynamically generated alert styles from alert_types_config.json */\n\n';

    // Generate CSS for each alert type
    for (const alert of config.alertTypes) {
        const code = alert.phenomenon_code;
        const codeLower = code.toLowerCase();
        const color = alert.colors.primary;

        // Dashboard alert card borders
        css += `.alert-card.${codeLower} { border-color: ${color} !important; }\n`;

        // Base ticker backgrounds (for themes that don't override)
        css += `.ticker-container.${code} { background-color: ${color} !important; }\n`;

        // Storm Chaser dashboard theme (uses ::before bars)
        css += `.theme-storm-chaser .alert-card.${codeLower}::before { background: ${color} !important; }\n`;

        // Atmospheric dashboard theme (uses ::before bars with gradients)
        const gradient = `linear-gradient(135deg, ${color} 0%, ${adjustBrightness(color, -20)} 100%)`;
        css += `.theme-atmospheric .alert-card.${codeLower}::before { background: ${gradient} !important; }\n`;

        // Meteorologist dashboard theme
        css += `.theme-meteorologist .alert-card.${codeLower}::before { background: ${color} !important; }\n`;

        // Winter dashboard theme
        css += `.theme-winter .alert-card.${codeLower}::before { background: ${gradient} !important; }\n`;

        // Atmospheric ticker (gradient backgrounds)
        css += `body.ticker-theme-atmospheric .ticker-container.${code} { background: ${gradient} !important; }\n`;

        // Storm Chaser ticker
        css += `body.ticker-theme-storm-chaser .ticker-container.${code} { background-color: ${color} !important; }\n`;

        // Meteorologist ticker
        css += `body.ticker-theme-meteorologist .ticker-container.${code} { background-color: ${color} !important; }\n`;

        // Winter ticker
        css += `body.ticker-theme-winter .ticker-container.${code} { background: ${gradient} !important; }\n`;

        // Classic ticker
        css += `body.ticker-theme-classic .ticker-container.${code} { background-color: ${color} !important; }\n`;
    }

    styleTag.textContent = css;

    // Remove old dynamic styles if they exist
    const oldStyle = document.getElementById('dynamic-alert-styles');
    if (oldStyle) {
        oldStyle.remove();
    }

    // Append new styles
    document.head.appendChild(styleTag);

    console.log(`✅ Applied dynamic styles for ${config.alertTypes.length} alert types`);
    console.log('   All themes will now automatically use colors from alert_types_config.json');
}

/**
 * Adjust color brightness (for gradients)
 * @param {string} color - Hex color (e.g., "#FF0000")
 * @param {number} percent - Percentage to darken (negative) or lighten (positive)
 * @returns {string} - Adjusted hex color
 */
function adjustBrightness(color, percent) {
    // Remove # if present
    color = color.replace('#', '');

    // Convert to RGB
    let r = parseInt(color.substring(0, 2), 16);
    let g = parseInt(color.substring(2, 4), 16);
    let b = parseInt(color.substring(4, 6), 16);

    // Adjust brightness
    r = Math.max(0, Math.min(255, r + (r * percent / 100)));
    g = Math.max(0, Math.min(255, g + (g * percent / 100)));
    b = Math.max(0, Math.min(255, b + (b * percent / 100)));

    // Convert back to hex
    const rr = Math.round(r).toString(16).padStart(2, '0');
    const gg = Math.round(g).toString(16).padStart(2, '0');
    const bb = Math.round(b).toString(16).padStart(2, '0');

    return `#${rr}${gg}${bb}`;
}

// Wait for alert config to be ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.addEventListener('alertConfigReady', applyDynamicAlertStyles);
        // Also try immediately in case config is already loaded
        setTimeout(applyDynamicAlertStyles, 500);
    });
} else {
    window.addEventListener('alertConfigReady', applyDynamicAlertStyles);
    // Try immediately if config might already be loaded
    setTimeout(applyDynamicAlertStyles, 500);
}
