document.addEventListener('DOMContentLoaded', () => {
    const WEBSOCKET_URL = CONFIG.websocket_url;
    const ROTATION_SPEED_MS = 10000;
    const rotatorContainer = document.getElementById('alert-rotator');
    let activeAlerts = [];
    let currentRotationIndex = 0;
    let rotationInterval;
    let isRotating = false;

    function connect() {
        createWebSocketConnection(WEBSOCKET_URL, {
            onMessage: (data) => {
                // Debug logging
                console.log('Rotator received message type:', data.type);
                console.log('Theme values - ticker_theme:', data.ticker_theme, 'widget_theme:', data.widget_theme, 'theme:', data.theme);

                // Apply theme from ANY message that contains it
                if (data.ticker_theme || data.widget_theme || data.theme) {
                    const themeToApply = data.ticker_theme || data.widget_theme || data.theme;
                    console.log('Rotator applying theme:', themeToApply);
                    applyWidgetTheme(themeToApply, 'widget');
                } else {
                    console.log('No theme found in message');
                }

                if (data.type === 'update') {
                    activeAlerts = data.alerts;
                    updateRotator();
                }
            }
        });
    }

    function updateRotator() {
        // Only restart rotation if alert list has actually changed
        if (activeAlerts.length === 0) {
            clearInterval(rotationInterval);
            isRotating = false;
            rotatorContainer.classList.remove('visible');
            return;
        }

        // If not currently rotating, start rotation
        if (!isRotating) {
            currentRotationIndex = 0;
            displayRotatedAlert();

            if (activeAlerts.length > 1) {
                clearInterval(rotationInterval);
                rotationInterval = setInterval(displayRotatedAlert, ROTATION_SPEED_MS);
                isRotating = true;
            }
        }
        // If already rotating, just update the current alert display
        // (don't restart the interval, which was causing the timing issues)
    }

    function displayRotatedAlert() {
        if (activeAlerts.length === 0) return;

        currentRotationIndex %= activeAlerts.length;
        const alert = activeAlerts[currentRotationIndex];
        const alertInfo = getAlertDisplayInfo(alert);
        document.getElementById('rotator-title').textContent = alertInfo.name;
        document.getElementById('rotator-location').textContent = alert.display_locations;
        document.getElementById('rotator-expires').textContent = formatExpirationTime(alert.expiration_time);
        rotatorContainer.className = `widget-container ${alert.phenomenon}`;
        if (alert.is_emergency) rotatorContainer.classList.add('EMERGENCY');
        rotatorContainer.classList.add('visible');
        currentRotationIndex++;
    }

    connect();
    console.log('Rotator widget initialized and waiting for WebSocket messages...');
});