# Storm Report Submission Form - Setup Guide

## Overview
A public form that allows users to submit storm reports from your website. Reports are integrated with the dashboard's Local Storm Report map and snow accumulation map.

## Files Created
- **submit_report.html** - Public-facing storm report form
- **main_app.py** - Added `/api/submit_storm_report` POST endpoint

## Google reCAPTCHA Setup

### 1. Get reCAPTCHA Keys
1. Go to https://www.google.com/recaptcha/admin/create
2. Register a new site:
   - **Label**: Ohio Weather Alerts Storm Reports
   - **reCAPTCHA type**: Select "reCAPTCHA v2" → "I'm not a robot" Checkbox
   - **Domains**: Add `belparkmedia.com` and `localhost` (for testing)
3. Click **Submit**
4. You'll receive:
   - **Site Key** (public - goes in HTML)
   - **Secret Key** (private - goes in config.json)

### 2. Update HTML File
Edit `submit_report.html` line 414:
```html
<div class="g-recaptcha" data-sitekey="YOUR_RECAPTCHA_SITE_KEY"></div>
```
Replace `YOUR_RECAPTCHA_SITE_KEY` with your actual Site Key.

### 3. Update Backend Config
Add to `config.json`:
```json
{
  "recaptcha_secret_key": "YOUR_RECAPTCHA_SECRET_KEY",
  ...existing config...
}
```

## Hosting on belparkmedia.com

### Option 1: Simple Upload
1. Upload `submit_report.html` to your web server
2. Access at: `https://belparkmedia.com/submit_report.html`
3. Update line 448 to point to your dashboard server:
```javascript
const response = await fetch('http://YOUR_DASHBOARD_IP:8080/api/submit_storm_report', {
```

### Option 2: Embed in Existing Website
If you have an existing page layout, copy the form section from `submit_report.html` into your existing page template.

## CORS Configuration
The backend automatically sets CORS headers to allow cross-origin requests from your website:
```python
self.send_header('Access-Control-Allow-Origin', '*')
```

For production, you may want to restrict this to your domain only:
```python
self.send_header('Access-Control-Allow-Origin', 'https://belparkmedia.com')
```

## Features

### Report Types Supported
- **Tornado** - Wind speed or EF-scale rating
- **Hail** - Diameter in inches
- **Wind** - Wind speed in mph
- **Flooding** - Water depth
- **Winter (Snow)** - Snow accumulation in inches
- **Tropical** - Wind speed or storm surge
- **Other** - General severe weather

### Required Fields
- Report type
- Location (can use geolocation or manual entry)
- Magnitude/measurement
- Date & time

### Optional Fields
- Additional details/notes
- Submitter name (defaults to "Anonymous")

### Spam Protection
- Google reCAPTCHA verification
- Field validation
- Server-side verification

## How Reports Flow Through the System

### 1. User Submits Report
- User fills out form on belparkmedia.com
- Clicks "Submit Report"
- reCAPTCHA verification runs

### 2. Backend Processing
- POST request sent to `/api/submit_storm_report`
- Backend verifies reCAPTCHA with Google
- Validates required fields
- Creates report with unique ID
- Adds `source: 'viewer'` flag
- Appends to `manual_lsrs` list

### 3. Broadcasting
- Report broadcast to all connected dashboard clients via WebSocket
- Dashboard updates Local Storm Report map in real-time
- Snow reports also available for snow_map interpolation

### 4. Display on Dashboard
- Viewer reports shown with purple eye icon
- Official NWS reports shown with standard icons
- Popups show report details and submitter info

## Report Data Structure

```javascript
{
  id: "uuid-v4",
  lat: 40.1234,
  lng: -82.5678,
  typeText: "SNOW",
  magnitude: "6.5",
  remarks: "Heavy snow accumulation in driveway",
  timestamp: "2025-12-02T14:30:00",
  location: "Columbus, OH",
  submitter: "John Doe",
  source: "viewer"  // Distinguishes from official reports
}
```

## Testing

### Local Testing
1. Open `submit_report.html` in browser
2. Test form submission (will fail on reCAPTCHA until keys added)
3. Check browser console for errors
4. Verify network requests in DevTools

### Production Testing
1. Upload to belparkmedia.com
2. Submit test report
3. Check dashboard for new report appearing
4. Verify it shows with viewer icon (purple eye)

## Troubleshooting

### reCAPTCHA Not Showing
- **Check**: Site key is correct in HTML
- **Check**: Domain is registered in reCAPTCHA console
- **Check**: No browser extensions blocking reCAPTCHA

### "reCAPTCHA verification failed"
- **Check**: Secret key is correct in config.json
- **Check**: Server can reach Google's servers (not blocked by firewall)

### Report Not Appearing on Dashboard
- **Check**: Dashboard is connected to backend via WebSocket
- **Check**: Console shows "Received public storm report" message
- **Check**: `manual_lsrs` list is not empty

### CORS Errors
- **Check**: Backend has CORS headers enabled
- **Check**: URL in fetch() matches your server
- **Check**: Server is accessible from belparkmedia.com

### Location Not Working
- **Check**: Browser allows geolocation (HTTPS required)
- **Check**: User granted location permission
- **Fallback**: Manual entry always available

## Moderation

### Viewing Reports
All viewer reports are visible in the dashboard's Local Storm Report map with a distinct purple eye icon.

### Removing Individual Reports
(To be implemented in next phase - will add UI in dashboard)

### Clearing All Reports
Existing "Clear Reports" button in dashboard clears all manual reports.

## Security Considerations

1. **reCAPTCHA**: Prevents automated spam submissions
2. **Field Validation**: Server validates all required fields
3. **Rate Limiting**: Consider implementing if abuse occurs
4. **Input Sanitization**: Backend should sanitize text inputs (TODO)
5. **Authentication**: Consider requiring login for moderation features

## Future Enhancements

1. **Email Notifications**: Alert administrators of new viewer reports
2. **Report Approval System**: Review reports before displaying
3. **Photo Uploads**: Allow users to attach images
4. **Report Voting**: Let users upvote/verify reports
5. **Auto-Geocoding Improvement**: Use better geocoding service
6. **Mobile App**: Native mobile version
7. **Social Sharing**: Share reports to social media

## Integration with Snow Map

Snow reports (typeText: "SNOW") submitted through the form are automatically:
1. Added to `manual_lsrs` list
2. Available in dashboard LSR map
3. **TODO**: Need to add to snow_map interpolation data

The snow_map currently only fetches from `/api/snow_reports` which pulls LSR + ASOS data. We'll need to merge viewer snow reports into this data.

---

**Created**: December 2, 2025
**Status**: ✅ Backend complete, needs reCAPTCHA keys and dashboard updates
