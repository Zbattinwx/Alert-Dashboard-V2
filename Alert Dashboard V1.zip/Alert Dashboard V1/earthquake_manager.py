# earthquake_manager.py
# ==================================================================================
# EARTHQUAKE MANAGER SERVICE
# ==================================================================================
# Manages earthquake data from USGS earthquake feed.
# Tracks active earthquakes, provides filtering by magnitude, and broadcasts
# updates to connected clients.
# ==================================================================================

import aiohttp
import asyncio
from datetime import datetime, timezone
from typing import Dict, List, Optional, Set
import json
from logger import get_logger


class Earthquake:
    """
    Represents a single earthquake event from USGS.
    """

    def __init__(self, feature: dict):
        """
        Initialize an earthquake from USGS GeoJSON feature.

        Args:
            feature: GeoJSON feature object from USGS API
        """
        self.id = feature.get('id', '')
        properties = feature.get('properties', {})
        geometry = feature.get('geometry', {})
        coordinates = geometry.get('coordinates', [0, 0, 0])

        # Basic properties
        self.magnitude = properties.get('mag', 0.0)
        self.place = properties.get('place', 'Unknown Location')
        self.time = datetime.fromtimestamp(properties.get('time', 0) / 1000, tz=timezone.utc)
        self.updated = datetime.fromtimestamp(properties.get('updated', 0) / 1000, tz=timezone.utc)

        # Location
        self.longitude = coordinates[0]
        self.latitude = coordinates[1]
        self.depth_km = coordinates[2]  # Depth in kilometers

        # Additional properties
        self.url = properties.get('url', '')
        self.detail = properties.get('detail', '')
        self.felt = properties.get('felt')  # Number of felt reports
        self.cdi = properties.get('cdi')  # Community Decimal Intensity
        self.mmi = properties.get('mmi')  # Modified Mercalli Intensity
        self.alert = properties.get('alert')  # green/yellow/orange/red
        self.status = properties.get('status', 'automatic')
        self.tsunami = properties.get('tsunami', 0)  # 0 or 1
        self.significance = properties.get('sig', 0)
        self.type = properties.get('type', 'earthquake')
        self.mag_type = properties.get('magType', '')

    def to_json(self) -> dict:
        """
        Convert earthquake to JSON-serializable dictionary.

        Returns:
            Dictionary representation of the earthquake
        """
        return {
            'id': self.id,
            'magnitude': self.magnitude,
            'place': self.place,
            'time': self.time.isoformat(),
            'updated': self.updated.isoformat(),
            'longitude': self.longitude,
            'latitude': self.latitude,
            'depth_km': self.depth_km,
            'url': self.url,
            'detail': self.detail,
            'felt': self.felt,
            'cdi': self.cdi,
            'mmi': self.mmi,
            'alert': self.alert,
            'status': self.status,
            'tsunami': self.tsunami,
            'significance': self.significance,
            'type': self.type,
            'mag_type': self.mag_type
        }

    def get_felt_radius_km(self) -> float:
        """
        Estimate the radius in kilometers where the earthquake might be felt.
        This is a rough approximation based on magnitude.

        Returns:
            Estimated radius in kilometers
        """
        # Rough formula: felt radius increases exponentially with magnitude
        # M2.0 = ~20km, M3.0 = ~50km, M4.0 = ~100km, M5.0 = ~200km, M6.0 = ~400km, etc.
        if self.magnitude < 2.0:
            return 10
        elif self.magnitude < 3.0:
            return 30
        elif self.magnitude < 4.0:
            return 70
        elif self.magnitude < 5.0:
            return 150
        elif self.magnitude < 6.0:
            return 300
        elif self.magnitude < 7.0:
            return 600
        else:
            return 1200

    def __repr__(self):
        return f"<Earthquake M{self.magnitude} - {self.place}>"


class EarthquakeManager:
    """
    Manages earthquake data from USGS earthquake feed.
    """

    # USGS GeoJSON feed URLs
    USGS_BASE_URL = "https://earthquake.usgs.gov"
    FEED_URL = f"{USGS_BASE_URL}/earthquakes/feed/v1.0/summary/2.5_day.geojson"

    def __init__(self, min_magnitude: float = 2.0, poll_interval_seconds: int = 120):
        """
        Initialize the earthquake manager.

        Args:
            min_magnitude: Minimum magnitude to track (default 2.0)
            poll_interval_seconds: How often to poll USGS API (default 120 seconds)
        """
        self.min_magnitude = min_magnitude
        self.poll_interval = poll_interval_seconds
        self.active_earthquakes: Dict[str, Earthquake] = {}
        self.tracked_ids: Set[str] = set()
        self.last_update = None
        self.is_running = False
        self.logger = get_logger()

    async def fetch_earthquakes(self) -> Optional[List[Earthquake]]:
        """
        Fetch latest earthquakes from USGS API.

        Returns:
            List of Earthquake objects, or None if fetch failed
        """
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(self.FEED_URL, timeout=aiohttp.ClientTimeout(total=30)) as response:
                    if response.status != 200:
                        self.logger.warning(f"⚠️ USGS API returned status {response.status}")
                        return None

                    data = await response.json()
                    features = data.get('features', [])

                    earthquakes = []
                    for feature in features:
                        try:
                            eq = Earthquake(feature)
                            # Filter by minimum magnitude
                            if eq.magnitude >= self.min_magnitude:
                                earthquakes.append(eq)
                        except Exception as e:
                            self.logger.debug(f"⚠️ Error parsing earthquake feature: {e}")
                            continue

                    self.last_update = datetime.now(timezone.utc)
                    return earthquakes

        except asyncio.TimeoutError:
            self.logger.warning("⚠️ Timeout fetching earthquake data from USGS")
            return None
        except Exception as e:
            self.logger.error(f"❌ Error fetching earthquake data: {e}")
            return None

    def add_or_update_earthquake(self, earthquake: Earthquake) -> bool:
        """
        Add or update an earthquake in the active list.

        Args:
            earthquake: Earthquake object to add/update

        Returns:
            True if this is a new earthquake, False if it's an update
        """
        is_new = earthquake.id not in self.tracked_ids

        self.active_earthquakes[earthquake.id] = earthquake
        self.tracked_ids.add(earthquake.id)

        return is_new

    def get_all_earthquakes(self) -> List[Earthquake]:
        """
        Get all active earthquakes.

        Returns:
            List of all active earthquake objects
        """
        return list(self.active_earthquakes.values())

    def get_earthquake(self, eq_id: str) -> Optional[Earthquake]:
        """
        Get a specific earthquake by ID.

        Args:
            eq_id: Earthquake ID

        Returns:
            Earthquake object or None
        """
        return self.active_earthquakes.get(eq_id)

    def remove_old_earthquakes(self, max_age_hours: int = 24) -> int:
        """
        Remove earthquakes older than specified hours.

        Args:
            max_age_hours: Maximum age in hours (default 24)

        Returns:
            Number of earthquakes removed
        """
        now = datetime.now(timezone.utc)
        to_remove = []

        for eq_id, eq in self.active_earthquakes.items():
            age_hours = (now - eq.time).total_seconds() / 3600
            if age_hours > max_age_hours:
                to_remove.append(eq_id)

        for eq_id in to_remove:
            del self.active_earthquakes[eq_id]
            self.tracked_ids.discard(eq_id)

        if to_remove:
            self.logger.debug(f"🧹 Removed {len(to_remove)} old earthquake(s)")

        return len(to_remove)

    def to_json(self) -> dict:
        """
        Convert all earthquakes to JSON format.

        Returns:
            Dictionary with all earthquake data
        """
        return {
            'earthquakes': [eq.to_json() for eq in self.active_earthquakes.values()],
            'count': len(self.active_earthquakes),
            'last_update': self.last_update.isoformat() if self.last_update else None,
            'min_magnitude': self.min_magnitude
        }


# Global instance
_earthquake_manager = None


def get_earthquake_manager() -> EarthquakeManager:
    """Get or create the global earthquake manager instance."""
    global _earthquake_manager
    if _earthquake_manager is None:
        _earthquake_manager = EarthquakeManager(min_magnitude=2.0, poll_interval_seconds=120)
    return _earthquake_manager
