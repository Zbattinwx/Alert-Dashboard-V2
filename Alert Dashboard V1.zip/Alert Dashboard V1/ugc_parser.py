# ugc_parser.py

UGC_TO_COUNTY = {}

def load_ugc_database():
    """
    Reads the ugc_database.txt file and populates the UGC_TO_COUNTY dictionary.
    This map is primarily used for getting the NAME of a county from its code.
    """
    try:
        with open('ugc_database.txt', 'r', encoding='utf-8') as f:
            for line in f:
                if '|' not in line: continue
                parts = line.strip().split('|')
                if len(parts) < 7: continue

                state, zone_num, office, zone_name, simple_ugc, county_name, fips = parts[:7]

                # Create the County UGC (e.g., OHC065 from FIPS 39065)
                county_ugc = f"{state}C{fips[2:]}"
                UGC_TO_COUNTY[county_ugc] = {"name": county_name, "state": state, "fips": fips}

                # Create the Zone UGC (e.g., OHZ026)
                zone_ugc = f"{state}Z{zone_num}"
                # For zones, we still store the FIPS for the primary county listed on that line
                UGC_TO_COUNTY[zone_ugc] = {"name": zone_name, "state": state, "fips": fips}

        print(f"✅ Successfully loaded {len(UGC_TO_COUNTY)} UGC codes into memory for name lookups.")
        return True
        
    except FileNotFoundError:
        print("❌ CRITICAL: ugc_database.txt not found. County name lookup will not work.")
        return False
    except Exception as e:
        print(f"❌ An error occurred while loading the UGC database: {e}")
        return False