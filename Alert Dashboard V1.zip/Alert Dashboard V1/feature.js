console.log('[Feature Widget] feature.js loaded');

document.addEventListener('DOMContentLoaded', () => {
    console.log('[Feature Widget] DOMContentLoaded fired');
    const WEBSOCKET_URL = CONFIG.websocket_url;
    const featureBox = document.getElementById('feature-alert-box');
    let hideTimeout;

    console.log('[Feature Widget] Feature box element:', featureBox);

    function connect() {
        createWebSocketConnection(WEBSOCKET_URL, {
            onMessage: (data) => {
                console.log('[Feature Widget] Received message:', data.type);

                // Apply theme from ANY message that contains it
                if (data.ticker_theme || data.widget_theme || data.theme) {
                    applyWidgetTheme(data.ticker_theme || data.widget_theme || data.theme, 'widget');
                }

                if (data.type === 'feature_alert' && data.alert_data) {
                    console.log('[Feature Widget] Displaying featured alert:', data.alert_data.product_id);
                    displayFeaturedAlert(data.alert_data);
                }
            },
            onOpen: () => {
                console.log('[Feature Widget] WebSocket connection opened and ready');
            }
        });
    }

    function displayFeaturedAlert(alert) {
        console.log('[Feature Widget] displayFeaturedAlert called with:', alert);
        clearTimeout(hideTimeout);

        // Update Text Content
        const alertInfo = getAlertDisplayInfo(alert);
        document.getElementById('feature-icon').className = `fas ${alertInfo.icon}`;
        document.getElementById('feature-title').textContent = alertInfo.name;
        document.getElementById('feature-locations').textContent = alert.display_locations;
        document.getElementById('feature-expires').textContent = formatExpirationTime(alert.expiration_time);

        // Build Impacts (Wind/Hail)
        let impactsHTML = '';
        if (alert.max_wind_gust) impactsHTML += `<span class="tag">${alert.max_wind_gust}</span>`;
        if (alert.max_hail_size) impactsHTML += `<span class="tag">${alert.max_hail_size}</span>`;
        document.getElementById('feature-impacts').innerHTML = impactsHTML;

        // Build Tags (Observed, Destructive, etc.)
        let tagsHTML = '';
        if (alert.is_emergency) tagsHTML += `<span class="tag emergency">EMERGENCY</span>`;
        if (alert.tornado_observed) tagsHTML += `<span class="tag emergency">OBSERVED</span>`;
        if (alert.tornado_detection) tagsHTML += `<span class="tag">${alert.tornado_detection}</span>`;
        if (alert.damage_threat === 'DESTRUCTIVE') tagsHTML += `<span class="tag emergency">DESTRUCTIVE</span>`;
        if (alert.damage_threat === 'CATASTROPHIC') tagsHTML += `<span class="tag emergency">CATASTROPHIC</span>`;
        if (alert.damage_threat === 'CONSIDERABLE') tagsHTML += `<span class="tag">CONSIDERABLE</span>`;
        document.getElementById('feature-tags').innerHTML = tagsHTML;



        // Update styling and show the box
        featureBox.className = `feature-container ${alert.phenomenon}`; // Resets classes
        featureBox.classList.remove('hidden');
        console.log('[Feature Widget] Alert displayed, auto-hide in 20 seconds');

        // Automatically hide after 20 seconds
        hideTimeout = setTimeout(() => {
            featureBox.classList.add('hidden');
            console.log('[Feature Widget] Alert auto-hidden');
        }, 20000);
    }

    connect();
});