# constants.py
# ==================================================================================
# SHARED CONSTANTS MODULE
# ==================================================================================
# This module contains all shared constants used across the alert dashboard system.
# Centralizing these values eliminates duplication and ensures consistency.
#
# NOTE: Alert type definitions are now loaded from alert_types_config.json
#       See alert_config_loader.py for the dynamic loading mechanism
# ==================================================================================

from datetime import timedelta, timezone

# ==================================================================================
# NWS PHENOMENON CODES & ALERT TYPES
# ==================================================================================
# These are now dynamically loaded from alert_types_config.json
# Import these from alert_config_loader instead of defining them here

from alert_config_loader import (
    NWS_EVENT_TO_PHENOMENON,
    TARGET_PHENOMENA,
    HIGH_PRIORITY_ALERTS,
    ALERT_PRIORITY,
    get_alert_config,
    reload_alert_config
)

# For backwards compatibility, these are still available as module-level variables

# ==================================================================================
# WFO OFFICE TIMEZONES
# ==================================================================================
# Maps Weather Forecast Office (WFO) codes to their IANA timezone identifiers
# Used for displaying alert times in the correct local timezone

WFO_TIMEZONES = {
    # Eastern Time
    "BOX": "America/New_York", "BTV": "America/New_York", "CAR": "America/New_York",
    "GYX": "America/New_York", "OKX": "America/New_York", "PHI": "America/New_York",
    "ALY": "America/New_York", "BGM": "America/New_York", "BUF": "America/New_York",
    "CTP": "America/New_York", "PBZ": "America/New_York", "AKQ": "America/New_York",
    "LWX": "America/New_York", "RNK": "America/New_York", "ILN": "America/New_York",
    "CLE": "America/New_York", "IWX": "America/New_York", "DTX": "America/New_York",
    "APX": "America/New_York", "GRR": "America/New_York", "MQT": "America/New_York",
    "ILM": "America/New_York", "MHX": "America/New_York", "RAH": "America/New_York",
    "GSP": "America/New_York", "CHS": "America/New_York", "CAE": "America/New_York",
    "JAX": "America/New_York", "MLB": "America/New_York", "MFL": "America/New_York",
    "KEY": "America/New_York", "TBW": "America/New_York", "TAE": "America/New_York",
    "FFC": "America/New_York", "RLX": "America/New_York", "JKL": "America/New_York",
    "LMK": "America/New_York", "IND": "America/Indianapolis",

    # Central Time
    "LOT": "America/Chicago", "ILX": "America/Chicago", "DVN": "America/Chicago",
    "DMX": "America/Chicago", "MPX": "America/Chicago", "DLH": "America/Chicago",
    "GRB": "America/Chicago", "MKX": "America/Chicago", "ARX": "America/Chicago",
    "EAX": "America/Chicago", "SGF": "America/Chicago", "LSX": "America/Chicago",
    "PAH": "America/Chicago", "MEG": "America/Chicago", "OHX": "America/Chicago",
    "MRX": "America/Chicago", "HUN": "America/Chicago", "BMX": "America/Chicago",
    "MOB": "America/Chicago", "JAN": "America/Chicago", "LIX": "America/Chicago",
    "LCH": "America/Chicago", "SHV": "America/Chicago", "LZK": "America/Chicago",
    "TSA": "America/Chicago", "OUN": "America/Chicago", "TUL": "America/Chicago",
    "FWD": "America/Chicago", "HGX": "America/Chicago", "CRP": "America/Chicago",
    "BRO": "America/Chicago", "EWX": "America/Chicago", "SJT": "America/Chicago",
    "AMA": "America/Chicago", "LUB": "America/Chicago", "MAF": "America/Chicago",
    "TOP": "America/Chicago", "ICT": "America/Chicago", "GID": "America/Chicago",
    "OAX": "America/Chicago", "LBF": "America/Chicago", "GLD": "America/Chicago",
    "DDC": "America/Chicago", "FSD": "America/Chicago", "ABR": "America/Chicago",
    "UNR": "America/Chicago", "BIS": "America/Chicago", "FGF": "America/Chicago",

    # Mountain Time
    "BOU": "America/Denver", "PUB": "America/Denver", "GJT": "America/Denver",
    "ABQ": "America/Denver", "EPZ": "America/Denver", "SLC": "America/Denver",
    "PIH": "America/Denver", "BOI": "America/Denver", "MSO": "America/Denver",
    "TFX": "America/Denver", "GGW": "America/Denver", "BYZ": "America/Denver",
    "RIW": "America/Denver", "CYS": "America/Denver",

    # Pacific Time
    "SEW": "America/Los_Angeles", "PDT": "America/Los_Angeles", "MFR": "America/Los_Angeles",
    "EKA": "America/Los_Angeles", "STO": "America/Los_Angeles", "REV": "America/Los_Angeles",
    "LKN": "America/Los_Angeles", "VFX": "America/Los_Angeles", "SGX": "America/Los_Angeles",
    "LOX": "America/Los_Angeles", "HNX": "America/Los_Angeles",

    # Arizona (Mountain Standard Time - no DST)
    "PSR": "America/Phoenix", "TWC": "America/Phoenix", "FGZ": "America/Phoenix",

    # Alaska/Hawaii
    "AJK": "America/Juneau", "ALU": "America/Adak", "HFO": "Pacific/Honolulu"
}

# ==================================================================================
# STATE FIPS CODES
# ==================================================================================
# Maps 2-letter state codes to 2-digit FIPS state codes

STATE_FIPS_MAP = {
    'AL': '01', 'AK': '02', 'AZ': '04', 'AR': '05', 'CA': '06', 'CO': '08', 'CT': '09', 'DE': '10', 'DC': '11', 'FL': '12',
    'GA': '13', 'HI': '15', 'ID': '16', 'IL': '17', 'IN': '18', 'IA': '19', 'KS': '20', 'KY': '21', 'LA': '22', 'ME': '23',
    'MD': '24', 'MA': '25', 'MI': '26', 'MN': '27', 'MS': '28', 'MO': '29', 'MT': '30', 'NE': '31', 'NV': '32', 'NH': '33',
    'NJ': '34', 'NM': '35', 'NY': '36', 'NC': '37', 'ND': '38', 'OH': '39', 'OK': '40', 'OR': '41', 'PA': '42', 'RI': '44',
    'SC': '45', 'SD': '46', 'TN': '47', 'TX': '48', 'UT': '49', 'VT': '50', 'VA': '51', 'WA': '53', 'WV': '54', 'WI': '55', 'WY': '56'
}

# ==================================================================================
# TIMEZONE PARSING
# ==================================================================================
# Maps timezone abbreviations to UTC offset for parsing alert expiration times
# Used when parsing text-based alerts that use timezone abbreviations

TIMEZONE_MAP = {
    'EST': timezone(timedelta(hours=-5)), 'EDT': timezone(timedelta(hours=-4)),
    'CST': timezone(timedelta(hours=-6)), 'CDT': timezone(timedelta(hours=-5)),
    'MST': timezone(timedelta(hours=-7)), 'MDT': timezone(timedelta(hours=-6)),
    'PST': timezone(timedelta(hours=-8)), 'PDT': timezone(timedelta(hours=-7)),
    'AKST': timezone(timedelta(hours=-9)), 'AKDT': timezone(timedelta(hours=-8)),
    'HST': timezone(timedelta(hours=-10)), 'UTC': timezone.utc, 'Z': timezone.utc
}

# ==================================================================================
# ALERT PRIORITY LEVELS - Now loaded from alert_types_config.json
# ==================================================================================
# ALERT_PRIORITY is imported from alert_config_loader above

# ==================================================================================
# TARGET AFD OFFICES
# ==================================================================================
# Weather Forecast Offices whose Area Forecast Discussions (AFDs) should be captured

TARGET_AFD_OFFICES = {"ILN", "IWX", "CLE", "PBZ", "RLX"}
