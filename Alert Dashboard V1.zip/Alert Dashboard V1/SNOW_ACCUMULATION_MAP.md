# Snow Accumulation Map Feature

## Overview
A brand new dashboard page that displays an interpolated gradient/heatmap visualization of snow accumulation based on actual Local Storm Reports (LSR) from the Iowa State Mesonet. This provides a visual representation similar to forecast maps but based on actual observed snow totals.

## What Was Created

### 1. New Files

#### `snow_map.html`
- Standalone HTML page with dark theme matching your dashboard aesthetic
- Header with back-to-dashboard link
- Full-screen Leaflet map
- Interactive controls panel (top-right)
- Legend showing color scale (bottom-right)
- Status indicator (top-left)

#### `snow_map.js`
- Complete JavaScript implementation with:
  - **Inverse Distance Weighting (IDW)** interpolation algorithm
  - **Nearest Neighbor** interpolation (alternative method)
  - Canvas-based gradient rendering
  - Real-time snow data fetching from API
  - Interactive report markers with popups
  - Adjustable resolution and opacity controls

### 2. Modified Files

#### `main_app.py`
- Added new `/api/snow_reports` endpoint (lines 1407-1453)
- Fetches LSR data from Iowa State Mesonet
- Filters for SNOW and HEAVY SNOW reports only
- Returns GeoJSON format with snow reports from last 24 hours
- Supports configurable states and time ranges via URL parameters

#### `index.html`
- Added navigation link to Snow Accumulation Map (line 68-70)
- Positioned after "Local Storm Reports" in the side menu
- Opens in new tab with snowflake icon

## Features

### Interpolation Methods

**Inverse Distance Weighting (IDW)** - Default
- Weights nearby snow reports based on distance
- Creates smooth gradients between observations
- Configurable power parameter (default: 2)
- Search radius: 2° (configurable)

**Nearest Neighbor**
- Assigns value of closest snow report
- Creates distinct zones around each observation
- Useful for seeing exact report influence areas

### Interactive Controls

1. **Interpolation Method Selector**
   - Switch between IDW and Nearest Neighbor
   - Changes apply immediately

2. **Resolution Slider**
   - Adjusts grid cell size (0.01° to 0.1°)
   - Smaller = higher resolution but slower
   - Default: 0.02°

3. **Opacity Slider**
   - Control transparency of gradient overlay
   - Range: 0% to 100%
   - Default: 70%

4. **Refresh Button**
   - Manually reload latest snow data
   - Automatically fetches on page load

### Color Scale

Gradient colors (purple tones matching winter weather theme):
- **Very Light Blue** (#f0f9ff): Trace - 1"
- **Light Blue-Purple** (#e0e7ff): 1" - 2"
- **Pale Purple** (#ddd6fe): 2" - 4"
- **Light Purple** (#c4b5fd): 4" - 6"
- **Medium Purple** (#a78bfa): 6" - 8"
- **Bright Purple** (#8b5cf6): 8" - 12"
- **Dark Purple** (#7c3aed): 12" - 18"
- **Very Dark Purple** (#6d28d9): 18"+

### Map Features

- **Base Layer**: Dark theme from CARTO
- **Report Markers**: Purple circle markers at each observation point
- **Popups**: Click markers to view:
  - Snow accumulation amount
  - Location (city and county)
  - Report timestamp
  - Observer remarks
- **Dynamic Updates**: Map regenerates when zooming/panning
- **Status Indicator**: Shows loading state and report count

## How It Works

### Technical Flow

1. **Data Fetching**
   - JavaScript calls `/api/snow_reports?states=OH&hours=24`
   - Backend fetches from Iowa State Mesonet API
   - Filters for SNOW/HEAVY SNOW with magnitude data
   - Returns GeoJSON to frontend

2. **Grid Creation**
   - Calculates map viewport bounds
   - Creates grid based on cell size parameter
   - Grid points spaced evenly across map area

3. **Interpolation**
   - For each grid point, calculates estimated snow value
   - IDW: Weighted average based on distance to all nearby reports
   - Nearest: Value from closest report within search radius

4. **Rendering**
   - Creates HTML5 canvas matching grid dimensions
   - Colors each pixel based on interpolated value
   - Converts canvas to image overlay
   - Places on map with geographic bounds

5. **Interactivity**
   - Map events trigger re-interpolation
   - Control changes update configuration
   - Markers layer stays on top of gradient

## Usage

### Accessing the Map

1. **From Dashboard**: Click "Snow Accumulation Map" in the side menu
2. **Direct URL**: Navigate to `http://your-server:8080/snow_map.html`

### Best Practices

- **During Active Events**: Use higher resolution (0.01°) for detailed patterns
- **Historical View**: Use lower resolution (0.05°+) for performance
- **Lake Effect Analysis**: IDW method shows gradient transitions well
- **Discrete Bands**: Nearest Neighbor shows distinct snow bands

### Comparing Interpolation Methods

**Use IDW When:**
- You want smooth transitions between observations
- Analyzing widespread precipitation events
- Creating publication-quality maps
- Multiple nearby observations exist

**Use Nearest Neighbor When:**
- You want to see discrete influence zones
- Limited observations available
- Emphasizing report locations
- Quick visualization needed

## API Details

### Endpoint: `/api/snow_reports`

**Parameters:**
- `states` (optional): Two-letter state codes, default "OH"
- `hours` (optional): Hours to look back, default "24"

**Example:**
```
/api/snow_reports?states=OH,PA&hours=48
```

**Response Format:**
```json
{
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "geometry": {
        "type": "Point",
        "coordinates": [-81.5, 41.2]
      },
      "properties": {
        "magnitude": "6.5",
        "typetext": "SNOW",
        "city": "Cleveland",
        "county": "Cuyahoga",
        "valid": "2025-12-02T10:30:00Z",
        "remark": "Measured in parking lot"
      }
    }
  ]
}
```

## Configuration

All configuration is in `snow_map.js`:

```javascript
const config = {
    defaultCenter: [40.4, -82.9],  // Ohio center
    defaultZoom: 7,
    cellSize: 0.02,                 // Grid resolution
    opacity: 0.7,                   // Overlay opacity
    interpolationMethod: 'idw',     // 'idw' or 'nearest'
    idwPower: 2,                    // IDW power parameter
    searchRadius: 2.0               // Search radius in degrees
};
```

## Performance Considerations

- **Cell Size Impact**: Smaller cells = more calculations
  - 0.01°: ~40,000 grid points (high quality, slower)
  - 0.02°: ~10,000 grid points (balanced, default)
  - 0.05°: ~1,600 grid points (fast, lower quality)

- **Map Viewport**: Larger viewport = more grid points
  - Zooming in reduces calculations
  - Zooming out increases calculations

- **Optimization**: Canvas rendering is fast, interpolation is the bottleneck

## Future Enhancement Ideas

1. **Time Series Animation**: Show snow accumulation evolution over time
2. **Contour Lines**: Add isoline overlays for specific amounts (4", 8", 12")
3. **Multi-Source Data**: Combine LSR with NWS observation stations
4. **Export Options**: Download as GeoTIFF or image
5. **Comparison Mode**: Side-by-side forecast vs. observed
6. **Statistics Panel**: Show max, min, average accumulations
7. **Custom Color Scales**: User-defined color ramps
8. **Mobile Optimization**: Touch-friendly controls

## Troubleshooting

**Problem**: "No snow reports in the last 24 hours"
- **Solution**: This is normal during non-snow periods. Check back during winter weather events.

**Problem**: Map shows only a few small colored areas
- **Solution**: Increase search radius or decrease cell size for better coverage.

**Problem**: Performance is slow
- **Solution**: Increase cell size (lower resolution) or zoom in to reduce viewport.

**Problem**: Colors don't match between reports and gradient
- **Solution**: This is expected - interpolation smooths values. Use Nearest Neighbor for exact report zones.

**Problem**: Gradient doesn't update after changing controls
- **Solution**: Map auto-updates on pan/zoom. Try moving the map slightly.

## Files Summary

| File | Purpose | Lines |
|------|---------|-------|
| `snow_map.html` | Main page structure and styling | ~300 |
| `snow_map.js` | Interpolation and rendering logic | ~440 |
| `main_app.py` | API endpoint for snow data | +47 |
| `index.html` | Navigation menu link | +3 |

## Technical Notes

- **Coordinate System**: WGS84 (EPSG:4326)
- **Distance Calculation**: Simple Euclidean approximation (sufficient for small regions)
- **Canvas Size**: Matches grid dimensions (not screen pixels)
- **Image Format**: Data URL (PNG) from canvas
- **Layer Order**: Canvas → Report Markers → Controls/Legend

---

**Created**: December 2, 2025
**Version**: 1.0
**Status**: ✅ Ready for use
