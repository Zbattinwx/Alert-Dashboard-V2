# Documentation Archive

This folder contains older documentation files that have been consolidated into the main user guides.

## Current Documentation

Please refer to these updated guides in the root directory:
- **[README.md](../README.md)** - Main project overview and quick links
- **[LOCAL_SETUP_GUIDE.md](../LOCAL_SETUP_GUIDE.md)** - Complete guide for self-hosting
- **[REMOTE_ACCESS_GUIDE.md](../REMOTE_ACCESS_GUIDE.md)** - Complete guide for remote access

## Archived Files

These files are kept for reference but may contain outdated information:
- `UserGuide.txt` - Original user guide (replaced by LOCAL_SETUP_GUIDE.md and REMOTE_ACCESS_GUIDE.md)
- `QUICK_START.txt` - Quick start for adding alerts (see ADDING_NEW_ALERTS_GUIDE.md)
- `QUICK_START_STORM_REPORTS.txt` - Storm report quick start (see STORM_REPORT_FEATURE_SUMMARY.md)
- `QUICK_RESTORE_GUIDE.txt` - Backup restoration guide
- `exe script.txt` - Build script notes
- `api_example_alerts.txt` - API example data
- `sample_alert.txt` - Sample alert data
- `sps_examples.txt` - Special weather statement examples
- `sv_examples.txt` - Severe thunderstorm warning examples

## Active Technical Documentation

These technical docs are still current and located in the root directory:
- **[ADDING_NEW_ALERTS_GUIDE.md](../ADDING_NEW_ALERTS_GUIDE.md)** - How to add new alert types
- **[ARCHITECTURE.md](../ARCHITECTURE.md)** - System architecture
- **[STORM_REPORT_FEATURE_SUMMARY.md](../STORM_REPORT_FEATURE_SUMMARY.md)** - Storm reporting system
- **[SNOW_FEATURE_QUICK_START.md](../SNOW_FEATURE_QUICK_START.md)** - Snow visualization features
- **[DAILY_RECAP_IMPLEMENTATION.md](../DAILY_RECAP_IMPLEMENTATION.md)** - Daily statistics
- **[TESTING_GUIDE.md](../TESTING_GUIDE.md)** - Testing procedures
- **[DYNAMIC_STYLING_GUIDE.md](../DYNAMIC_STYLING_GUIDE.md)** - Alert styling system
- **[USER_PREFERENCE_SYSTEM.md](../USER_PREFERENCE_SYSTEM.md)** - User preferences
