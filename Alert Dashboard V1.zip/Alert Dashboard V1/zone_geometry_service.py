# zone_geometry_service.py
# ==================================================================================
# ZONE GEOMETRY SERVICE
# ==================================================================================
# This service handles fetching and caching zone boundary geometries from the NWS API.
# Zone-based alerts (advisories, watches) need precise zone boundaries instead of
# entire county outlines for accurate map rendering.
# ==================================================================================

import aiohttp
from typing import Optional, List
from alert import Alert
from logger import get_logger


class ZoneGeometryService:
    """
    Service for fetching and caching zone geometry data from NWS API.
    Consolidates all zone geometry operations in one place.
    """

    def __init__(self):
        """Initialize the service with an empty cache."""
        self.cache = {}
        self.user_agent = "WeatherWiseDashboard/1.0"
        self.logger = get_logger()

    async def fetch_zone_geometry(self, ugc_code: str, session: aiohttp.ClientSession) -> Optional[List]:
        """
        Fetches the precise zone boundary geometry from the NWS API for a given UGC zone code.
        Returns a list of polygon coordinates in [lat, lon] format, or None if unavailable.

        Args:
            ugc_code: The UGC zone code (e.g., "MTZ301")
            session: Active aiohttp ClientSession for making requests

        Returns:
            List of polygons (each polygon is a list of [lat, lon] coordinates), or None

        Example:
            fetch_zone_geometry("MTZ301") returns the boundary for East Glacier Park Region
        """
        # Check cache first
        if ugc_code in self.cache:
            return self.cache[ugc_code]

        # Only fetch for zone codes (not county codes)
        if not ugc_code or len(ugc_code) < 5 or ugc_code[2] != 'Z':
            return None

        try:
            # Build the API URL for the zone
            # Format: https://api.weather.gov/zones/forecast/MTZ301
            zone_url = f"https://api.weather.gov/zones/forecast/{ugc_code}"

            headers = {"User-Agent": self.user_agent}
            async with session.get(zone_url, headers=headers) as response:
                if response.status != 200:
                    self.logger.debug(f"⚠️ Could not fetch zone geometry for {ugc_code}: HTTP {response.status}")
                    self.cache[ugc_code] = None
                    return None

                data = await response.json()
                geometry = data.get("geometry")

                if not geometry:
                    self.logger.debug(f"⚠️ No geometry available for zone {ugc_code}")
                    self.cache[ugc_code] = None
                    return None

                geom_type = geometry.get("type")
                coordinates = geometry.get("coordinates", [])
                polygon_list = []

                # Handle both Polygon and MultiPolygon geometries
                if geom_type == "Polygon":
                    outer_ring = coordinates[0]
                    # Swap lon,lat to lat,lon for Leaflet
                    swapped_coords = [[lat, lon] for lon, lat in outer_ring]
                    polygon_list.append(swapped_coords)

                elif geom_type == "MultiPolygon":
                    for polygon_coords in coordinates:
                        outer_ring = polygon_coords[0]
                        swapped_coords = [[lat, lon] for lon, lat in outer_ring]
                        polygon_list.append(swapped_coords)

                # Cache the result
                self.cache[ugc_code] = polygon_list if polygon_list else None

                if polygon_list:
                    self.logger.debug(f"✅ Fetched zone geometry for {ugc_code}: {len(polygon_list)} polygon(s)")

                return polygon_list

        except Exception as e:
            self.logger.warning(f"❌ Error fetching zone geometry for {ugc_code}: {e}")
            self.cache[ugc_code] = None
            return None

    async def populate_alert_with_zone_geometry(self, alert: Alert, session: aiohttp.ClientSession) -> None:
        """
        Populates an alert with zone geometry if it has zone codes but no polygon.

        Args:
            alert: The Alert object to populate
            session: Active aiohttp ClientSession for making requests

        Modifies:
            alert.polygon - Sets to list of zone polygons if available
        """
        # Skip if alert already has a polygon or no affected areas
        if alert.polygon or not alert.affected_areas:
            return

        # Extract zone codes (UGC codes with 'Z' in position 2)
        zone_codes = [ugc for ugc in alert.affected_areas if len(ugc) >= 5 and ugc[2] == 'Z']

        if not zone_codes:
            return

        self.logger.debug(f"🗺️ Alert {alert.product_id} has {len(zone_codes)} zone code(s) but no polygon. Fetching zone geometry...")

        # Fetch geometry for all zone codes in parallel
        import asyncio
        zone_geometry_tasks = [self.fetch_zone_geometry(zone, session) for zone in zone_codes]
        zone_geometries = await asyncio.gather(*zone_geometry_tasks)

        # Combine all zone polygons into the alert's polygon field
        all_zone_polygons = []
        for geometry in zone_geometries:
            if geometry:
                all_zone_polygons.extend(geometry)

        if all_zone_polygons:
            # Store as a list of polygons (dashboard.js expects this format)
            alert.polygon = all_zone_polygons
            self.logger.debug(f"✅ Successfully added {len(all_zone_polygons)} zone polygon(s) to alert {alert.product_id}")

    def clear_cache(self) -> None:
        """Clears the geometry cache. Useful for testing or memory management."""
        self.cache.clear()
        self.logger.debug("🗑️ Zone geometry cache cleared")

    def get_cache_size(self) -> int:
        """Returns the number of cached zone geometries."""
        return len(self.cache)

    def get_cache_stats(self) -> dict:
        """Returns statistics about the cache."""
        cached_count = sum(1 for v in self.cache.values() if v is not None)
        failed_count = sum(1 for v in self.cache.values() if v is None)
        return {
            "total_cached": len(self.cache),
            "successful": cached_count,
            "failed": failed_count
        }
