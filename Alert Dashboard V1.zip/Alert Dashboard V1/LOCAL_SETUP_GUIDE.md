# ONW Alert Dashboard - Local Setup Guide

This guide will walk you through setting up and running the ONW Alert Dashboard entirely on your local PC.

## Overview

The ONW Alert Dashboard is a real-time weather alert monitoring and broadcasting system that:
- Connects to NWS Weather Wire (NWWS-OI) for real-time weather alerts
- Displays alerts on an interactive dashboard
- Provides OBS-ready widgets for streaming
- Tracks storm reports, snow accumulation, and other weather data

## Prerequisites

### System Requirements
- **Windows 10/11** (or any OS with Python 3.9+)
- **Python 3.9 or higher** ([Download here](https://www.python.org/downloads/))
- **Web Browser** (Chrome, Firefox, or Edge recommended)
- **Internet Connection** (for receiving NWS data)

### Optional
- **OBS Studio** (if you plan to use streaming widgets)

## Installation Steps

### 1. Install Python

1. Download Python 3.9 or higher from [python.org](https://www.python.org/downloads/)
2. During installation, **check the box** "Add Python to PATH"
3. Verify installation by opening Command Prompt and typing:
   ```bash
   python --version
   ```
   You should see something like `Python 3.9.x` or higher

### 2. Install Required Python Packages

Open Command Prompt in your project directory and run:

```bash
pip install slixmpp websockets aiohttp aiofiles google-auth google-auth-oauthlib google-api-python-client schedule pytz
```

These packages provide:
- **slixmpp**: XMPP connection to NWS Weather Wire
- **websockets**: Real-time dashboard updates
- **aiohttp**: Async HTTP requests to NWS API
- **aiofiles**: Async file operations
- **google-***: Google Chat integration (optional)
- **schedule**: Automated tasks
- **pytz**: Timezone handling

### 3. Configure the Application

#### A. Configure Backend (`config.json`)

Open `config.json` in a text editor and configure:

```json
{
  "alert_source": "nwws",
  "nwws_credentials": {
    "username": "your_nwws_username",
    "password": "your_nwws_password"
  },
  "filters": {
    "states": ["OH", "IN", "MI"],
    "offices": [],
    "ugc_codes": []
  },
  "dashboard_password": "YourSecurePassword123",
  "ticker_rotation_speed_ms": 10000,
  "ticker_no_alerts_message": "NO ACTIVE ALERTS",
  "send_google_chat_alerts": false,
  "enable_storm_threat": false,
  "restart_interval_hours": 24,
  "log_level": "normal"
}
```

**Key Configuration Options:**
- **alert_source**: Use `"nwws"` for real-time alerts or `"nws_api"` for polling
- **nwws_credentials**: Your NWWS-OI credentials ([Get credentials here](https://www.weather.gov/nwws/))
- **filters.states**: Array of 2-letter state codes to monitor (e.g., `["OH", "IN"]`)
- **dashboard_password**: Password to access the dashboard
- **ticker_rotation_speed_ms**: How fast alerts scroll on the ticker (milliseconds)

#### B. Configure Frontend (`frontend_config.js`)

Open `frontend_config.js` and ensure it's set for localhost:

```javascript
const CONFIG = {
    websocket_url: "ws://localhost:8765",
    odot_api_key: "your_odot_api_key_here",
    "enable_obs_integration": false,
    "winter_mode_enabled": false
};
```

**Important:** The WebSocket URL must be `ws://localhost:8765` for local hosting.

## Running the Dashboard

### Method 1: Using the Batch File (Recommended)

1. Double-click `start.bat` in the project folder
2. A Command Prompt window will open showing server logs
3. The server will automatically restart if it crashes
4. To stop the server, close the Command Prompt window

### Method 2: Manual Python Command

1. Open Command Prompt in the project directory
2. Run:
   ```bash
   python main_app.py
   ```
3. Press `Ctrl+C` to stop the server

### What You Should See

When the server starts successfully, you'll see:
```
INFO - WebSocket server started on ws://0.0.0.0:8765
INFO - HTTP server started on http://0.0.0.0:8080
INFO - Dashboard is ready at http://localhost:8080/index.html
INFO - Connecting to NWWS-OI...
INFO - NWWS-OI connection established
```

## Accessing the Dashboard

### Main Dashboard

1. Open your web browser
2. Navigate to: `http://localhost:8080/index.html`
3. Enter your dashboard password (set in `config.json`)
4. You're in! The dashboard will show active weather alerts

### Dashboard Sections

- **Director Panel**: Control OBS scenes and sources (requires OBS WebSocket plugin)
- **Active Alerts**: Real-time weather warnings color-coded by severity
- **Alert Map**: Interactive map showing warning polygons
- **Local Storm Reports**: User-submitted storm reports
- **Snow Accumulation Map**: Snow depth visualization
- **ODOT Feeds**: Ohio traffic camera feeds
- **SPC Outlooks**: Storm Prediction Center outlooks
- **Mesoscale Discussions**: SPC mesoscale discussions
- **Area Forecast Discussions**: Detailed forecasts from NWS offices
- **Top Wind Gusts**: Highest wind gusts from Tempest stations
- **Daily Recap**: Statistics for the day's alerts
- **Ticker Settings**: Customize the alert ticker

## OBS Studio Integration

If you're streaming weather coverage with OBS, you can add browser sources to display alerts.

### Available OBS Widgets

All widgets are accessed at `http://localhost:8080/[widget_name].html`

#### 1. Alert Ticker
- **URL**: `http://localhost:8080/ticker.html`
- **Purpose**: Scrolling ticker showing active alerts
- **Recommended Size**: 1920x80 (full width bottom)
- **Features**: Auto-updates, customizable speed, sponsor logo support

#### 2. Sponsored Ticker (with logo)
- **URL**: `http://localhost:8080/ticker-sponsored.html`
- **Purpose**: Ticker with sponsor logo
- **Recommended Size**: 1920x100

#### 3. Featured Alert Widget
- **URL**: `http://localhost:8080/feature.html`
- **Purpose**: Large graphic for a single high-priority alert
- **Recommended Size**: 800x600
- **Usage**: Click the star icon on any alert in the dashboard to feature it
- **Auto-hides**: After 20 seconds

#### 4. New Alert Chime
- **URL**: `http://localhost:8080/new_alert.html`
- **Purpose**: Audio/visual notification when a tornado, severe thunderstorm, or flash flood warning is issued
- **Recommended Size**: 600x200
- **Auto-hides**: After 5 seconds

#### 5. Alert Rotator
- **URL**: `http://localhost:8080/rotator.html`
- **Purpose**: Automatically cycles through active alert titles
- **Recommended Size**: 600x100

#### 6. Lower Third
- **URL**: `http://localhost:8080/lower_third.html`
- **Purpose**: Professional lower third graphic for names/titles
- **Recommended Size**: 1920x200
- **Usage**: Control from Director Panel in dashboard

#### 7. Camera Widget
- **URL**: `http://localhost:8080/camera_widget.html`
- **Purpose**: Display single ODOT traffic camera
- **Recommended Size**: 640x480
- **Usage**: Click "Feature in OBS" on ODOT Feeds page

#### 8. Camera Rotator
- **URL**: `http://localhost:8080/camera_rotator.html`
- **Purpose**: Automatically cycle through multiple cameras
- **Recommended Size**: 640x480

### Adding a Widget to OBS

1. In OBS, add a new **Browser Source**
2. Set the URL to the widget (e.g., `http://localhost:8080/ticker.html`)
3. Set width and height (see recommended sizes above)
4. Check "Shutdown source when not visible" to save resources
5. Click OK

The widget will automatically connect to your dashboard and update in real-time.

## Themes

The dashboard supports multiple visual themes:

- **Classic** (default)
- **Atmospheric**
- **Storm Chaser**
- **Meteorologist**
- **Winter**

Change themes in the dashboard settings (gear icon in top right).

## Adding New Alert Types

All alert types are configured in a single file: `alert_types_config.json`

### To Add a New Alert Type:

1. Open `alert_types_config.json`
2. Add a new alert object to the `alert_types` array:

```json
{
  "phenomenon_code": "BZ",
  "nws_event_name": "Blizzard Warning",
  "display_name": "Blizzard Warning",
  "short_name": "Blizzard",
  "priority": 6,
  "high_priority": true,
  "show_on_map": true,
  "icon": "fas fa-wind",
  "colors": {
    "primary": "#FF4500",
    "css_var": "#FF4500",
    "state_map": "#FF4500",
    "daily_recap": "#FF4500"
  },
  "map_style": {
    "color": "#FF4500",
    "weight": 3,
    "fillOpacity": 0.5
  }
}
```

3. Save the file
4. Restart the Python backend
5. The new alert type is now tracked everywhere!

See [ADDING_NEW_ALERTS_GUIDE.md](ADDING_NEW_ALERTS_GUIDE.md) for details.

## Storm Report Submission

Users can submit storm reports via the form at:
`http://localhost:8080/submit_report.html`

### Features:
- Location-based (uses browser geolocation or manual entry)
- Photo uploads
- Report types: Tornado, Funnel Cloud, Hail, Wind Damage, Flooding
- Optional Google reCAPTCHA to prevent spam
- Reports appear immediately on the dashboard

### Managing Storm Reports

Admin can block/unblock IPs from submitting reports:
1. Go to `http://localhost:8080/admin_blocklist.html`
2. Enter the dashboard password
3. View, block, or unblock IP addresses

## Troubleshooting

### Dashboard Won't Load

**Problem**: Browser shows "Can't connect" or "Connection refused"

**Solutions**:
1. Verify the Python server is running (check Command Prompt window)
2. Check if port 8080 is already in use by another program
3. Try accessing `http://127.0.0.1:8080/index.html` instead

### No Alerts Appearing

**Problem**: Dashboard loads but shows no alerts even during active weather

**Solutions**:
1. Check NWWS credentials in `config.json`
2. Verify your state filters in `config.json` (e.g., `["OH"]`)
3. Check server logs for connection errors
4. Try changing `"alert_source"` to `"nws_api"` for testing

### OBS Widgets Not Updating

**Problem**: Widgets in OBS are frozen or showing old data

**Solutions**:
1. Verify `frontend_config.js` has `websocket_url: "ws://localhost:8765"`
2. Refresh the browser source in OBS (right-click → Refresh)
3. Check browser console for errors (right-click widget → Interact → F12)
4. Ensure firewall isn't blocking WebSocket connections

### Python Package Errors

**Problem**: `ModuleNotFoundError` when starting server

**Solution**:
```bash
pip install slixmpp websockets aiohttp aiofiles schedule pytz
```

### Port Already in Use

**Problem**: `OSError: [Errno 48] Address already in use`

**Solutions**:
1. Stop any other instances of `main_app.py`
2. Change ports in `main_app.py` (search for `8080` and `8765`)
3. Restart your computer to free stuck ports

## Advanced Configuration

### Google Chat Integration

To send alerts to Google Chat:

1. Set `"send_google_chat_alerts": true` in `config.json`
2. Add your Google Chat webhook URL to `google_chat_webhook_url`
3. Restart the server

### Storm Threat Integration

To enable storm threat indicators:

1. Set `"enable_storm_threat": true` in `config.json`
2. Ensure storm threat JSON file is available
3. Restart the server

### OBS WebSocket Control

To control OBS from the dashboard:

1. Install OBS WebSocket plugin ([obs-websocket](https://github.com/obsproject/obs-websocket))
2. Set `"enable_obs_integration": true` in `frontend_config.js`
3. Configure OBS WebSocket password in dashboard settings

### Auto-Restart Configuration

The server can automatically restart on a schedule:

```json
{
  "restart_interval_hours": 24
}
```

Set to `0` to disable auto-restart.

## File Structure

```
ONWAlertDashboard/
├── main_app.py                 # Main backend server
├── config.json                 # Backend configuration
├── frontend_config.js          # Frontend configuration
├── alert_types_config.json     # Alert type definitions
├── start.bat                   # Windows startup script
├── index.html                  # Main dashboard page
├── dashboard.js                # Dashboard logic
├── dashboard.css               # Dashboard styles
├── ticker.html                 # OBS ticker widget
├── feature.html                # OBS featured alert widget
├── new_alert.html              # OBS alert chime widget
├── lower_third.html            # OBS lower third widget
├── rotator.html                # OBS rotator widget
├── camera_widget.html          # OBS camera widget
├── submit_report.html          # Storm report submission form
├── snow_map.html               # Snow accumulation map
├── alert_parser.py             # Alert parsing logic
├── alert_manager.py            # Alert state management
├── zone_geometry_service.py    # Geographic data handling
├── message_broker.py           # WebSocket communication
├── constants.py                # Shared constants
├── ugc_parser.py              # UGC code parsing
└── logs/                       # Application logs
```

## Additional Resources

- **Adding Alerts**: See [ADDING_NEW_ALERTS_GUIDE.md](ADDING_NEW_ALERTS_GUIDE.md)
- **Architecture**: See [ARCHITECTURE.md](ARCHITECTURE.md)
- **Storm Reports**: See [STORM_REPORT_FEATURE_SUMMARY.md](STORM_REPORT_FEATURE_SUMMARY.md)
- **Snow Features**: See [SNOW_FEATURE_QUICK_START.md](SNOW_FEATURE_QUICK_START.md)
- **Testing**: See [TESTING_GUIDE.md](TESTING_GUIDE.md)

## Getting NWWS-OI Credentials

To receive real-time alerts from NWS Weather Wire:

1. Visit [https://www.weather.gov/nwws/](https://www.weather.gov/nwws/)
2. Click "Request an Account"
3. Fill out the registration form
4. Wait for approval (usually 1-2 business days)
5. Add credentials to `config.json`

## Support

For issues, questions, or feature requests:
- Check existing documentation files
- Review server logs in the Command Prompt window
- Verify configuration files are valid JSON

## License

This dashboard is for personal/educational use. Weather data is provided by the National Weather Service.

---

**Happy Weather Tracking!**
