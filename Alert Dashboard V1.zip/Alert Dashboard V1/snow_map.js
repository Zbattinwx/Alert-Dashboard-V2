// Snow Accumulation Map JavaScript
// Displays an interpolated gradient map of snow accumulation based on LSR data

let snowMap;
let canvasOverlay;
let snowReports = [];
let reportMarkers = L.layerGroup();
let ohioBoundary = null; // Will store Ohio polygon for clipping

// Configuration
const config = {
    defaultCenter: [40.4, -82.9], // Ohio center
    defaultZoom: 7,
    cellSize: 0.015, // Grid cell size in degrees (smaller = smoother)
    opacity: 0.75,
    interpolationMethod: 'idw', // 'idw' or 'nearest'
    idwPower: 2.5, // Power parameter for IDW (higher = more localized)
    searchRadius: 1.5 // Search radius in degrees for IDW
};

// Color scale presets (min-max ranges with discrete colors)
const colorScalePresets = {
    default: [
        { min: 0, max: 1, color: [30, 60, 140] },      // Dark blue
        { min: 1, max: 2, color: [50, 110, 220] },     // Bright blue
        { min: 2, max: 4, color: [80, 170, 255] },     // Sky blue
        { min: 4, max: 6, color: [100, 200, 255] },    // Cyan blue
        { min: 6, max: 8, color: [120, 220, 240] },    // Light cyan
        { min: 8, max: 10, color: [140, 235, 220] },   // Cyan
        { min: 10, max: 12, color: [160, 245, 200] },  // Cyan-green
        { min: 12, max: 18, color: [180, 250, 180] },  // Light green
        { min: 18, max: 999, color: [220, 255, 140] }  // Bright yellow-green
    ],
    forecast: [
        { min: 0, max: 1, color: [224, 224, 224] },    // ≤1" - Light gray/white
        { min: 1, max: 2, color: [108, 194, 233] },    // 1-2" - Light blue
        { min: 2, max: 4, color: [43, 140, 190] },     // 2-4" - Blue
        { min: 4, max: 8, color: [30, 71, 137] },      // 4-8" - Dark blue
        { min: 8, max: 12, color: [124, 90, 164] },    // 8-12" - Purple
        { min: 12, max: 16, color: [212, 63, 63] },    // 12-16" - Red-orange
        { min: 16, max: 999, color: [240, 35, 117] }   // 16"+ - Pink/magenta
    ]
};

// Active color scale
let colorScale = [...colorScalePresets.default];
let useDiscreteColors = true; // Use discrete ranges instead of interpolation

/**
 * Initialize the Leaflet map
 */
function initMap() {
    console.log('Initializing map...');
    console.log('Leaflet available:', typeof L !== 'undefined');

    try {
        snowMap = L.map('snow-map').setView(config.defaultCenter, config.defaultZoom);
        console.log('Map object created');

        // Dark base layer
        L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>',
            subdomains: 'abcd',
            maxZoom: 20
        }).addTo(snowMap);
        console.log('Base layer added');

        // Add report markers layer
        reportMarkers.addTo(snowMap);

        console.log('Map initialized successfully');
    } catch (error) {
        console.error('Error initializing map:', error);
        updateStatus('error', 'Failed to initialize map: ' + error.message);
    }
}

/**
 * Fetch Ohio state boundary from Census Bureau
 */
async function fetchOhioBoundary() {
    try {
        // Fetch Ohio boundary from US Census Bureau
        const response = await fetch('https://raw.githubusercontent.com/python-visualization/folium/master/examples/data/us-states.json');
        const data = await response.json();

        // Find Ohio feature
        const ohioFeature = data.features.find(f => f.properties.name === 'Ohio');
        if (ohioFeature) {
            ohioBoundary = ohioFeature.geometry;
            console.log('Ohio boundary loaded');
        }
    } catch (error) {
        console.error('Could not load Ohio boundary:', error);
    }
}

/**
 * Check if a point is inside Ohio using ray casting algorithm
 */
function isPointInOhio(lat, lon) {
    if (!ohioBoundary) return true; // If boundary not loaded, show everything

    // Handle MultiPolygon or Polygon
    const polygons = ohioBoundary.type === 'MultiPolygon'
        ? ohioBoundary.coordinates
        : [ohioBoundary.coordinates];

    for (const polygon of polygons) {
        for (const ring of polygon) {
            if (pointInPolygon([lon, lat], ring)) {
                return true;
            }
        }
    }
    return false;
}

/**
 * Point in polygon test using ray casting
 */
function pointInPolygon(point, polygon) {
    const x = point[0], y = point[1];
    let inside = false;

    for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
        const xi = polygon[i][0], yi = polygon[i][1];
        const xj = polygon[j][0], yj = polygon[j][1];

        const intersect = ((yi > y) !== (yj > y))
            && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
        if (intersect) inside = !inside;
    }

    return inside;
}

/**
 * Fetch snow report data from the API
 */
async function fetchSnowData() {
    updateStatus('loading', 'Fetching snow data...');

    try {
        // Get hours from input, default to 24
        const hoursBack = document.getElementById('hours-back')?.value || 24;

        // Fetch from Ohio AND surrounding states for better border interpolation
        const response = await fetch(`/api/snow_reports?states=OH,PA,WV,KY,IN,MI&hours=${hoursBack}`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        snowReports = data.features.map(feature => ({
            lat: feature.geometry.coordinates[1],
            lon: feature.geometry.coordinates[0],
            magnitude: parseFloat(feature.properties.magnitude),
            city: feature.properties.city || 'Unknown',
            county: feature.properties.county || '',
            time: feature.properties.valid || '',
            remark: feature.properties.remark || '',
            type: feature.properties.typetext || ''  // Include the type to distinguish viewer reports
        }));

        console.log(`Loaded ${snowReports.length} snow reports`);

        if (snowReports.length === 0) {
            updateStatus('ready', `No snow reports in the last ${hoursBack} hours`);
            return;
        }

        // Add markers for each report
        addReportMarkers();

        // Generate the interpolated snow map
        generateSnowMap();

        // Count Ohio vs surrounding reports
        const ohioReports = snowReports.filter(r => isPointInOhio(r.lat, r.lon)).length;
        const surroundingReports = snowReports.length - ohioReports;

        updateStatus('ready', `Displaying Ohio data (${ohioReports} OH reports, ${surroundingReports} border)`);
    } catch (error) {
        console.error('Error fetching snow data:', error);
        updateStatus('error', `Error: ${error.message}`);
    }
}

/**
 * Add point markers for each snow report (Ohio only for display)
 */
function addReportMarkers() {
    reportMarkers.clearLayers();

    // Only add markers for Ohio reports to improve performance
    snowReports.forEach(report => {
        // Skip markers outside Ohio
        if (!isPointInOhio(report.lat, report.lon)) {
            return;
        }

        // Distinguish viewer reports from official reports
        const isViewerReport = report.type === 'VIEWER_SNOW';
        const markerColor = isViewerReport ? '#bb9af7' : '#d946ef';
        const markerIcon = isViewerReport ? 'eye' : 'snowflake';

        const marker = L.circleMarker([report.lat, report.lon], {
            radius: isViewerReport ? 6 : 5,
            fillColor: markerColor,
            color: '#fff',
            weight: 1.5,
            opacity: 1,
            fillOpacity: 0.7
        });

        const reportTypeLabel = isViewerReport
            ? `<i class="fas fa-${markerIcon}"></i> Viewer Report`
            : `<i class="fas fa-${markerIcon}"></i> Official Report`;

        const reportBannerText = isViewerReport ? 'Viewer Report' : 'Official Report';

        const popupContent = `
            <div class="snow-popup">
                <div style="background: rgba(${isViewerReport ? '187, 154, 247' : '217, 70, 239'}, 0.2); padding: 6px; border-radius: 4px; margin-bottom: 8px;">
                    <h4 style="margin: 0; color: ${markerColor};"><i class="fas fa-${markerIcon}"></i> ${reportBannerText}</h4>
                </div>
                <p><strong>Amount:</strong> ${report.magnitude}" Snow</p>
                <p><strong>Location:</strong> ${report.city}${report.county ? ', ' + report.county : ''}</p>
                <p><strong>Time:</strong> ${new Date(report.time).toLocaleString()}</p>
                ${report.remark ? `<p><strong>Remarks:</strong> ${report.remark}</p>` : ''}
            </div>
        `;

        marker.bindPopup(popupContent);
        marker.addTo(reportMarkers);
    });

    console.log(`Added ${reportMarkers.getLayers().length} markers (Ohio only)`);
}

/**
 * Generate the interpolated snow accumulation map
 */
function generateSnowMap() {
    if (snowReports.length === 0) {
        console.log('No snow reports to interpolate');
        return;
    }

    // Calculate map bounds
    const bounds = snowMap.getBounds();
    const minLat = bounds.getSouth();
    const maxLat = bounds.getNorth();
    const minLon = bounds.getWest();
    const maxLon = bounds.getEast();

    // Create grid
    const grid = createGrid(minLat, maxLat, minLon, maxLon);

    // Interpolate values
    const interpolatedGrid = interpolateGrid(grid);

    // Render to canvas
    renderToCanvas(interpolatedGrid, minLat, maxLat, minLon, maxLon);
}

/**
 * Create a grid of points for interpolation
 */
function createGrid(minLat, maxLat, minLon, maxLon) {
    const grid = [];
    const cellSize = config.cellSize;

    for (let lat = minLat; lat <= maxLat; lat += cellSize) {
        for (let lon = minLon; lon <= maxLon; lon += cellSize) {
            grid.push({ lat, lon, value: null });
        }
    }

    return grid;
}

/**
 * Interpolate snow values across the grid using the selected method
 */
function interpolateGrid(grid) {
    if (config.interpolationMethod === 'idw') {
        return grid.map(point => ({
            ...point,
            value: interpolateIDW(point.lat, point.lon)
        }));
    } else {
        return grid.map(point => ({
            ...point,
            value: interpolateNearest(point.lat, point.lon)
        }));
    }
}

/**
 * Inverse Distance Weighting (IDW) interpolation
 */
function interpolateIDW(lat, lon) {
    let numerator = 0;
    let denominator = 0;
    const power = config.idwPower;
    const searchRadius = config.searchRadius;

    // Find all reports within search radius
    const nearbyReports = snowReports.filter(report => {
        const dist = distance(lat, lon, report.lat, report.lon);
        return dist <= searchRadius;
    });

    if (nearbyReports.length === 0) {
        return null; // No data in this area
    }

    // Check if we're very close to a report point
    for (const report of nearbyReports) {
        const dist = distance(lat, lon, report.lat, report.lon);
        if (dist < 0.001) {
            return report.magnitude;
        }
    }

    // Apply IDW formula
    for (const report of nearbyReports) {
        const dist = distance(lat, lon, report.lat, report.lon);
        const weight = 1 / Math.pow(dist, power);
        numerator += weight * report.magnitude;
        denominator += weight;
    }

    return denominator > 0 ? numerator / denominator : null;
}

/**
 * Nearest neighbor interpolation
 */
function interpolateNearest(lat, lon) {
    let nearest = null;
    let minDist = Infinity;

    for (const report of snowReports) {
        const dist = distance(lat, lon, report.lat, report.lon);
        if (dist < minDist) {
            minDist = dist;
            nearest = report;
        }
    }

    // Only use if within search radius
    return minDist <= config.searchRadius ? nearest.magnitude : null;
}

/**
 * Calculate distance between two lat/lon points (simple Euclidean approximation)
 */
function distance(lat1, lon1, lat2, lon2) {
    const dlat = lat2 - lat1;
    const dlon = lon2 - lon1;
    return Math.sqrt(dlat * dlat + dlon * dlon);
}

/**
 * Get color for a snow accumulation value (discrete ranges)
 */
function getColorForValue(value) {
    if (value === null || value === undefined || value < 0) {
        return null;
    }

    // Find the range this value falls into
    for (const range of colorScale) {
        if (value >= range.min && value < range.max) {
            return range.color;
        }
    }

    // If value is beyond the last range, use the last color
    return colorScale[colorScale.length - 1].color;
}

/**
 * Render the interpolated grid to a canvas overlay
 */
function renderToCanvas(grid, minLat, maxLat, minLon, maxLon) {
    // Remove existing canvas overlay if present
    if (canvasOverlay) {
        snowMap.removeLayer(canvasOverlay);
    }

    // Create canvas element
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    // Calculate grid dimensions
    const cellSize = config.cellSize;
    const cols = Math.ceil((maxLon - minLon) / cellSize);
    const rows = Math.ceil((maxLat - minLat) / cellSize);

    // Set canvas size
    canvas.width = cols;
    canvas.height = rows;

    // Draw grid cells (only within Ohio boundary)
    let idx = 0;
    for (let row = 0; row < rows; row++) {
        for (let col = 0; col < cols; col++) {
            if (idx >= grid.length) break;

            const point = grid[idx++];

            // Only draw if point is inside Ohio
            if (point.value !== null && isPointInOhio(point.lat, point.lon)) {
                const color = getColorForValue(point.value);
                if (color) {
                    ctx.fillStyle = `rgba(${color[0]}, ${color[1]}, ${color[2]}, ${config.opacity})`;
                    ctx.fillRect(col, rows - row - 1, 1, 1); // Flip vertically
                }
            }
        }
    }

    // Create Leaflet image overlay from canvas
    const bounds = [[minLat, minLon], [maxLat, maxLon]];
    canvasOverlay = L.imageOverlay(canvas.toDataURL(), bounds, {
        opacity: 1,
        interactive: false
    });

    canvasOverlay.addTo(snowMap);
    canvasOverlay.bringToBack(); // Keep markers on top

    console.log('Canvas overlay rendered');
}

/**
 * Update status indicator
 */
function updateStatus(state, text) {
    const statusEl = document.getElementById('status');
    const statusText = document.getElementById('status-text');

    statusEl.className = state;
    statusText.textContent = text;
}

/**
 * Update legend to match current color scale
 */
function updateLegend() {
    const legendContainer = document.querySelector('#legend');
    const legendItems = legendContainer.querySelectorAll('.legend-item');

    // Clear existing legend items (keep header)
    legendItems.forEach(item => item.remove());

    // Add new legend items based on current color scale
    colorScale.forEach((range) => {
        const item = document.createElement('div');
        item.className = 'legend-item';

        const colorBox = document.createElement('div');
        colorBox.className = 'legend-color';
        colorBox.style.background = `rgb(${range.color[0]}, ${range.color[1]}, ${range.color[2]})`;

        const label = document.createElement('span');
        if (range.max >= 999) {
            label.textContent = `${range.min}"+`;
        } else {
            label.textContent = `${range.min}" - ${range.max}"`;
        }

        item.appendChild(colorBox);
        item.appendChild(label);
        legendContainer.appendChild(item);
    });
}

/**
 * RGB to Hex converter
 */
function rgbToHex(r, g, b) {
    return "#" + [r, g, b].map(x => {
        const hex = x.toString(16);
        return hex.length === 1 ? "0" + hex : hex;
    }).join('');
}

/**
 * Hex to RGB converter
 */
function hexToRgb(hex) {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? [
        parseInt(result[1], 16),
        parseInt(result[2], 16),
        parseInt(result[3], 16)
    ] : null;
}

/**
 * Open color scale editor
 */
function openColorEditor() {
    const modal = document.getElementById('color-editor-modal');
    const container = document.getElementById('color-stops-container');

    container.innerHTML = '';

    colorScale.forEach((range, index) => {
        const rangeDiv = document.createElement('div');
        rangeDiv.className = 'color-stop';

        const maxValue = range.max >= 999 ? '' : range.max;
        const maxLabel = range.max >= 999 ? '+ (open-ended)' : `to`;

        rangeDiv.innerHTML = `
            <input type="number" class="range-min" value="${range.min}" min="0" step="0.5" data-index="${index}" style="width: 60px;">
            <span style="color: #a1a1aa; font-size: 12px;">${maxLabel}</span>
            <input type="number" class="range-max" value="${maxValue}" min="0" step="0.5" data-index="${index}" style="width: 60px;" ${range.max >= 999 ? 'disabled placeholder="∞"' : ''}>
            <span style="color: #a1a1aa; font-size: 12px;">inches</span>
            <input type="color" class="range-color" value="${rgbToHex(...range.color)}" data-index="${index}">
            <button onclick="removeColorStop(${index})"><i class="fas fa-trash"></i></button>
        `;
        container.appendChild(rangeDiv);
    });

    modal.classList.add('open');
}

/**
 * Close color scale editor
 */
function closeColorEditor() {
    document.getElementById('color-editor-modal').classList.remove('open');
}

/**
 * Add new color range
 */
window.addColorStop = function() {
    const lastRange = colorScale[colorScale.length - 1];
    const newMin = lastRange.max >= 999 ? lastRange.min + 2 : lastRange.max;

    // Remove the 999 from the previous last range
    if (lastRange.max >= 999) {
        lastRange.max = newMin;
    }

    colorScale.push({
        min: newMin,
        max: newMin + 2,
        color: [200, 200, 200]
    });
    openColorEditor();
};

/**
 * Remove color range
 */
window.removeColorStop = function(index) {
    if (colorScale.length > 2) {
        colorScale.splice(index, 1);

        // Make sure the last range is open-ended
        if (colorScale.length > 0) {
            colorScale[colorScale.length - 1].max = 999;
        }

        openColorEditor();
    } else {
        alert('You must have at least 2 color ranges');
    }
};

/**
 * Save color scale changes
 */
function saveColorScale() {
    const mins = document.querySelectorAll('.range-min');
    const maxes = document.querySelectorAll('.range-max');
    const colors = document.querySelectorAll('.range-color');

    const newScale = [];
    mins.forEach((input, index) => {
        const minVal = parseFloat(input.value);
        const maxVal = maxes[index].disabled ? 999 : parseFloat(maxes[index].value);

        newScale.push({
            min: minVal,
            max: maxVal,
            color: hexToRgb(colors[index].value)
        });
    });

    // Sort by min value
    newScale.sort((a, b) => a.min - b.min);

    // Validate ranges don't overlap
    for (let i = 0; i < newScale.length - 1; i++) {
        if (newScale[i].max > newScale[i + 1].min) {
            alert('Error: Overlapping ranges detected. Please fix the ranges.');
            return;
        }
    }

    // Make sure last range is open-ended
    newScale[newScale.length - 1].max = 999;

    colorScale = newScale;
    updateLegend();

    if (snowReports.length > 0) {
        generateSnowMap();
    }

    closeColorEditor();
}

/**
 * Set up control event listeners
 */
function initControls() {
    // Color preset selector
    document.getElementById('color-preset').addEventListener('change', (e) => {
        const preset = e.target.value;
        if (preset === 'custom') {
            openColorEditor();
        } else if (colorScalePresets[preset]) {
            colorScale = [...colorScalePresets[preset]];
            updateLegend();
            if (snowReports.length > 0) {
                generateSnowMap();
            }
        }
    });

    // Edit colors button
    document.getElementById('edit-colors-btn').addEventListener('click', openColorEditor);

    // Color editor modal buttons
    document.getElementById('add-stop-btn').addEventListener('click', window.addColorStop);
    document.getElementById('save-colors-btn').addEventListener('click', saveColorScale);
    document.getElementById('cancel-colors-btn').addEventListener('click', closeColorEditor);

    // Interpolation method selector
    document.getElementById('interpolation-method').addEventListener('change', (e) => {
        config.interpolationMethod = e.target.value;
        if (snowReports.length > 0) {
            generateSnowMap();
        }
    });

    // Cell size (resolution) slider
    const cellSizeSlider = document.getElementById('cell-size');
    const cellSizeValue = document.getElementById('cell-size-value');
    cellSizeSlider.addEventListener('input', (e) => {
        config.cellSize = parseFloat(e.target.value);
        cellSizeValue.textContent = `${config.cellSize.toFixed(3)}°`;
    });
    cellSizeSlider.addEventListener('change', () => {
        if (snowReports.length > 0) {
            generateSnowMap();
        }
    });

    // Opacity slider
    const opacitySlider = document.getElementById('opacity');
    const opacityValue = document.getElementById('opacity-value');
    opacitySlider.addEventListener('input', (e) => {
        config.opacity = parseFloat(e.target.value) / 100;
        opacityValue.textContent = `${e.target.value}%`;
        if (canvasOverlay) {
            canvasOverlay.setOpacity(config.opacity);
        }
    });

    // Refresh button
    document.getElementById('refresh-btn').addEventListener('click', () => {
        fetchSnowData();
    });

    // Toggle controls visibility
    document.getElementById('toggle-controls-btn').addEventListener('click', () => {
        const controls = document.getElementById('controls');
        const btn = document.getElementById('toggle-controls-btn');

        controls.classList.toggle('minimized');

        if (controls.classList.contains('minimized')) {
            btn.innerHTML = '<i class="fas fa-eye"></i> Show';
        } else {
            btn.innerHTML = '<i class="fas fa-eye-slash"></i> Hide';
        }
    });

    // Import custom reports button
    document.getElementById('import-custom-btn').addEventListener('click', () => {
        importCustomReports();
    });

    // Hours back input - refresh when Enter is pressed
    document.getElementById('hours-back').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            fetchSnowData();
        }
    });

    // Regenerate map when map is moved/zoomed
    snowMap.on('moveend', () => {
        if (snowReports.length > 0) {
            generateSnowMap();
        }
    });
}

/**
 * Import custom snow reports from text file
 */
function importCustomReports() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.txt,.text';
    input.style.display = 'none';

    input.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (event) => {
            try {
                const text = event.target.result;
                const customReports = parseCustomReports(text);

                if (customReports.length > 0) {
                    // Add to existing reports
                    snowReports = snowReports.concat(customReports);

                    // Clear existing markers and regenerate map
                    reportMarkers.clearLayers();
                    addReportMarkers();
                    generateSnowMap();

                    updateStatus('ready', `Imported ${customReports.length} custom reports`);
                    console.log(`Total reports: ${snowReports.length}`);
                } else {
                    updateStatus('error', 'No valid reports found in file');
                }
            } catch (error) {
                console.error('Error parsing custom reports:', error);
                updateStatus('error', 'Error parsing custom reports: ' + error.message);
            }
        };

        reader.readAsText(file);
    });

    document.body.appendChild(input);
    input.click();
    document.body.removeChild(input);
}

/**
 * Parse custom reports from text file
 */
function parseCustomReports(text) {
    const reports = [];
    const lines = text.split('\n');

    for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();

        // Skip empty lines, headers, and county/state labels
        if (!line ||
            line.startsWith('Location') ||
            line.startsWith('...') ||
            line.startsWith('Amount') ||
            line.length < 20) {
            continue;
        }

        // Parse line format: "Location   Amount   Time/Date   Lat/Lon"
        // Example: "2 SW Fort Wayne              10.0 in   0130 AM 11/30   41.05N/85.17W"

        // Use regex to extract components
        const match = line.match(/^(.+?)\s+([\d.]+)\s+in\s+(\d{4}\s+[AP]M\s+\d{1,2}\/\d{1,2})\s+([\d.]+)([NS])\/([\d.]+)([EW])/);

        if (match) {
            const location = match[1].trim();
            const amount = parseFloat(match[2]);
            const timeStr = match[3].trim();
            const lat = parseFloat(match[4]) * (match[5] === 'S' ? -1 : 1);
            const lon = parseFloat(match[6]) * (match[7] === 'W' ? -1 : 1);

            // Parse the date/time
            const year = new Date().getFullYear();

            // Extract time components
            const timeMatch = timeStr.match(/(\d{2})(\d{2})\s+([AP]M)\s+(\d{1,2})\/(\d{1,2})/);
            if (timeMatch) {
                let hours = parseInt(timeMatch[1]);
                const minutes = parseInt(timeMatch[2]);
                const ampm = timeMatch[3];
                const month = parseInt(timeMatch[4]);
                const day = parseInt(timeMatch[5]);

                // Convert to 24-hour format
                if (ampm === 'PM' && hours !== 12) hours += 12;
                if (ampm === 'AM' && hours === 12) hours = 0;

                const obsDate = new Date(year, month - 1, day, hours, minutes);

                // Create report in the format used by snowReports array
                reports.push({
                    lat: lat,
                    lon: lon,
                    magnitude: amount,
                    city: location,
                    county: '',
                    time: obsDate.toISOString(),
                    remark: '',
                    type: 'CUSTOM IMPORT - LSR SNOW'
                });
            }
        }
    }

    console.log(`Parsed ${reports.length} custom reports`);
    return reports;
}

/**
 * Initialize the application
 */
async function init() {
    console.log('Starting Snow Map application...');
    console.log('Document ready state:', document.readyState);

    try {
        initMap();
        initControls();

        // Load Ohio boundary first for clipping
        await fetchOhioBoundary();

        // Then fetch and display snow data
        fetchSnowData();
    } catch (error) {
        console.error('Error during initialization:', error);
        alert('Failed to initialize Snow Map: ' + error.message);
    }
}

// Start the application when DOM is ready
console.log('Snow map script loaded');
if (document.readyState === 'loading') {
    console.log('Waiting for DOMContentLoaded...');
    document.addEventListener('DOMContentLoaded', init);
} else {
    console.log('DOM already ready, initializing immediately...');
    init();
}
