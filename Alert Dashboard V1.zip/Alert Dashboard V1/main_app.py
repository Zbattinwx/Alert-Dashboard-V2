# main_app.py
# ==================================================================================
# NWS ALERT DASHBOARD - MAIN APPLICATION
# ==================================================================================
# This is the core backend server that:
# 1. Connects to NWS Weather Wire (NWWS-OI) via XMPP for real-time alerts
# 2. Fetches initial alert state from NWS API
# 3. Manages active alerts, tracks updates/cancellations
# 4. Broadcasts alert data to connected dashboard clients via WebSocket
# 5. Handles alert map rendering by fetching zone geometries
# 6. Provides test alert injection for development/testing
# ==================================================================================

import asyncio
import collections
import json
import logging
import re
import sys
from html import unescape
from xml.etree import ElementTree
import aiohttp
from ugc_parser import load_ugc_database
from datetime import datetime, timedelta, timezone
from ugc_parser import UGC_TO_COUNTY

import slixmpp
import websockets
import weatherwise_control
import aiofiles

import http.server
import socketserver
import ssl
import threading
import uuid

from google.oauth2 import service_account
from googleapiclient.discovery import build

from alert import Alert
from alert_parser import parse_alert, get_location_string
from constants import (
    NWS_EVENT_TO_PHENOMENON,
    TARGET_PHENOMENA,
    HIGH_PRIORITY_ALERTS,
    WFO_TIMEZONES,
    STATE_FIPS_MAP,
    TARGET_AFD_OFFICES,
    ALERT_PRIORITY
)
from patterns import PATTERN_AFD_ID, PATTERN_VTEC_TIMESTAMP, PATTERN_UGC_EXPIRATION
from zone_geometry_service import ZoneGeometryService
from alert_manager import AlertManager
from message_broker import MessageBroker
from daily_stats import get_daily_stats_tracker
import pytz
from earthquake_manager import get_earthquake_manager
from logger import get_logger, set_log_level

import os
import signal
import schedule
from dotenv import load_dotenv

# Determine where the executable is located
if getattr(sys, 'frozen', False):
    # If running as a compiled .exe, use the location of the .exe file
    application_path = os.path.dirname(sys.executable)
else:
    # If running as a script, use the location of the script
    application_path = os.path.dirname(os.path.abspath(__file__))

# Tell load_dotenv to look specifically in that folder
env_path = os.path.join(application_path, '.env')
load_dotenv(dotenv_path=env_path)

# Optional: Change working directory to the app folder
# This ensures config.json and active_alerts.json are read/written 
# in the same folder as the .exe, not in a random System32 folder.
os.chdir(application_path)

# Load environment variables from .env file
load_dotenv()

# Determine environment (production or development)
ENVIRONMENT = os.getenv('ENVIRONMENT', 'development')
IS_PRODUCTION = ENVIRONMENT == 'production'

GOOGLE_CHAT_SPACE_ID = "spaces/AAAAVWPv5-E" 

last_message_timestamp = None
user_cache = {} # ADD THIS LINE
latest_storm_threats = []
UGC_TO_FIPS_MAP = {}

try:
    from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
except ImportError:
    # For Python < 3.9, you would need to pip install tzdata
    from backports.zoneinfo import ZoneInfo, ZoneInfoNotFoundError


def to_json(self):
        return self.__dict__


from config_manager import ConfigManager

# Initialize configuration manager
config_manager = ConfigManager('config.json')
# Keep backward compatibility by providing dict-like access
config = config_manager.as_dict()


_ALERT_CACHE_FILE = "active_alerts.json"
_SERVER_START_TIME = datetime.now()
_RESTART_INTERVAL_HOURS = config.get("restart_interval_hours", 24)

# Load credentials from environment variables
NWWS_USERNAME = os.getenv('NWWS_USERNAME')
NWWS_PASSWORD = os.getenv('NWWS_PASSWORD')
DASHBOARD_PASSWORD = os.getenv('DASHBOARD_PASSWORD')
RECAPTCHA_SECRET_KEY = os.getenv('RECAPTCHA_SECRET_KEY')
GOOGLE_CHAT_WEBHOOK_URL = os.getenv('GOOGLE_CHAT_WEBHOOK_URL')
OBS_WEBSOCKET_PASSWORD = os.getenv('OBS_WEBSOCKET_PASSWORD')
OBS_WEBSOCKET_URL = os.getenv('OBS_WEBSOCKET_URL', 'ws://localhost:4455')

if config.get("alert_source") == "nwws" and (not NWWS_USERNAME or not NWWS_PASSWORD):
    sys.exit("FATAL: NWWS_USERNAME or NWWS_PASSWORD not found in environment variables (.env file)")

WEBSOCKET_HOST = "0.0.0.0"
WEBSOCKET_PORT = 8765

HTTP_PORT = 8080

# Initialize services
zone_geometry_service = ZoneGeometryService()
alert_manager = AlertManager(_ALERT_CACHE_FILE)
message_broker = MessageBroker()

# Backward compatibility references (these will be gradually removed)
active_alerts = alert_manager.active_alerts
recent_products = alert_manager.recent_products
latest_afds = alert_manager.latest_afds
manual_lsrs = alert_manager.manual_lsrs
connected_clients = message_broker.connected_clients

# Store reference to main event loop for HTTP thread
main_event_loop = None


# ==================================================================================
# TEST ALERT TIMESTAMP MANAGEMENT
# ==================================================================================
# Functions to update timestamps in test alerts to prevent them from being
# rejected as expired when injected during testing
# ==================================================================================


def update_test_alert_timestamps(alert_text: str, hours_from_now: int = 1) -> str:
    """
    Updates timestamps in test alert text to be current/future.
    This allows test alerts to pass the expiration check.

    Args:
        alert_text: Raw alert text with old timestamps
        hours_from_now: How many hours in the future to set expiration (default 1)

    Returns:
        Alert text with updated timestamps
    """
    now = datetime.now(timezone.utc)
    issue_time = now
    expire_time = now + timedelta(hours=hours_from_now)

    # Format for VTEC timestamps (YYMMDDTHHMM)
    vtec_issue = issue_time.strftime('%y%m%dT%H%MZ')
    vtec_expire = expire_time.strftime('%y%m%dT%H%MZ')

    # Update VTEC string issue time using compiled pattern
    alert_text = PATTERN_VTEC_TIMESTAMP.sub(rf'\g<1>{vtec_issue}-{vtec_expire}/', alert_text)

    # Update UGC line expiration (DDHHMM format)
    ugc_expire = expire_time.strftime('%d%H%M')
    alert_text = PATTERN_UGC_EXPIRATION.sub(rf'\g<1>{ugc_expire}\g<3>', alert_text)

    return alert_text


def update_test_alert_json_timestamps(alert_json: dict, hours_from_now: int = 1) -> dict:
    """
    Updates timestamps in API/JSON test alerts to be current/future.

    Args:
        alert_json: Alert JSON object
        hours_from_now: How many hours in the future to set expiration (default 1)

    Returns:
        Updated alert JSON object
    """
    import copy

    # Create a deep copy to avoid modifying the original
    alert = copy.deepcopy(alert_json)

    now = datetime.now(timezone.utc)
    issue_time = now
    expire_time = now + timedelta(hours=hours_from_now)

    # Format with timezone offset (e.g., "2025-10-20T14:35:00-04:00")
    # Use local timezone for realistic display
    local_now = datetime.now()
    tz_offset = local_now.astimezone().strftime('%z')
    tz_offset_formatted = f"{tz_offset[:3]}:{tz_offset[3:]}"

    issue_str = issue_time.strftime(f'%Y-%m-%dT%H:%M:%S{tz_offset_formatted}')
    expire_str = expire_time.strftime(f'%Y-%m-%dT%H:%M:%S{tz_offset_formatted}')

    # Update all time fields in properties
    if 'properties' in alert:
        props = alert['properties']
        props['sent'] = issue_str
        props['effective'] = issue_str
        props['onset'] = issue_str
        props['expires'] = expire_str
        props['ends'] = expire_str

        # Update VTEC in parameters if present
        if 'parameters' in props and 'VTEC' in props['parameters']:
            vtec_old = props['parameters']['VTEC'][0]
            vtec_issue = issue_time.strftime('%y%m%dT%H%MZ')
            vtec_expire = expire_time.strftime('%y%m%dT%H%MZ')

            # Replace timestamps in VTEC string
            vtec_new = re.sub(r'\d{6}T\d{4}Z', vtec_issue, vtec_old, count=1)
            vtec_new = re.sub(r'-\d{6}T\d{4}Z/', f'-{vtec_expire}/', vtec_new)
            props['parameters']['VTEC'][0] = vtec_new

    return alert


USER_TO_IMPERSONATE = 'zach@belparkweather.org'


def load_ugc_to_fips_map():
    """Loads the UGC-to-FIPS JSON map into memory."""
    global UGC_TO_FIPS_MAP
    try:
        with open('ugc_to_fips.json', 'r') as f:
            UGC_TO_FIPS_MAP = json.load(f)
        print(f"✅ Successfully loaded {len(UGC_TO_FIPS_MAP)} UGC-to-FIPS mappings.")
    except FileNotFoundError:
        print("❌ CRITICAL: ugc_to_fips.json not found. Run build_ugc_map.py to create it.")
    except Exception as e:
        print(f"❌ Error loading ugc_to_fips.json: {e}")


async def poll_storm_threat_data():
    """Periodically checks for and loads storm threat data from the processor."""
    global latest_storm_threats
    print("🌪️ Storm Threat polling service started.")
    while True:
        if not config.get("enable_storm_threat", False):
            print("Storm threat system is disabled in config.json. Waiting...")
            await asyncio.sleep(120)
            continue # This will skip the rest of the loop and start the next iteration
        
        try:
            # Use aiofiles for non-blocking file I/O
            async with aiofiles.open('storm_data.json', mode='r') as f:
                contents = await f.read()
                latest_storm_threats = json.loads(contents)
                print(f"✅ Loaded {len(latest_storm_threats)} storm threat objects.")
                # After loading new data, trigger a broadcast to all clients
                await broadcast_updates()
        except FileNotFoundError:
            # This is normal if the processor hasn't run yet
            latest_storm_threats = []
        except json.JSONDecodeError:
            print("⚠️ Error decoding storm_data.json. File might be partially written.")
        except Exception as e:
            print(f"❌ Error in storm threat poller: {e}")
        
        # Wait 2 minutes before checking again
        await asyncio.sleep(30)


async def poll_earthquake_data():
    """Periodically fetches earthquake data from USGS API."""
    earthquake_manager = get_earthquake_manager()
    print("🌍 Earthquake polling service started.")

    while True:
        try:
            earthquakes = await earthquake_manager.fetch_earthquakes()

            if earthquakes is not None:
                new_count = 0
                for eq in earthquakes:
                    is_new = earthquake_manager.add_or_update_earthquake(eq)
                    if is_new:
                        new_count += 1
                        print(f"🆕 New earthquake detected: M{eq.magnitude} - {eq.place}")

                # Remove earthquakes older than 24 hours
                earthquake_manager.remove_old_earthquakes(max_age_hours=24)

                # Broadcast updates to all clients
                await broadcast_updates()

                if new_count > 0:
                    print(f"✅ Processed {len(earthquakes)} earthquakes ({new_count} new)")

        except Exception as e:
            print(f"❌ Error in earthquake poller: {e}")
            import traceback
            traceback.print_exc()

        # Wait before next poll (default 2 minutes)
        await asyncio.sleep(earthquake_manager.poll_interval)


async def save_alerts_to_disk():
    """Saves the current state of active_alerts, recent_products, and daily stats to disk."""
    print(f"💾 Saving {len(active_alerts)} alerts and {len(recent_products)} products to disk.")
    try:
        data_to_save = {
            "active_alerts": {
                alert_id: alert.to_json() for alert_id, alert in active_alerts.items()
            },
            "recent_products": list(recent_products),
            "latest_afds": latest_afds
        }
        # Use async file I/O to avoid blocking the event loop
        async with aiofiles.open(_ALERT_CACHE_FILE, 'w') as f:
            await f.write(json.dumps(data_to_save, indent=2))

        # Also save daily stats state
        stats_tracker = get_daily_stats_tracker()
        stats_tracker.save_state()
    except Exception as e:
        print(f"❌ Error saving alerts to disk: {e}")

def load_alerts_from_disk():
    """Loads the state of active_alerts and recent_products from a JSON file."""
    global active_alerts, recent_products, latest_afds
    if not os.path.exists(_ALERT_CACHE_FILE):
        print("🗄️ No existing alert cache file found.")
        return

    try:
        with open(_ALERT_CACHE_FILE, 'r') as f:
            data = json.load(f)

        # Restore active_alerts
        active_alerts.clear()
        for alert_id, alert_data in data.get("active_alerts", {}).items():
            # ✅ FIX: Check for and pass 'raw_text' to the constructor
            raw_text_from_cache = alert_data.get("raw_text")
            if not raw_text_from_cache:
                print(f"⚠️ Skipping alert {alert_id} from cache, missing raw_text.")
                continue

            # Instantiate the Alert with the required text, then update it
            alert = Alert(raw_text_from_cache)
            alert.__dict__.update(alert_data)

            # Ensure datetime objects are properly restored
            if isinstance(alert.issue_time, str):
                alert.issue_time = datetime.fromisoformat(alert.issue_time)
            if isinstance(alert.expiration_time, str):
                alert.expiration_time = datetime.fromisoformat(alert.expiration_time)
            active_alerts[alert_id] = alert

        # Restore recent_products
        recent_products.clear()
        for product in data.get("recent_products", []):
            recent_products.append(product)

        # Restore AFD data
        latest_afds.update(data.get("latest_afds", {}))

        print(f"✅ Loaded {len(active_alerts)} alerts and {len(recent_products)} products from disk.")
    except Exception as e:
        print(f"❌ Error loading alerts from disk: {e}")
        # Clean up corrupted file
        if os.path.exists(_ALERT_CACHE_FILE):
            os.remove(_ALERT_CACHE_FILE)
            print("⚠️ Removed corrupted alert cache file.")

async def initial_api_state_load():
    """
    Performs a one-time poll of the NWS API on startup, parsing the
    JSON responses directly into Alert objects.
    """
    print("🛰️ Performing one-time startup poll of NWS API to get current state...")
    
    states_to_query = config.get("filters", {}).get("states", [])
    api_url = "https://api.weather.gov/alerts/active?status=actual"

    if states_to_query:
        api_url = f"https://api.weather.gov/alerts/active?status=actual&area={','.join(states_to_query)}"
        print(f"   -> Querying API for configured states: {states_to_query}")
    else:
        print("   -> No state filters found. Querying API for all active alerts nationwide.")

    async with aiohttp.ClientSession(headers={"User-Agent": "WeatherWiseDashboard/1.0"}) as session:
        try:
            async with session.get(api_url) as response:
                if response.status != 200:
                    print(f"❌ Initial API poll failed: {response.status}")
                    return

                data = await response.json()
                alert_features = data.get("features", [])
                print(f"   -> API response contains {len(alert_features)} alert features.")

                tasks = [fetch_and_process_api_alert(session, feature.get("properties", {}).get('@id')) for feature in alert_features if feature.get("properties", {}).get('@id')]
                
                parsed_alerts = await asyncio.gather(*tasks)

                alerts_added = 0
                stats_tracker = get_daily_stats_tracker()
                filters = config.get("filters", {})
                for alert in parsed_alerts:
                    if alert and alert.phenomenon in TARGET_PHENOMENA:
                        # Apply the same filtering logic as handle_incoming_alert
                        if not filter_nwws_alert(alert, filters):
                            continue

                        # Filter UGC codes to only show counties from configured states
                        filter_alert_ugc_codes(alert, filters)

                        # Populate FIPS codes from filtered UGC codes
                        if alert.affected_areas:
                            populate_fips_codes_from_ugc(alert)

                        if alert.product_id not in active_alerts:
                             active_alerts[alert.product_id] = alert
                             alerts_added += 1
                             # Track alert for daily statistics
                             try:
                                 stats_tracker.record_alert(alert)
                             except Exception as e:
                                 print(f"⚠️ Error tracking initial alert for daily stats: {e}")

                print(f"✅ Initial state load complete. Added {alerts_added} new alerts to the system.")

                # Broadcast the loaded alerts to any connected clients
                if alerts_added > 0:
                    await broadcast_updates()

        except Exception as e:
            print(f"❌ An error occurred during initial API state load: {e}")

async def poll_google_chat_messages():
    """Periodically polls Google Chat for new messages."""
    global last_message_timestamp, user_cache
    
    print("💬 Google Chat polling service started.")
    
    try:
        # --- 📍 CHANGE #1: ADD NEW SCOPE ---
        # We now need scopes for BOTH the Chat API and the People API.
        creds = service_account.Credentials.from_service_account_file(
            'service-account.json',
            scopes=[
                'https://www.googleapis.com/auth/chat.messages.readonly',
                'https://www.googleapis.com/auth/directory.readonly' # <-- New scope for People API
            ],
            subject=USER_TO_IMPERSONATE
        )
        # --- 📍 CHANGE #2: BUILD TWO SEPARATE SERVICES ---
        chat_service = build('chat', 'v1', credentials=creds)
        people_service = build('people', 'v1', credentials=creds) # <-- New service for People API
        
    except Exception as e:
        print(f"❌ FATAL: Could not build Google services. Check service-account.json and permissions. Error: {e}")
        return

    while True:
        try:
            results = chat_service.spaces().messages().list(
                parent=GOOGLE_CHAT_SPACE_ID,
                pageSize=25,
                orderBy="createTime DESC"
            ).execute()

            messages = results.get('messages', [])
            messages.reverse()

            messages_to_send = []
            if not messages:
                pass
            elif last_message_timestamp is None:
                messages_to_send = messages
            else:
                for msg in messages:
                    if msg['createTime'] > last_message_timestamp:
                        messages_to_send.append(msg)

            if messages_to_send:
                print(f"  ✅ Found {len(messages_to_send)} new messages. Looking up authors...")
                for msg in messages_to_send:
                    if msg.get('sender', {}).get('type') != 'HUMAN':
                        continue
                    
                    author_name = "Unknown Sender"
                    user_id_from_chat = msg.get('sender', {}).get('name') # This will be 'users/12345...'

                    if user_id_from_chat in user_cache:
                         author_name = user_cache[user_id_from_chat]
                    elif user_id_from_chat:
                        try:
                            # --- 📍 CHANGE #3: USE THE PEOPLE API FOR LOOKUP ---
                            # The People API needs the numeric ID, not the "users/" prefix.
                            person_id = user_id_from_chat.replace("users/", "")
                            
                            print(f"    -> Preparing to look up user via People API: {person_id}")

                            # Call the People API to get the user's name
                            user_info = people_service.people().get(
                                resourceName=f"people/{person_id}",
                                personFields='names' # We only need the name fields
                            ).execute()
                            
                            # Extract the display name from the People API response
                            display_name = "Unknown Sender"
                            names = user_info.get('names', [])
                            if names:
                                display_name = names[0].get('displayName', 'Unknown Sender')
                            
                            print(f"    -> Successfully fetched info for {display_name}")
                            author_name = display_name
                            user_cache[user_id_from_chat] = author_name
                            
                        except Exception as e:
                            print(f"!!! An unexpected error occurred during user lookup for {user_id_from_chat}: {e}")
                            author_name = "Error: See Console"

                    message_payload = {
                        "type": "chat_message",
                        "author": author_name,
                        "text": msg.get('text', '[Attachment or non-text message]')
                    }
                    await broadcast_message(json.dumps(message_payload))
                
                last_message_timestamp = messages_to_send[-1]['createTime']
                
        except Exception as e:
            print(f"❌ Error during polling loop: {e}")
        
        await asyncio.sleep(10)


class NWWSBot(slixmpp.ClientXMPP):
    """The main bot class to connect to the NWWS-OI service."""
    def __init__(self, jid, password):
        super().__init__(jid, password, sasl_mech='PLAIN')
        self.add_event_handler("session_start", self.on_session_start)
        self.add_event_handler("groupchat_message", self.on_muc_message)
        self.add_event_handler("disconnected", self.on_disconnected)
        
        # This will hold our reconnection task to ensure we don't run duplicates
        self.reconnect_task = None

    async def on_session_start(self, event):
        # When a session starts, it means we are connected.
        # We must cancel any pending reconnection task.
        if self.reconnect_task and not self.reconnect_task.done():
            self.reconnect_task.cancel()
            print("✅ Reconnection successful. Reconnect task cancelled.")
        self.reconnect_task = None

        print("🚀 Session started. Joining alert channel...")
        await self.get_roster()
        self.send_presence()
        await self.plugin['xep_0045'].join_muc('nwws@conference.nwws-oi.weather.gov', 'WeatherWiseBot')

    def on_muc_message(self, msg):
        if msg['type'] != 'groupchat' or msg['mucnick'] == 'WeatherWiseBot':
            return

        alert_body = msg.xml.find('{nwws-oi}x')
        if alert_body is not None and alert_body.text:
            raw_text = unescape(alert_body.text).strip()

            match = PATTERN_AFD_ID.search(raw_text)
            if match:
                product_id = match.group(1).upper()
                office = product_id[3:]
                if office in TARGET_AFD_OFFICES:
                    print(f"✅ Captured AFD for {office}.")
                    latest_afds[office] = raw_text
                    # Save AFDs to disk immediately to prevent loss on restart
                    alert_manager.save_to_disk()
                    # Broadcast the update and stop further processing for this product
                    asyncio.create_task(broadcast_updates())
                    return

            recent_products.appendleft({'text': raw_text, 'id': raw_text})
            asyncio.create_task(broadcast_updates())
            asyncio.create_task(handle_incoming_alert(raw_text))
            return

        if msg['body']:
            print(f"Received summary line (no full text found): {msg['body']}")

    def on_disconnected(self, event):
        """Handles disconnection and schedules a persistent reconnection task."""
        print("🔌 INFO: Disconnected from the NWWS-OI server.")
        
        # Start the reconnect task only if it's not already running.
        if self.reconnect_task is None or self.reconnect_task.done():
            print("   -> Scheduling persistent reconnection task.")
            self.reconnect_task = asyncio.create_task(self.attempt_reconnect())
        else:
            print("   -> Reconnection task is already active.")

    async def attempt_reconnect(self):
        """Continuously attempts to reconnect with an incremental backoff."""
        wait_time = 5  # Initial wait time in seconds
        while True:
            try:
                print(f"   -> Attempting to reconnect in {wait_time} seconds...")
                await asyncio.sleep(wait_time)
                # The connect() coroutine will re-run the entire connection flow
                await self.connect()
                # If connect() succeeds, the session_start event will fire
                # and cancel this task. We break the loop here.
                break 
            except Exception as e:
                print(f"   -> Reconnect attempt failed: {e}")
                # Increase wait time for the next attempt (exponential backoff)
                # but cap it at 5 minutes (300 seconds)
                wait_time = min(wait_time * 2, 300) 

def filter_api_alert(alert_properties, filters):
    if not filters:
        return True
    states = filters.get("states", [])
    if states and not any(state in alert_properties.get("areaDesc", "") for state in states):
        return False
    offices = filters.get("offices", [])
    if offices and alert_properties.get("senderName") in offices:
        return True
    ugc_codes = filters.get("ugc_codes", [])
    if ugc_codes:
        alert_ugc = alert_properties.get("geocode", {}).get("UGC", [])
        if any(code in ugc_codes for code in alert_ugc):
            return True
    if offices or ugc_codes:
        return False
    return True

async def poll_nws_api():
    """
    Periodically polls the NWS API for active alerts and sends them
    through the same handling pipeline as NWWS alerts.
    """
    states_to_query = config.get("filters", {}).get("states", [])
    if not states_to_query:
        print("⚠️ No states listed in config.json filters. API polling will not run.")
        return

    # Use a set to keep track of alert IDs we've already processed
    processed_ids = set()

    api_url = f"https://api.weather.gov/alerts/active?status=actual&area={','.join(states_to_query)}"
    print(f"📡 Polling NWS API for states: {states_to_query}")

    async with aiohttp.ClientSession(headers={"User-Agent": "WeatherDashboard/1.0"}) as session:
        while True:
            try:
                async with session.get(api_url) as response:
                    if response.status != 200:
                        print(f"❌ Error fetching from NWS API: {response.status}")
                        await asyncio.sleep(60)
                        continue

                    data = await response.json()
                    alert_features = data.get("features", [])
                    print(f"API poll found {len(alert_features)} active features.")

                    # Get the full text for each new alert
                    for feature in alert_features:
                        alert_id = feature.get("properties", {}).get("id")
                        if alert_id and alert_id not in processed_ids:
                            # The '@id' field contains the URL to the full alert text
                            full_text_url = feature.get('@id')
                            if full_text_url:
                                async with session.get(full_text_url) as text_response:
                                    if text_response.status == 200:
                                        # The response is a JSON object containing the raw text
                                        alert_data = await text_response.json()
                                        raw_text = alert_data.get("properties", {}).get("productText")
                                        if raw_text:
                                            # Send the full text to our universal handler
                                            await handle_incoming_alert(raw_text)
                                            processed_ids.add(alert_id)
                                    else:
                                        print(f"❌ Failed to fetch full text for {alert_id}")
            except Exception as e:
                print(f"An error occurred during API polling: {e}")

            # Wait for the next poll
            await asyncio.sleep(60)
            
def filter_nwws_alert(parsed_alert, filters):
    """
    Checks if an alert from NWWS should be kept based on the provided filters.
    The logic is an OR: if any filter is defined, the alert must match at least one.
    """
    # If no filters are defined, or all filter lists within are empty, pass everything.
    if not filters or all(not v for v in filters.values()):
        return True

    # If any filter type is defined, the alert must match at least one of the criteria below.
    # We start by assuming it doesn't match.
    matches_criteria = False
    
    # --- Check State Filter ---
    states = filters.get("states", [])
    if states:
        # Get the 2-letter state codes from the alert's UGCs (e.g., 'OH' from 'OHC123')
        alert_states = {ugc[:2] for ugc in parsed_alert.affected_areas}
        if any(state in alert_states for state in states):
            matches_criteria = True
            
    # --- Check Office Filter ---
    offices = filters.get("offices", [])
    if not matches_criteria and offices:
        if parsed_alert.issuing_office in offices:
            matches_criteria = True

    # --- Check UGC Filter ---
    ugc_codes = filters.get("ugc_codes", [])
    if not matches_criteria and ugc_codes:
        if any(code in ugc_codes for code in parsed_alert.affected_areas):
            matches_criteria = True
            
    # The function returns True only if one of the checks flipped the flag.
    return matches_criteria

def filter_alert_ugc_codes(parsed_alert, filters):
    """
    Filters the UGC codes (affected_areas) in an alert to only include those
    matching the configured state filter. This ensures alerts only show counties
    from the filtered states, not from all states in a multi-state alert.

    Args:
        parsed_alert: The Alert object to filter
        filters: The filter configuration from config.json
    """
    if not filters:
        return

    states = filters.get("states", [])
    if not states or not parsed_alert.affected_areas:
        return

    # Filter affected_areas to only include UGC codes matching the state filter
    # UGC codes start with 2-letter state abbreviation (e.g., OHZ001, OHC049)
    original_count = len(parsed_alert.affected_areas)
    filtered_ugc_codes = [
        ugc for ugc in parsed_alert.affected_areas
        if ugc[:2] in states
    ]

    # Update the alert's affected areas
    parsed_alert.affected_areas = filtered_ugc_codes

    # Regenerate display_locations based on filtered UGC codes
    if filtered_ugc_codes:
        from alert_parser import get_location_string
        parsed_alert.display_locations = get_location_string(filtered_ugc_codes)

        removed_count = original_count - len(filtered_ugc_codes)
        if removed_count > 0:
            print(f"   Filtered out {removed_count} non-matching UGC codes from alert (kept {len(filtered_ugc_codes)} matching {states})")


# Zone geometry fetching is now handled by ZoneGeometryService
# See zone_geometry_service.py for implementation


def populate_fips_codes_from_ugc(alert: Alert):
    """
    Uses the pre-built UGC_TO_FIPS_MAP to find all FIPS codes associated
    with an alert's UGCs (both county and zone types).
    This is critical for zone-based alerts that need FIPS codes for mapping.
    """
    if not alert.affected_areas:
        return

    all_fips = set(alert.fips_codes) if alert.fips_codes else set()

    for ugc in alert.affected_areas:
        # Look up the UGC code in our new map. The map returns a LIST of FIPS codes.
        found_fips_list = UGC_TO_FIPS_MAP.get(ugc)

        if found_fips_list:
            # Add all found FIPS codes to our set
            for fips in found_fips_list:
                all_fips.add(fips.zfill(5))

    alert.fips_codes = sorted(list(all_fips))

async def send_alert_to_google_chat(alert: Alert):
    """Formats and sends a new alert notification to a Google Chat webhook."""

    if not config.get("send_google_chat_alerts", False):
        return

    webhook_url = GOOGLE_CHAT_WEBHOOK_URL
    if not webhook_url:
        return # Do nothing if the URL isn't configured

    # Load alert names from configuration
    from alert_config_loader import get_alert_config
    alert_config = get_alert_config()
    alert_name = alert_config.ALERT_DISPLAY_MAP.get(alert.phenomenon, "Weather Alert")
    
    # Add a prefix for high-impact events
    if alert.is_emergency:
        alert_name = f"🚨 **TORNADO EMERGENCY** 🚨"
    elif alert.damage_threat in ["DESTRUCTIVE", "CATASTROPHIC"]:
        alert_name = f"**{alert.damage_threat.upper()}** {alert_name}"
    elif alert.tornado_observed:
        alert_name = f"**OBSERVED** {alert_name}"
        
    expires_text = "N/A"
    if alert.expiration_time:
        try:
            # Look up the IANA timezone name from the WFO ID, default to New York (Eastern)
            iana_tz_name = WFO_TIMEZONES.get(alert.issuing_office, "America/New_York")
            target_tz = ZoneInfo(iana_tz_name)
            
            # Convert the UTC time to the target timezone
            local_time = alert.expiration_time.astimezone(target_tz)
            
            # Format the string with the correct local time and timezone abbreviation
            expires_text = local_time.strftime('%I:%M %p %Z')

        except ZoneInfoNotFoundError:
            # Fallback for rare cases where a timezone isn't found
            expires_text = alert.expiration_time.strftime('%I:%M %p UTC')
        except Exception as e:
            print(f"Error converting timezone for alert {alert.product_id}: {e}")
            expires_text = "Error"

    # Prepare the message payload for Google Chat
    message = {
        "cardsV2": [{
            "cardId": "weatherAlertCard",
            "card": {
                "header": {
                    "title": f"New {alert_name}",
                    "subtitle": f"For: {alert.display_locations}"
                },
                "sections": [{
                    "widgets": [

                        { "textParagraph": { "text": f"<b>Expires:</b> {expires_text}" } },
                        { "textParagraph": { "text": f"<b>Threats:</b> Wind: {alert.max_wind_gust or 'N/A'}, Hail: {alert.max_hail_size or 'N/A'}, Snow: {alert.snow_amount or 'N/A'}" } }
                    ]
                }]
            }
        }]
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(webhook_url, json=message) as response:
                if response.status == 200:
                    print(f"✅ Successfully sent alert {alert.product_id} to Google Chat.")
                else:
                    print(f"❌ Failed to send alert to Google Chat. Status: {response.status}, Response: {await response.text()}")
    except Exception as e:
        print(f"❌ An error occurred while sending alert to Google Chat: {e}")
        
        
def create_statewide_summary(alerts):
    """
    Processes all active alerts and returns a dictionary mapping
    each FIPS code to its highest-priority alert phenomenon.
    Includes all phenomenon types in TARGET_PHENOMENA.
    """
    county_threats = {}

    for alert in alerts:
        alert_phenomenon = alert.get("phenomenon")
        alert_priority = ALERT_PRIORITY.get(alert_phenomenon, 99)

        fips_codes = alert.get("fips_codes", [])

        # CRITICAL FIX: If alert has no fips_codes, skip it entirely
        # This prevents zone-based alerts without FIPS from being invisible
        if not fips_codes:
            print(f"⚠️ Alert {alert.get('product_id')} has no FIPS codes, cannot add to statewide summary")
            continue

        for fips in fips_codes:
            if fips not in county_threats or alert_priority < ALERT_PRIORITY.get(county_threats[fips], 99):
                county_threats[fips] = alert_phenomenon

    return county_threats

async def fetch_and_process_api_alert(session, url):
    """
    Fetches the full JSON for a single alert from the API, passes the entire
    feature to the parser, and returns a complete Alert object.
    Includes zone geometry fetching for zone-based alerts without polygons.
    """
    try:
        async with session.get(url) as response:
            if response.status == 200:
                # The entire response is the feature JSON we need to parse
                feature_json = await response.json()
                if feature_json:
                    # MODIFICATION: Call the universal parse_alert function
                    alert = parse_alert(feature_json)

                    # If this alert has zone codes but no polygon, fetch zone geometries
                    if alert:
                        await zone_geometry_service.populate_alert_with_zone_geometry(alert, session)

                    return alert
    except Exception as e:
        print(f"Failed to fetch or parse alert from {url}: {e}")
    return None


# ==================================================================================
# ALERT PROCESSING AND MANAGEMENT
# ==================================================================================
# Core function that handles incoming alerts from NWWS, performs intelligent
# merging of updates, handles cancellations, fetches zone geometries, and
# broadcasts changes to connected clients.
# ==================================================================================

async def handle_incoming_alert(raw_text: str, is_test: bool = False):
    """
    Parses, manages, and broadcasts alerts. Now intelligently merges updates
    and ignores already-expired incoming products.

    Args:
        raw_text: The raw alert text to parse
        is_test: If True, marks this alert as a test alert that can be cleared
    """
    parsed_alert = parse_alert(raw_text)

    # If parsing returns None (e.g., filtered out non-thunderstorm SPS), skip processing
    if parsed_alert is None:
        return

    # Mark as test alert if specified
    if is_test:
        parsed_alert.is_test = True

    try:
        if '$$' in parsed_alert.raw_text and parsed_alert.product_id:
            main_block = parsed_alert.raw_text.split('$$')[0]
            text_parts = main_block.split(parsed_alert.product_id)
            if len(text_parts) > 1:
                parsed_alert.text = text_parts[1].strip()
    except Exception as e:
        print(f"Could not automatically extract plain text for {parsed_alert.product_id}: {e}")
        if not hasattr(parsed_alert, 'text'):
            parsed_alert.text = parsed_alert.raw_text

    if parsed_alert.expiration_time and parsed_alert.expiration_time < datetime.now(timezone.utc):
        print(f"Ignoring stale, already-expired product: {parsed_alert.product_id or 'Unknown ID'}")
        return

    if not parsed_alert.product_id or parsed_alert.phenomenon not in TARGET_PHENOMENA:
        return

    # DEBUG: Log all SV warnings with their status flags for troubleshooting stats tracking
    if parsed_alert.phenomenon == "SV":
        print(f"[DEBUG-SV] {parsed_alert.product_id}: is_update={parsed_alert.is_update}, is_cancellation={parsed_alert.is_cancellation}")

    filters = config.get("filters", {})
    if not filter_nwws_alert(parsed_alert, filters):
        return

    # Filter UGC codes to only show counties from configured states
    # This removes non-matching counties from multi-state alerts
    filter_alert_ugc_codes(parsed_alert, filters)

    # CRITICAL FIX: Always populate FIPS codes from UGC codes for zone-based alerts
    # This ensures zone-based alerts (Winter Weather Advisories, Special Weather Statements, etc.)
    # have the necessary FIPS codes for map rendering
    if parsed_alert.affected_areas:
        populate_fips_codes_from_ugc(parsed_alert)

    # NEW: If alert has zone codes but no polygon, fetch zone geometries from NWS API
    async with aiohttp.ClientSession() as session:
        await zone_geometry_service.populate_alert_with_zone_geometry(parsed_alert, session)

    alert_id_to_manage = parsed_alert.product_id
    broadcast_needed = False

    if parsed_alert.is_cancellation:
        if alert_id_to_manage in active_alerts:
            print(f"❌ CANCELLATION: Removing {alert_id_to_manage}.")
            del active_alerts[alert_id_to_manage]
            broadcast_needed = True
    
    elif alert_id_to_manage in active_alerts:
        print(f"🔄 Merging update for alert: {alert_id_to_manage}")
        existing_alert = active_alerts[alert_id_to_manage]

        # --- START OF FIX ---
        # Overwrite text and times unconditionally with the latest data
        existing_alert.raw_text = parsed_alert.raw_text
        existing_alert.expiration_time = parsed_alert.expiration_time

        # Preserve test flag (once a test, always a test)
        if parsed_alert.is_test:
            existing_alert.is_test = True

        # If the new alert has a polygon, use it.
        if parsed_alert.polygon:
            existing_alert.polygon = parsed_alert.polygon

        # Combine UGC and FIPS codes, ensuring no duplicates
        existing_alert.affected_areas = sorted(list(set(existing_alert.affected_areas + parsed_alert.affected_areas)))
        existing_alert.fips_codes = sorted(list(set(existing_alert.fips_codes + parsed_alert.fips_codes)))

        # Re-generate the display location string with the updated county list
        if existing_alert.affected_areas:
             existing_alert.display_locations = get_location_string(existing_alert.affected_areas)

        # Update storm motion if present in the new data
        if parsed_alert.storm_motion:
            existing_alert.storm_motion = parsed_alert.storm_motion

        # Update snow amount from the latest alert data
        # This ensures we show the correct snow totals for the filtered counties
        if parsed_alert.snow_amount:
            existing_alert.snow_amount = parsed_alert.snow_amount

        # --- MERGE THREATS ---
        # Use the highest threat level found in any version of the alert
        existing_alert.is_emergency = existing_alert.is_emergency or parsed_alert.is_emergency
        existing_alert.tornado_observed = existing_alert.tornado_observed or parsed_alert.tornado_observed
        existing_alert.tornado_possible = existing_alert.tornado_possible or parsed_alert.tornado_possible

        # Compare and set the highest damage threat level
        threat_levels = {'NONE': 0, 'BASE': 1, 'CONSIDERABLE': 2, 'DESTRUCTIVE': 3, 'CATASTROPHIC': 4}
        existing_threat_val = threat_levels.get(existing_alert.damage_threat, 0)
        new_threat_val = threat_levels.get(parsed_alert.damage_threat, 0)
        if new_threat_val > existing_threat_val:
            existing_alert.damage_threat = parsed_alert.damage_threat
        # --- END OF FIX ---

        # Track alert for daily statistics (even if it's an update, in case we missed the original)
        try:
            stats_tracker = get_daily_stats_tracker()
            stats_tracker.record_alert(existing_alert)
        except Exception as e:
            print(f"⚠️ Error tracking alert update for daily stats: {e}")

        broadcast_needed = True

    else:
        if parsed_alert.phenomenon in HIGH_PRIORITY_ALERTS:
            # Only send chime and Google Chat for NEW alerts, not updates/continuations
            if not parsed_alert.is_update:
                print(f"🔔 New high-priority alert: {alert_id_to_manage}. Triggering chime.")
                chime_message = json.dumps({
                    "type": "new_alert",
                    "alert_data": parsed_alert.to_json()
                })
                asyncio.create_task(broadcast_message(chime_message))
                asyncio.create_task(send_alert_to_google_chat(parsed_alert))
            else:
                print(f"⏭️  Skipping chime/Google Chat for alert update (CON): {alert_id_to_manage}")

        print(f"➕ New alert added: {alert_id_to_manage}")
        active_alerts[alert_id_to_manage] = parsed_alert

        # Track alert for daily statistics
        try:
            stats_tracker = get_daily_stats_tracker()
            stats_tracker.record_alert(parsed_alert)
        except Exception as e:
            print(f"⚠️ Error tracking alert for daily stats: {e}")

        broadcast_needed = True

    if await clear_expired_alerts():
        broadcast_needed = True

    if broadcast_needed:
        await broadcast_updates()


async def clear_expired_alerts():
    """
    Performs a single pass to remove expired alerts from the global list.
    Returns True if alerts were removed, False otherwise.
    """
    now_utc = datetime.now(timezone.utc)
    initial_count = len(active_alerts)
    
    unexpired_alerts = {
        alert_id: alert for alert_id, alert in active_alerts.items()
        if not (alert.expiration_time and alert.expiration_time < now_utc)
    }
    
    if len(unexpired_alerts) < initial_count:
        print(f"🧹 Cleared {initial_count - len(unexpired_alerts)} expired alert(s).")
        active_alerts.clear()
        active_alerts.update(unexpired_alerts)
        return True
    return False

async def background_cleanup_task():
    """The background task that periodically clears expired alerts."""
    while True:
        await asyncio.sleep(60)
        # If the cleanup removed any alerts, broadcast the changes to all clients.
        if await clear_expired_alerts():
            await broadcast_updates()


async def periodic_state_save_task():
    """Periodically saves alerts and daily stats state to disk (every 5 minutes)."""
    while True:
        await asyncio.sleep(300)  # Save every 5 minutes
        await save_alerts_to_disk()


async def broadcast_updates():
    """Broadcasts complete state update to all connected clients."""
    earthquake_manager = get_earthquake_manager()
    earthquake_data = earthquake_manager.to_json()

    # Create config copy with environment credentials injected for broadcast
    broadcast_config = dict(config)
    broadcast_config['dashboard_password'] = DASHBOARD_PASSWORD
    broadcast_config['obs_websocket_password'] = OBS_WEBSOCKET_PASSWORD
    broadcast_config['obs_websocket_url'] = OBS_WEBSOCKET_URL

    await message_broker.broadcast_update(
        alert_manager,
        broadcast_config,
        latest_storm_threats,
        create_statewide_summary,
        earthquake_data
    )

async def broadcast_message(message: str):
    """Broadcasts a raw message string to all connected clients."""
    await message_broker.broadcast_message(message)

async def client_handler(websocket):
    message_broker.add_client(websocket)
    try:
        # First, clean up any expired alerts before sending the initial state.
        await clear_expired_alerts()
        # Then, send the clean list to the new client.
        await broadcast_updates()

        async for message in websocket:
            try:
                data = json.loads(message)
                if data.get('type') == 'feature_alert':
                    print(f"Featuring alert: {data.get('alert_data', {}).get('product_id')}")
                    # Re-broadcast this message to all clients (including the new widget)
                    await broadcast_message(message)
                    
                elif data.get('type') == 'manual_lsr':
                    report_payload = data.get('payload', {})
                    if 'lat' in report_payload and 'lng' in report_payload:
                        # Add server-side info to the report
                        report_payload['id'] = str(uuid.uuid4())
                        report_payload['timestamp'] = datetime.now(timezone.utc).isoformat()
                        print(f"📝 Received manual storm report: {report_payload['typeText']}")
                        manual_lsrs.append(report_payload)

                        # Track for daily statistics
                        try:
                            stats_tracker = get_daily_stats_tracker()
                            # Convert manual LSR format to standardized format
                            report_data = {
                                'type': report_payload.get('type', 'unknown'),
                                'magnitude': report_payload.get('magnitude', ''),
                                'location': report_payload.get('location', 'Unknown'),
                                'time': report_payload['timestamp'],
                                'geometry': {
                                    'coordinates': [report_payload['lng'], report_payload['lat']]
                                }
                            }
                            stats_tracker.record_storm_report(report_data)
                        except Exception as e:
                            print(f"⚠️ Error tracking manual LSR for daily stats: {e}")

                        # Immediately broadcast the update so everyone sees it
                        await broadcast_updates()
                
                elif data.get('type') == 'feature_camera':
                    print(f"Featuring ODOT Camera: {data.get('camera_data', {}).get('title')}")
                    # Re-broadcast this message to all clients (including our new camera widget)
                    await broadcast_message(message)
                    
                elif data.get('type') == 'hide_camera_widget':
                    print("Broadcasting request to hide camera widget.")
                    await broadcast_message(message)
                    
                elif data.get('type') == 'clear_manual_lsrs':
                    print("🗑️ Clearing all manual storm reports.")
                    manual_lsrs.clear() # This empties the list
                    await broadcast_updates() # This tells everyone the list is now empty

                elif data.get('type') == 'remove_viewer_report':
                    report_id = data.get('report_id')
                    if report_id:
                        # Find and remove the report with this ID
                        initial_count = len(manual_lsrs)
                        manual_lsrs[:] = [r for r in manual_lsrs if r.get('id') != report_id]
                        removed_count = initial_count - len(manual_lsrs)

                        if removed_count > 0:
                            print(f"🗑️ Removed viewer report: {report_id}")
                            await broadcast_updates()
                        else:
                            print(f"⚠️ Could not find viewer report with ID: {report_id}")

                elif data.get('type') == 'update_ticker_settings':
                    settings = data.get('settings', {})
                    print(f"⚙️ Received ticker settings to broadcast: {settings}")

                    # Save ticker theme to config.json if provided
                    if 'theme' in settings:
                        try:
                            with open('config.json', 'r') as f:
                                config_data = json.load(f)
                            config_data['ticker_theme'] = settings['theme']
                            with open('config.json', 'w') as f:
                                json.dump(config_data, f, indent=2)
                            print(f"💾 Saved ticker theme to config.json: {settings['theme']}")
                            # Reload config
                            config.reload()
                        except Exception as e:
                            print(f"❌ Error saving ticker theme: {e}")

                    # Prepare the message to send out to all ticker clients
                    broadcast_payload = {
                        "type": "ticker_settings_update",
                        "settings": settings
                    }

                    # Use the existing broadcast function to send to all clients
                    await broadcast_message(json.dumps(broadcast_payload))
                    
                elif data.get('type') in ['show_lower_third', 'hide_lower_third']:
                    print(f"Broadcasting command: {data.get('type')}")
                    await broadcast_message(message)
                
                elif data.get('type') == 'zoom':
                    # Support both coordinate-based and location-based zoom
                    if 'latitude' in data and 'longitude' in data:
                        lat = data['latitude']
                        lon = data['longitude']
                        print(f"🔎 Received zoom request for coordinates: ({lat}, {lon})")
                        loop = asyncio.get_running_loop()
                        await loop.run_in_executor(
                            None,
                            lambda: weatherwise_control.zoom_to_location(latitude=lat, longitude=lon)
                        )
                    elif 'location' in data:
                        location = data['location']
                        print(f"🔎 Received zoom request for location: {location}")
                        loop = asyncio.get_running_loop()
                        await loop.run_in_executor(
                            None,
                            lambda: weatherwise_control.zoom_to_location(location_name=location)
                        )

                # === TEST ALERT INJECTION ===
                elif data.get('type') == 'inject_test_alert':
                    print("🧪 TEST ALERT INJECTION RECEIVED")
                    alert_data = data.get('alert_data')
                    alert_source = data.get('source', 'nwws')

                    if not alert_data:
                        print("❌ No alert data provided")
                        continue

                    try:
                        if alert_source == 'api':
                            # Update timestamps to be current/future
                            print(f"🧪 Updating API alert timestamps to current time...")
                            alert_data_updated = update_test_alert_json_timestamps(alert_data, hours_from_now=1)

                            # Simulate API alert processing
                            print(f"🧪 Injecting TEST API alert: {alert_data_updated.get('properties', {}).get('headline', 'Unknown')}")
                            parsed_alert = parse_alert(alert_data_updated)

                            # Mark as test alert
                            if parsed_alert:
                                parsed_alert.product_id = f"TEST.{parsed_alert.product_id or 'UNKNOWN'}"

                                # Process zone geometry if needed
                                async with aiohttp.ClientSession() as session:
                                    await zone_geometry_service.populate_alert_with_zone_geometry(parsed_alert, session)

                                # Populate FIPS codes
                                if parsed_alert.affected_areas:
                                    populate_fips_codes_from_ugc(parsed_alert)

                                # Mark as test alert
                                parsed_alert.is_test = True

                                # Add to active alerts
                                active_alerts[parsed_alert.product_id] = parsed_alert

                                # Track alert for daily statistics
                                try:
                                    stats_tracker = get_daily_stats_tracker()
                                    stats_tracker.record_alert(parsed_alert)
                                except Exception as e:
                                    print(f"⚠️ Error tracking test alert for daily stats: {e}")

                                print(f"✅ TEST alert added: {parsed_alert.product_id} ({parsed_alert.phenomenon})")
                                await broadcast_updates()

                        elif alert_source == 'nwws':
                            # Update timestamps to be current/future
                            print(f"🧪 Updating NWWS alert timestamps to current time...")
                            alert_data_updated = update_test_alert_timestamps(alert_data, hours_from_now=1)

                            # Simulate NWWS/Weather Wire text alert (mark as test)
                            print(f"🧪 Injecting TEST NWWS alert (first 80 chars): {alert_data_updated[:80]}...")
                            await handle_incoming_alert(alert_data_updated, is_test=True)
                            print(f"✅ TEST NWWS alert processed")

                        else:
                            print(f"❌ Unknown alert source: {alert_source}")

                    except Exception as e:
                        print(f"❌ Error injecting test alert: {e}")
                        import traceback
                        traceback.print_exc()

                elif data.get('type') == 'clear_test_alerts':
                    # Remove all alerts marked as test alerts
                    test_alert_ids = [alert_id for alert_id, alert in active_alerts.items() if alert.is_test]
                    for alert_id in test_alert_ids:
                        del active_alerts[alert_id]
                    print(f"✅ Cleared {len(test_alert_ids)} test alert(s)")
                    await broadcast_updates()

                elif data.get('type') == 'clear_alert':
                    # Manually clear a specific alert by product_id
                    product_id = data.get('product_id')
                    if product_id and product_id in active_alerts:
                        removed_alert = active_alerts[product_id]
                        del active_alerts[product_id]
                        print(f"🗑️ Manually cleared alert: {product_id} ({removed_alert.phenomenon})")
                        await broadcast_updates()
                    else:
                        print(f"⚠️ Alert not found for manual clearing: {product_id}")

                # === DAILY RECAP / SUMMARY HANDLERS ===
                elif data.get('type') == 'get_daily_summary':
                    # Return current day's running statistics
                    try:
                        stats_tracker = get_daily_stats_tracker()
                        summary = stats_tracker.generate_summary()
                        await websocket.send(json.dumps({
                            'type': 'daily_summary',
                            'data': summary
                        }))
                    except Exception as e:
                        print(f"❌ Error getting daily summary: {e}")

                elif data.get('type') == 'get_previous_day_summary':
                    # Return yesterday's finalized summary
                    try:
                        stats_tracker = get_daily_stats_tracker()
                        date = data.get('date')  # Optional: specific date in YYYY-MM-DD format
                        if not date:
                            yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
                            date = yesterday

                        summary = stats_tracker.load_daily_summary(date)
                        if summary:
                            await websocket.send(json.dumps({
                                'type': 'previous_day_summary',
                                'data': summary
                            }))
                        else:
                            await websocket.send(json.dumps({
                                'type': 'previous_day_summary',
                                'data': None,
                                'error': f'No summary found for {date}'
                            }))
                    except Exception as e:
                        print(f"❌ Error getting previous day summary: {e}")

                elif data.get('type') == 'get_summary_history':
                    # Return list of recent daily summaries
                    try:
                        stats_tracker = get_daily_stats_tracker()
                        days = data.get('days', 7)
                        summaries = stats_tracker.load_recent_summaries(days)
                        await websocket.send(json.dumps({
                            'type': 'summary_history',
                            'data': summaries
                        }))
                    except Exception as e:
                        print(f"❌ Error getting summary history: {e}")

                elif data.get('type') == 'get_monthly_summary':
                    # Return monthly aggregated stats
                    try:
                        stats_tracker = get_daily_stats_tracker()
                        month = data.get('month')  # Format: YYYY-MM
                        if not month:
                            month = datetime.now().strftime('%Y-%m')

                        summary = stats_tracker.load_monthly_summary(month)
                        if summary:
                            await websocket.send(json.dumps({
                                'type': 'monthly_summary',
                                'data': summary
                            }))
                        else:
                            await websocket.send(json.dumps({
                                'type': 'monthly_summary',
                                'data': None,
                                'error': f'No summary found for {month}'
                            }))
                    except Exception as e:
                        print(f"❌ Error getting monthly summary: {e}")

            except json.JSONDecodeError:
                print(f"Received non-JSON message: {message}")
            except Exception as e:
                print(f"Error processing client message: {e}")
    except websockets.exceptions.ConnectionClosed:
        print("Client connection closed.")
    finally:
        message_broker.remove_client(websocket)

# ==================================================================================
# IP BLOCKING SYSTEM FOR STORM REPORTS
# ==================================================================================

BLOCKED_IPS_FILE = "blocked_ips.json"

def load_blocked_ips():
    """Load blocked IPs from file"""
    try:
        with open(BLOCKED_IPS_FILE, 'r') as f:
            data = json.load(f)
            return data.get('blocked_ips', []), data.get('blocked_submissions', [])
    except FileNotFoundError:
        return [], []
    except Exception as e:
        print(f"Error loading blocked IPs: {e}")
        return [], []

def save_blocked_ips(blocked_ips, blocked_submissions):
    """Save blocked IPs to file"""
    try:
        with open(BLOCKED_IPS_FILE, 'w') as f:
            json.dump({
                'blocked_ips': blocked_ips,
                'blocked_submissions': blocked_submissions
            }, f, indent=4)
        return True
    except Exception as e:
        print(f"Error saving blocked IPs: {e}")
        return False

def is_ip_blocked(ip_address):
    """Check if an IP is blocked"""
    blocked_ips, _ = load_blocked_ips()
    return ip_address in blocked_ips

def add_blocked_ip(ip_address, reason=""):
    """Add an IP to the blocklist"""
    blocked_ips, blocked_submissions = load_blocked_ips()
    if ip_address not in blocked_ips:
        blocked_ips.append(ip_address)
        save_blocked_ips(blocked_ips, blocked_submissions)
        print(f"🚫 Blocked IP: {ip_address} - Reason: {reason}")
        return True
    return False

def remove_blocked_ip(ip_address):
    """Remove an IP from the blocklist"""
    blocked_ips, blocked_submissions = load_blocked_ips()
    if ip_address in blocked_ips:
        blocked_ips.remove(ip_address)
        save_blocked_ips(blocked_ips, blocked_submissions)
        print(f"✅ Unblocked IP: {ip_address}")
        return True
    return False

def log_blocked_submission(ip_address, data):
    """Log a blocked submission attempt"""
    blocked_ips, blocked_submissions = load_blocked_ips()
    blocked_submissions.append({
        'ip': ip_address,
        'timestamp': datetime.now(timezone.utc).isoformat(),
        'data': {
            'type': data.get('type', ''),
            'location': data.get('location', ''),
            'submitter': data.get('name', 'Anonymous')
        }
    })
    # Keep only last 100 blocked submissions
    if len(blocked_submissions) > 100:
        blocked_submissions = blocked_submissions[-100:]
    save_blocked_ips(blocked_ips, blocked_submissions)

class CustomHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    """Custom HTTP handler to serve alert configuration JSON"""

    # Rate limiting for Nominatim API calls (1 request per second per Nominatim usage policy)
    _last_nominatim_request = 0
    _nominatim_lock = threading.Lock()

    def do_GET(self):
        """Handle GET requests"""
        # Serve alert config JSON endpoint
        if self.path == '/api/alert_config':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()

            # Load and serve the alert configuration
            from alert_config_loader import get_alert_config
            alert_config = get_alert_config()
            config_data = alert_config.get_config_for_frontend()

            # Add dashboard_password and OBS credentials from environment
            config_data['dashboard_password'] = DASHBOARD_PASSWORD or ''
            config_data['obs_websocket_password'] = OBS_WEBSOCKET_PASSWORD or ''
            config_data['obs_websocket_url'] = OBS_WEBSOCKET_URL

            config_json = json.dumps(config_data, indent=2)
            self.wfile.write(config_json.encode('utf-8'))
            return

        # Health check endpoint
        if self.path == '/health' or self.path == '/api/health':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()

            # Gather health status information
            uptime_seconds = (datetime.now() - _SERVER_START_TIME).total_seconds()
            health_data = {
                "status": "healthy",
                "timestamp": datetime.now().isoformat(),
                "uptime_seconds": uptime_seconds,
                "uptime_formatted": f"{int(uptime_seconds // 3600)}h {int((uptime_seconds % 3600) // 60)}m",
                "environment": ENVIRONMENT,
                "alert_source": config.get("alert_source", "unknown"),
                "active_alerts_count": len(alert_manager.active_alerts),
                "websocket_clients": len(message_broker.connected_clients),
                "nwws_connected": hasattr(nwws_client, 'session_started') if 'nwws_client' in globals() else False,
                "python_version": sys.version.split()[0]
            }

            health_json = json.dumps(health_data, indent=2)
            self.wfile.write(health_json.encode('utf-8'))
            return

        # Proxy endpoint for Nominatim reverse geocoding (to avoid CORS)
        if self.path.startswith('/api/geocode_reverse'):
            import urllib.parse
            parsed_url = urllib.parse.urlparse(self.path)
            params = urllib.parse.parse_qs(parsed_url.query)
            lat = params.get('lat', [''])[0]
            lon = params.get('lon', [''])[0]

            if not lat or not lon:
                self.send_response(400)
                self.send_header('Content-type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                error_response = json.dumps({"error": "Missing lat or lon parameter"})
                self.wfile.write(error_response.encode('utf-8'))
                return

            try:
                import urllib.request
                import time

                # Rate limit: ensure at least 1 second between Nominatim requests
                with self._nominatim_lock:
                    time_since_last = time.time() - self._last_nominatim_request
                    if time_since_last < 1.0:
                        time.sleep(1.0 - time_since_last)
                    self.__class__._last_nominatim_request = time.time()

                nominatim_url = f"https://nominatim.openstreetmap.org/reverse?format=json&lat={lat}&lon={lon}"
                req = urllib.request.Request(
                    nominatim_url,
                    headers={
                        'User-Agent': 'ONWAlertDashboard/1.0 (https://belparkmedia.com)',
                        'Referer': 'https://belparkmedia.com'
                    }
                )
                with urllib.request.urlopen(req, timeout=10) as response:
                    data = response.read()
                    self.send_response(200)
                    self.send_header('Content-type', 'application/json')
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.end_headers()
                    self.wfile.write(data)
                    return
            except Exception as e:
                print(f"Error proxying reverse geocode request: {e}")
                self.send_response(500)
                self.send_header('Content-type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                error_response = json.dumps({"error": str(e)})
                self.wfile.write(error_response.encode('utf-8'))
                return

        # Proxy endpoint for Nominatim search geocoding (to avoid CORS)
        if self.path.startswith('/api/geocode_search'):
            import urllib.parse
            parsed_url = urllib.parse.urlparse(self.path)
            params = urllib.parse.parse_qs(parsed_url.query)
            query = params.get('q', [''])[0]

            if not query:
                self.send_response(400)
                self.send_header('Content-type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                error_response = json.dumps({"error": "Missing q parameter"})
                self.wfile.write(error_response.encode('utf-8'))
                return

            try:
                import urllib.request
                import time

                # Rate limit: ensure at least 1 second between Nominatim requests
                with self._nominatim_lock:
                    time_since_last = time.time() - self._last_nominatim_request
                    if time_since_last < 1.0:
                        time.sleep(1.0 - time_since_last)
                    self.__class__._last_nominatim_request = time.time()

                nominatim_url = f"https://nominatim.openstreetmap.org/search?format=json&q={urllib.parse.quote(query)}"
                req = urllib.request.Request(
                    nominatim_url,
                    headers={
                        'User-Agent': 'ONWAlertDashboard/1.0 (https://belparkmedia.com)',
                        'Referer': 'https://belparkmedia.com'
                    }
                )
                with urllib.request.urlopen(req, timeout=10) as response:
                    data = response.read()
                    self.send_response(200)
                    self.send_header('Content-type', 'application/json')
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.end_headers()
                    self.wfile.write(data)
                    return
            except Exception as e:
                print(f"Error proxying search geocode request: {e}")
                self.send_response(500)
                self.send_header('Content-type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                error_response = json.dumps({"error": str(e)})
                self.wfile.write(error_response.encode('utf-8'))
                return

        # Serve snow report data for snow accumulation map
        if self.path.startswith('/api/snow_reports'):
            import urllib.parse
            # datetime and timedelta already imported at top of file
            parsed_url = urllib.parse.urlparse(self.path)
            params = urllib.parse.parse_qs(parsed_url.query)

            # Default parameters
            states = params.get('states', ['OH'])[0]
            hours = params.get('hours', ['24'])[0]

            try:
                import urllib.request

                # Filter for snow reports only
                snow_reports = {
                    "type": "FeatureCollection",
                    "features": []
                }

                # 1. Fetch LSR data from Iowa State Mesonet
                lsr_url = f"https://mesonet.agron.iastate.edu/geojson/lsr.geojson?states={states}&hours={hours}"
                with urllib.request.urlopen(lsr_url) as response:
                    lsr_data = json.loads(response.read().decode())

                for feature in lsr_data.get('features', []):
                    props = feature.get('properties', {})
                    typetext = props.get('typetext', '').upper()

                    # Include SNOW and HEAVY SNOW reports
                    if 'SNOW' in typetext and props.get('magnitude'):
                        snow_reports['features'].append(feature)

                # 2. Fetch NWS ASOS/AWOS station snow data
                # Get snow depth data from surrounding states too for border interpolation
                networks = ['OH_ASOS', 'PA_ASOS', 'WV_ASOS', 'KY_ASOS', 'IN_ASOS', 'MI_ASOS']

                # Calculate time range
                now = datetime.now(timezone.utc)
                start = now - timedelta(hours=int(hours))

                # Request snow depth data from IEM ASOS
                asos_url = (
                    f"https://mesonet.agron.iastate.edu/cgi-bin/request/asos.py?"
                    f"data=snowdepth&tz=Etc/UTC&format=onlycomma&missing=null&trace=null"
                    f"&year1={start.year}&month1={start.month}&day1={start.day}"
                    f"&hour1={start.hour}&minute1={start.minute}"
                    f"&year2={now.year}&month2={now.month}&day2={now.day}"
                    f"&hour2={now.hour}&minute2={now.minute}"
                )

                for network in networks:
                    try:
                        network_url = asos_url + f"&network={network}"
                        with urllib.request.urlopen(network_url, timeout=5) as response:
                            csv_data = response.read().decode('utf-8')

                            # Parse CSV and get latest snow depth per station
                            lines = csv_data.strip().split('\n')
                            if len(lines) > 1:  # Skip if only header
                                station_snow = {}  # Track latest reading per station

                                for line in lines[1:]:  # Skip header
                                    parts = line.split(',')
                                    if len(parts) >= 4:
                                        station = parts[0]
                                        timestamp = parts[1]
                                        lat = parts[2]
                                        lon = parts[3]
                                        snowdepth = parts[4] if len(parts) > 4 else None

                                        # Skip if no valid snow depth
                                        if not snowdepth or snowdepth == 'null' or snowdepth == '':
                                            continue

                                        try:
                                            depth = float(snowdepth)
                                            if depth > 0:  # Only include positive snow depths
                                                # Keep latest reading per station
                                                if station not in station_snow or timestamp > station_snow[station]['time']:
                                                    station_snow[station] = {
                                                        'depth': depth,
                                                        'lat': float(lat),
                                                        'lon': float(lon),
                                                        'time': timestamp
                                                    }
                                        except ValueError:
                                            continue

                                # Add station data as features
                                for station, data in station_snow.items():
                                    feature = {
                                        "type": "Feature",
                                        "geometry": {
                                            "type": "Point",
                                            "coordinates": [data['lon'], data['lat']]
                                        },
                                        "properties": {
                                            "magnitude": str(data['depth']),
                                            "typetext": "ASOS_SNOW_DEPTH",
                                            "city": station,
                                            "county": network.replace('_ASOS', ''),
                                            "valid": data['time'],
                                            "remark": f"Automated station snow depth"
                                        }
                                    }
                                    snow_reports['features'].append(feature)
                    except Exception as e:
                        print(f"Warning: Could not fetch ASOS data for {network}: {e}")
                        continue

                # 3. Fetch CoCoRaHS snow reports
                try:
                    # CoCoRaHS API endpoint for snow observations
                    # Format: DateType=reportdate&Start Date=YYYY-MM-DD&EndDate=YYYY-MM-DD&State=OH
                    start_date = start.strftime('%m/%d/%Y')
                    end_date = now.strftime('%m/%d/%Y')

                    cocorahs_url = (
                        f"https://data.cocorahs.org/export/exportreports.aspx?"
                        f"ReportType=Daily&dtf=1&Format=JSON&State=OH"
                        f"&ReportDateType=reportdate&Date={end_date}"
                        f"&TimesInGMT=False"
                    )

                    req = urllib.request.Request(
                        cocorahs_url,
                        headers={'User-Agent': 'ONWAlertDashboard/1.0 (https://belparkmedia.com)'}
                    )

                    with urllib.request.urlopen(req, timeout=15) as response:
                        cocorahs_data = json.loads(response.read().decode('utf-8'))

                        # Check if the response is a list (valid data) or string (error message)
                        if not isinstance(cocorahs_data, list):
                            print(f"Warning: CoCoRaHS API returned non-list data: {type(cocorahs_data)}")
                            cocorahs_data = []

                        for obs in cocorahs_data:
                            # Ensure obs is a dictionary
                            if not isinstance(obs, dict):
                                continue

                            # Extract snowfall data
                            snowfall = obs.get('TotalSnowfall', None)
                            if snowfall and float(snowfall) > 0:
                                lat = float(obs.get('Latitude', 0))
                                lon = float(obs.get('Longitude', 0))

                                if lat and lon:
                                    feature = {
                                        "type": "Feature",
                                        "geometry": {
                                            "type": "Point",
                                            "coordinates": [lon, lat]
                                        },
                                        "properties": {
                                            "magnitude": str(snowfall),
                                            "typetext": "COCORAHS_SNOW",
                                            "city": obs.get('StationName', 'CoCoRaHS Station'),
                                            "county": obs.get('CountyName', ''),
                                            "valid": obs.get('ObservationDate', ''),
                                            "remark": f"CoCoRaHS: {snowfall}\" snowfall"
                                        }
                                    }
                                    snow_reports['features'].append(feature)

                    print(f"Fetched {len([f for f in snow_reports['features'] if f['properties']['typetext'] == 'COCORAHS_SNOW'])} CoCoRaHS observations")
                except Exception as e:
                    print(f"Warning: Could not fetch CoCoRaHS data: {e}")

                # 4. Add viewer-submitted snow reports from manual_lsrs
                for report in manual_lsrs:
                    typetext = report.get('typeText', '').upper()
                    # Include SNOW and winter-related reports
                    if 'SNOW' in typetext and report.get('magnitude'):
                        try:
                            # Parse magnitude to get numeric value
                            magnitude_str = str(report.get('magnitude', '0'))
                            # Remove non-numeric characters except decimal point
                            magnitude_clean = ''.join(c for c in magnitude_str if c.isdigit() or c == '.')

                            if magnitude_clean:
                                feature = {
                                    "type": "Feature",
                                    "geometry": {
                                        "type": "Point",
                                        "coordinates": [report['lng'], report['lat']]
                                    },
                                    "properties": {
                                        "magnitude": magnitude_clean,
                                        "typetext": "VIEWER_SNOW",
                                        "city": report.get('location', 'Unknown'),
                                        "county": "",
                                        "valid": report.get('timestamp', ''),
                                        "remark": f"Viewer report: {report.get('remarks', 'No details')}"
                                    }
                                }
                                snow_reports['features'].append(feature)
                        except (ValueError, KeyError) as e:
                            print(f"Warning: Could not process viewer snow report: {e}")
                            continue

                print(f"Snow map API: Returning {len(snow_reports['features'])} snow observations")

                try:
                    self.send_response(200)
                    self.send_header('Content-type', 'application/json')
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.end_headers()
                    self.wfile.write(json.dumps(snow_reports).encode('utf-8'))
                except (ConnectionAbortedError, BrokenPipeError):
                    # Client disconnected before response was sent - this is normal
                    pass
                return

            except Exception as e:
                print(f"Error fetching snow reports: {e}")
                import traceback
                traceback.print_exc()
                try:
                    self.send_response(500)
                    self.send_header('Content-type', 'application/json')
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.end_headers()
                    error_response = json.dumps({"error": str(e)})
                    self.wfile.write(error_response.encode('utf-8'))
                except (ConnectionAbortedError, BrokenPipeError):
                    # Client disconnected - can't send error response
                    pass
                return

        # API endpoint: Get blocklist data
        if self.path == '/api/blocklist':
            try:
                blocked_ips, blocked_submissions = load_blocked_ips()
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                response_data = json.dumps({
                    'blocked_ips': blocked_ips,
                    'blocked_submissions': blocked_submissions
                })
                self.wfile.write(response_data.encode('utf-8'))
                return
            except Exception as e:
                print(f"Error getting blocklist: {e}")
                self.send_response(500)
                self.send_header('Content-type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                error_response = json.dumps({"error": str(e)})
                self.wfile.write(error_response.encode('utf-8'))
                return

        # API endpoint: Get recent submissions
        if self.path == '/api/recent_submissions':
            try:
                # Get last 50 submissions from manual_lsrs
                recent = manual_lsrs[-50:] if len(manual_lsrs) > 50 else manual_lsrs
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                response_data = json.dumps({
                    'submissions': recent
                })
                self.wfile.write(response_data.encode('utf-8'))
                return
            except Exception as e:
                print(f"Error getting recent submissions: {e}")
                self.send_response(500)
                self.send_header('Content-type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                error_response = json.dumps({"error": str(e)})
                self.wfile.write(error_response.encode('utf-8'))
                return

        # Default behavior for all other paths
        super().do_GET()

    def do_OPTIONS(self):
        """Handle OPTIONS requests for CORS preflight"""
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'POST, GET, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def do_POST(self):
        """Handle POST requests"""
        # Handle storm report submission
        if self.path == '/api/submit_storm_report':
            try:
                # Get client IP address
                client_ip = self.client_address[0]

                # Check if IP is blocked
                if is_ip_blocked(client_ip):
                    print(f"🚫 Blocked submission attempt from: {client_ip}")
                    self.send_response(403)
                    self.send_header('Content-type', 'application/json')
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.end_headers()
                    error_response = json.dumps({"error": "Your IP address has been blocked from submitting reports"})
                    self.wfile.write(error_response.encode('utf-8'))

                    # Log the blocked attempt
                    try:
                        content_length = int(self.headers['Content-Length'])
                        post_data = self.rfile.read(content_length)
                        data = json.loads(post_data.decode('utf-8'))
                        log_blocked_submission(client_ip, data)
                    except:
                        pass
                    return

                # Read request body
                content_length = int(self.headers['Content-Length'])
                post_data = self.rfile.read(content_length)
                data = json.loads(post_data.decode('utf-8'))

                # Verify reCAPTCHA
                recaptcha_response = data.get('recaptcha')
                recaptcha_secret = RECAPTCHA_SECRET_KEY

                if recaptcha_secret:
                    import urllib.request
                    import urllib.parse

                    verify_url = 'https://www.google.com/recaptcha/api/siteverify'
                    verify_data = urllib.parse.urlencode({
                        'secret': recaptcha_secret,
                        'response': recaptcha_response
                    }).encode('utf-8')

                    try:
                        verify_request = urllib.request.Request(verify_url, data=verify_data)
                        verify_response = urllib.request.urlopen(verify_request)
                        verify_result = json.loads(verify_response.read().decode('utf-8'))

                        if not verify_result.get('success'):
                            self.send_response(400)
                            self.send_header('Content-type', 'application/json')
                            self.send_header('Access-Control-Allow-Origin', '*')
                            self.end_headers()
                            error_response = json.dumps({"error": "reCAPTCHA verification failed"})
                            self.wfile.write(error_response.encode('utf-8'))
                            return
                    except Exception as e:
                        print(f"Warning: reCAPTCHA verification failed: {e}")
                        # Continue anyway if reCAPTCHA service is down
                else:
                    print("Warning: No reCAPTCHA secret key configured")

                # Validate required fields
                required_fields = ['type', 'location', 'magnitude', 'datetime', 'latitude', 'longitude']
                missing_fields = [field for field in required_fields if not data.get(field)]

                if missing_fields:
                    self.send_response(400)
                    self.send_header('Content-type', 'application/json')
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.end_headers()
                    error_response = json.dumps({"error": f"Missing required fields: {', '.join(missing_fields)}"})
                    self.wfile.write(error_response.encode('utf-8'))
                    return

                # Create report payload
                report_payload = {
                    'id': str(uuid.uuid4()),
                    'lat': float(data['latitude']),
                    'lng': float(data['longitude']),
                    'typeText': data['type'],
                    'magnitude': data['magnitude'],
                    'remarks': data.get('notes', ''),
                    'timestamp': data['datetime'],
                    'location': data['location'],
                    'submitter': data.get('name', 'Anonymous'),
                    'source': 'viewer',  # Mark as viewer-submitted
                    'ip_address': client_ip  # Store IP for tracking
                }

                # Add to manual LSRs
                manual_lsrs.append(report_payload)
                print(f"📝 Received public storm report: {report_payload['typeText']} from {report_payload['submitter']} (IP: {client_ip})")

                # Track for daily statistics if it's a severe report
                try:
                    typetext_upper = report_payload['typeText'].upper()
                    if any(keyword in typetext_upper for keyword in ['TORNADO', 'HAIL', 'WIND', 'FLOOD']):
                        if hasattr(alert_manager, 'stats_manager') and alert_manager.stats_manager:
                            alert_manager.stats_manager.increment_stat('lsr_reports_received')
                except Exception as e:
                    print(f"Warning: Could not update LSR stats: {e}")

                # Broadcast to all connected clients
                if main_event_loop:
                    asyncio.run_coroutine_threadsafe(
                        broadcast_updates(),
                        main_event_loop
                    )

                # Send success response
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                success_response = json.dumps({
                    "success": True,
                    "message": "Storm report submitted successfully",
                    "report_id": report_payload['id']
                })
                self.wfile.write(success_response.encode('utf-8'))
                print(f"✅ Storm report {report_payload['id']} submitted successfully")

            except json.JSONDecodeError:
                self.send_response(400)
                self.send_header('Content-type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                error_response = json.dumps({"error": "Invalid JSON in request body"})
                self.wfile.write(error_response.encode('utf-8'))

            except Exception as e:
                print(f"Error processing storm report submission: {e}")
                import traceback
                traceback.print_exc()
                self.send_response(500)
                self.send_header('Content-type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                error_response = json.dumps({"error": str(e)})
                self.wfile.write(error_response.encode('utf-8'))
            return

        # API endpoint: Add IP to blocklist
        if self.path == '/api/blocklist/add':
            try:
                content_length = int(self.headers['Content-Length'])
                post_data = self.rfile.read(content_length)
                data = json.loads(post_data.decode('utf-8'))

                ip = data.get('ip')
                if not ip:
                    self.send_response(400)
                    self.send_header('Content-type', 'application/json')
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.end_headers()
                    error_response = json.dumps({"error": "Missing IP address"})
                    self.wfile.write(error_response.encode('utf-8'))
                    return

                # Add IP to blocklist
                success = add_blocked_ip(ip, "Manually blocked via admin interface")

                if success:
                    self.send_response(200)
                    self.send_header('Content-type', 'application/json')
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.end_headers()
                    success_response = json.dumps({"success": True, "message": f"IP {ip} blocked successfully"})
                    self.wfile.write(success_response.encode('utf-8'))
                else:
                    self.send_response(400)
                    self.send_header('Content-type', 'application/json')
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.end_headers()
                    error_response = json.dumps({"error": "IP already blocked"})
                    self.wfile.write(error_response.encode('utf-8'))
                return

            except Exception as e:
                print(f"Error adding blocked IP: {e}")
                self.send_response(500)
                self.send_header('Content-type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                error_response = json.dumps({"error": str(e)})
                self.wfile.write(error_response.encode('utf-8'))
                return

        # API endpoint: Remove IP from blocklist
        if self.path == '/api/blocklist/remove':
            try:
                content_length = int(self.headers['Content-Length'])
                post_data = self.rfile.read(content_length)
                data = json.loads(post_data.decode('utf-8'))

                ip = data.get('ip')
                if not ip:
                    self.send_response(400)
                    self.send_header('Content-type', 'application/json')
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.end_headers()
                    error_response = json.dumps({"error": "Missing IP address"})
                    self.wfile.write(error_response.encode('utf-8'))
                    return

                # Remove IP from blocklist
                success = remove_blocked_ip(ip)

                if success:
                    self.send_response(200)
                    self.send_header('Content-type', 'application/json')
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.end_headers()
                    success_response = json.dumps({"success": True, "message": f"IP {ip} unblocked successfully"})
                    self.wfile.write(success_response.encode('utf-8'))
                else:
                    self.send_response(400)
                    self.send_header('Content-type', 'application/json')
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.end_headers()
                    error_response = json.dumps({"error": "IP not found in blocklist"})
                    self.wfile.write(error_response.encode('utf-8'))
                return

            except Exception as e:
                print(f"Error removing blocked IP: {e}")
                self.send_response(500)
                self.send_header('Content-type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                error_response = json.dumps({"error": str(e)})
                self.wfile.write(error_response.encode('utf-8'))
                return

        # Default 404 for unknown POST paths
        self.send_response(404)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        error_response = json.dumps({"error": "Not found"})
        self.wfile.write(error_response.encode('utf-8'))

def start_http_server():
    """Starts an HTTP/HTTPS server in a separate thread."""
    handler = CustomHTTPRequestHandler

    # Check if SSL certificates are available (auto-enabled in production)
    use_ssl = IS_PRODUCTION
    cert_path = os.getenv("SSL_CERT_PATH", "C:\\ssl-certs\\atmosphericx.ddns.net-chain.pem")
    key_path = os.getenv("SSL_KEY_PATH", "C:\\ssl-certs\\atmosphericx.ddns.net-key.pem")

    with socketserver.TCPServer(("", HTTP_PORT), handler) as httpd:
        if use_ssl:
            try:
                # Wrap the socket with SSL
                context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
                context.load_cert_chain(certfile=cert_path, keyfile=key_path)
                httpd.socket = context.wrap_socket(httpd.socket, server_side=True)

                print(f"✅ HTTPS server started on https://{WEBSOCKET_HOST}:{HTTP_PORT}")
                print(f"   View your dashboard at https://atmosphericx.ddns.net:{HTTP_PORT}/index.html")
                print(f"   Alert config API: https://atmosphericx.ddns.net:{HTTP_PORT}/api/alert_config")
            except FileNotFoundError:
                print(f"❌ SSL certificate files not found!")
                print(f"   Expected cert: {cert_path}")
                print(f"   Expected key: {key_path}")
                print(f"   Falling back to HTTP...")
                use_ssl = False

        if not use_ssl:
            print(f"✅ HTTP server started on http://{WEBSOCKET_HOST}:{HTTP_PORT}")
            print(f"   View your dashboard at http://<Your_Remote_IP>:{HTTP_PORT}/index.html")
            print(f"   Alert config API: http://{WEBSOCKET_HOST}:{HTTP_PORT}/api/alert_config")

        httpd.serve_forever()
            
async def watch_config_file():
    """Periodically checks the config file for changes and reloads it without a restart."""
    global config
    print("⚙️ Configuration watcher started. Checking for changes every 60 seconds.")
    while True:
        await asyncio.sleep(60)
        try:
            # Use ConfigManager's reload method
            if config_manager.reload():
                print("⚙️ Detected change in config.json. Reloading configuration...")
                # Update the config dict reference
                config = config_manager.as_dict()

                # Broadcast updates to clients so they get the new settings
                await broadcast_updates()

        except Exception as e:
            print(f"An unexpected error occurred while watching config file: {e}")


async def check_for_restart():
    """Checks if the configured restart interval has passed and triggers a graceful restart."""
    print(f"⏲️ Scheduled restart enabled. Checking every 60 minutes for a restart after {_RESTART_INTERVAL_HOURS} hours.")
    while True:
        await asyncio.sleep(3600)  # Check every 60 minutes
        elapsed_time = datetime.now() - _SERVER_START_TIME
        if elapsed_time.total_seconds() > _RESTART_INTERVAL_HOURS * 3600:
            print("⏳ Scheduled restart initiated. Saving state and restarting server...")
            await save_alerts_to_disk()
            # Find and terminate the current process to trigger the restart mechanism
            os.kill(os.getpid(), signal.SIGINT)


def finalize_daily_summary():
    """
    Called at midnight Eastern time to finalize the previous day's summary.
    Generates summary files and resets counters for the new day.
    """
    try:
        stats_tracker = get_daily_stats_tracker()

        # Use Eastern timezone for daily boundaries
        eastern = pytz.timezone('America/New_York')
        now_eastern = datetime.now(eastern)
        yesterday = (now_eastern - timedelta(days=1)).strftime('%Y-%m-%d')

        print(f"📊 Finalizing daily summary for {yesterday} (Eastern Time)...")
        stats_tracker.save_daily_summary(yesterday)

        # Reset for new day
        stats_tracker.current_date = now_eastern.strftime('%Y-%m-%d')
        stats_tracker.reset_for_new_day()

        print(f"✅ Daily summary finalized. Ready for {stats_tracker.current_date}")
    except Exception as e:
        print(f"❌ Error finalizing daily summary: {e}")
        import traceback
        traceback.print_exc()


async def daily_summary_scheduler():
    """
    Background task that runs the scheduler to finalize daily summaries at midnight.
    """
    print("📅 Daily summary scheduler started. Will finalize summaries at midnight.")

    # Schedule midnight task
    schedule.every().day.at("00:00").do(finalize_daily_summary)

    # Check for pending tasks every minute
    while True:
        schedule.run_pending()
        await asyncio.sleep(60)  # Check every minute


def check_and_finalize_previous_day():
    """
    On startup, check if yesterday's summary exists. If not, create it.
    This handles cases where the app was offline at midnight.
    Uses Eastern timezone for daily boundaries.
    """
    try:
        stats_tracker = get_daily_stats_tracker()

        # Use Eastern timezone for daily boundaries
        eastern = pytz.timezone('America/New_York')
        now_eastern = datetime.now(eastern)
        yesterday = (now_eastern - timedelta(days=1)).strftime('%Y-%m-%d')
        summary_path = os.path.join(stats_tracker.daily_dir, f"summary_{yesterday}.json")

        if not os.path.exists(summary_path):
            print(f"⚠️ No summary found for {yesterday} (Eastern Time). Creating placeholder summary...")
            # Create a summary with current data (might be incomplete if app was down)
            stats_tracker.save_daily_summary(yesterday)
        else:
            print(f"✅ Summary for {yesterday} already exists.")

        # Ensure we're tracking for today
        today = now_eastern.strftime('%Y-%m-%d')
        if stats_tracker.current_date != today:
            print(f"⚠️ Resetting stats tracker to today's date: {today} (Eastern Time)")
            stats_tracker.current_date = today
            stats_tracker.reset_for_new_day()

    except Exception as e:
        print(f"❌ Error checking previous day summary: {e}")


async def main():
    global main_event_loop

    # Store reference to the main event loop for HTTP thread
    main_event_loop = asyncio.get_event_loop()

    # Initialize logger with config setting
    log_level = config.get("log_level", "normal")
    set_log_level(log_level)

    # Start the HTTP server in a daemon thread so it doesn't block the main app
    http_thread = threading.Thread(target=start_http_server, daemon=True)
    http_thread.start()
    load_ugc_database()
    load_ugc_to_fips_map()

    # Check and finalize previous day's summary if needed
    check_and_finalize_previous_day()

    load_alerts_from_disk()
    await initial_api_state_load()


    asyncio.create_task(background_cleanup_task())
    asyncio.create_task(periodic_state_save_task())  # Periodic save of alerts and stats
    asyncio.create_task(watch_config_file())
    asyncio.create_task(poll_google_chat_messages())
    asyncio.create_task(poll_storm_threat_data())
    asyncio.create_task(poll_earthquake_data())  # Start earthquake polling
    asyncio.create_task(daily_summary_scheduler())  # Start daily recap scheduler


    if _RESTART_INTERVAL_HOURS > 0:
        asyncio.create_task(check_for_restart())
    
    
# ---------------------------------------------------------
    # SSL CONFIGURATION FOR WEBSOCKETS
    # ---------------------------------------------------------
    ssl_context = None
    # Check if we should use SSL (same logic as your HTTP server)
    if IS_PRODUCTION:
        cert_path = os.getenv("SSL_CERT_PATH", "C:\\ssl-certs\\atmosphericx.ddns.net-chain.pem")
        key_path = os.getenv("SSL_KEY_PATH", "C:\\ssl-certs\\atmosphericx.ddns.net-key.pem")
        
        try:
            ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            ssl_context.load_cert_chain(certfile=cert_path, keyfile=key_path)
            print(f"🔒 Secure WebSockets (WSS) Enabled using: {cert_path}")
        except FileNotFoundError:
            print(f"⚠️ SSL Certs not found at {cert_path}. Falling back to insecure WS.")
            ssl_context = None
        except Exception as e:
            print(f"❌ Error loading SSL certs: {e}")
            ssl_context = None

    # ---------------------------------------------------------
    # START WEBSOCKET SERVER (WITH SSL IF AVAILABLE)
    # ---------------------------------------------------------
    # We pass the ssl_context here. If it is None, it defaults to standard ws://
    async with websockets.serve(client_handler, WEBSOCKET_HOST, WEBSOCKET_PORT, ssl=ssl_context):
        protocol = "wss" if ssl_context else "ws"
        print(f"✅ WebSocket server started on {protocol}://{WEBSOCKET_HOST}:{WEBSOCKET_PORT}")

        if config.get("alert_source") == "nws_api":
            print("✅ Running in NWS API mode.")
            await poll_nws_api()
        else:
            print("✅ Running in NWWS (XMPP) mode.")
            jid = f"{NWWS_USERNAME}@nwws-oi.weather.gov"
            xmpp = NWWSBot(jid, NWWS_PASSWORD)
            xmpp.register_plugin('xep_0045')
            xmpp.connect()
            await asyncio.Event().wait()

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format='%(levelname)-8s %(message)s')
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nShutting down...")