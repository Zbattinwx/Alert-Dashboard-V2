# Guide: Adding New Alert Types

## Overview

Your alert tracking system now uses a **centralized configuration file** for all alert types. You can add, remove, or modify alert types by editing a single JSON file - no code changes required!

## Quick Start: Adding a New Alert Type

### Step 1: Edit the Configuration File

Open `alert_types_config.json` in your editor.

### Step 2: Add Your Alert Type

Add a new entry to the `"alert_types"` array. Here's an example for **Lake Effect Snow Warning**:

```json
{
  "phenomenon_code": "LESW",
  "nws_event_name": "Lake Effect Snow Warning",
  "display_name": "Lake Effect Snow Warning",
  "short_name": "Lake Effect Snow Warning",
  "priority": 7,
  "high_priority": true,
  "show_on_map": true,
  "icon": "fas fa-snowflake",
  "colors": {
    "primary": "#4169E1",
    "css_var": "#4169E1",
    "state_map": "#4169E1",
    "daily_recap": "#4169E1"
  },
  "map_style": {
    "color": "#4169E1",
    "weight": 3,
    "fillOpacity": 0.5
  }
}
```

### Step 3: Restart the Application

Restart your Python backend server. The new alert type will be loaded automatically!

### Step 4: Test

Inject a test alert or wait for a real one to verify it displays correctly.

---

## Configuration Field Reference

### Required Fields

| Field | Description | Example |
|-------|-------------|---------|
| `phenomenon_code` | Short code for this alert type (2-4 chars) | `"LESW"` |
| `nws_event_name` | Exact name from NWS alerts | `"Lake Effect Snow Warning"` |
| `display_name` | Name shown in dashboard | `"Lake Effect Snow Warning"` |
| `short_name` | Abbreviated name for ticker | `"Lake Effect Snow Warning"` |
| `priority` | Display priority (1=highest, 15=lowest) | `7` |
| `high_priority` | Triggers notifications/chimes? | `true` or `false` |
| `show_on_map` | Display on map widgets? | `true` or `false` |
| `show_on_dashboard` | Display on main dashboard? (optional, default: true) | `true` or `false` |
| `show_on_ticker` | Display on ticker/lower thirds? (optional, default: true) | `true` or `false` |
| `icon` | Font Awesome icon class | `"fas fa-snowflake"` |

### Colors Object

| Field | Description | Example |
|-------|-------------|---------|
| `primary` | Primary UI color (hex) | `"#4169E1"` |
| `css_var` | CSS variable color | `"#4169E1"` |
| `state_map` | Color for state map view | `"#4169E1"` |
| `daily_recap` | Color in daily summary | `"#4169E1"` |

### Map Style Object

| Field | Description | Example |
|-------|-------------|---------|
| `color` | Polygon outline color | `"#4169E1"` |
| `weight` | Line thickness (1-5) | `3` |
| `fillOpacity` | Fill transparency (0.0-1.0) | `0.5` |

---

## Special Handling: SPS Filtering

If you need to customize which Special Weather Statements are shown (e.g., exclude fire weather, include thunderstorms), edit the `special_handling` section:

```json
"special_handling": {
  "sps_thunderstorm_filter": {
    "enabled": true,
    "excluded_keywords": [
      "FIRE DANGER",
      "DENSE FOG",
      "LAKE EFFECT"  ← Add keywords to exclude
    ],
    "thunderstorm_keywords": [
      "THUNDERSTORM",
      "LIGHTNING"  ← Add keywords to include
    ]
  }
}
```

---

## Priority Level Guidelines

Lower number = higher priority (displays first)

- **1-3**: Life-threatening warnings (Tornado, Flash Flood, Severe Thunderstorm)
- **4-6**: Other warnings (Storm Surge, Watches)
- **7-10**: Winter warnings and advisories
- **11-15**: Lower priority alerts (SPS, advisories)

---

## Color Selection Tips

### Recommended Colors by Alert Type

| Alert Type | Suggested Color | Hex Code |
|------------|----------------|----------|
| Tornado | Red | `#FF0000` |
| Severe T-Storm | Orange | `#FFA500` |
| Flash Flood | Green | `#84ff00` |
| Winter Storm | Magenta/Pink | `#FF69B4` |
| Winter Advisory | Plum | `#DDA0DD` |
| Snow Squall | Deep Magenta | `#C71585` |
| Lake Effect Snow | Royal Blue | `#4169E1` |
| Watch | Yellow/Pale | `#FFFF00` |

### Color Contrast

- Use high contrast colors for readability
- Avoid similar colors for different alert types
- Test on both light and dark backgrounds

---

## Example: Complete Alert Entry

Here's a fully configured example:

```json
{
  "phenomenon_code": "LESW",
  "nws_event_name": "Lake Effect Snow Warning",
  "display_name": "Lake Effect Snow Warning",
  "short_name": "Lake Effect Snow Warn",
  "priority": 7,
  "high_priority": true,
  "show_on_map": true,
  "icon": "fas fa-snowflake",
  "colors": {
    "primary": "#4169E1",
    "css_var": "#4169E1",
    "state_map": "#4169E1",
    "daily_recap": "#4169E1"
  },
  "map_style": {
    "color": "#4169E1",
    "weight": 3,
    "fillOpacity": 0.5
  }
}
```

---

## Troubleshooting

### Alert Not Appearing

1. **Check phenomenon_code**: Must match exactly what NWS sends
2. **Verify nws_event_name**: Must match NWS alert event name exactly
3. **Check priority**: Make sure it's not too low (higher number = lower priority)
4. **Restart required**: Did you restart the backend server?

### Wrong Colors

- Check all 4 color fields in the `colors` object
- Use hex format: `#RRGGBB`
- Clear browser cache after changes

### Map Not Showing

- Set `show_on_map: true`
- Check that `map_style` values are valid
- Verify polygon data exists for your alert zones

---

## Files Modified (For Reference)

If you're curious what files were changed to enable this system:

### Backend (Python)
- `alert_types_config.json` - **Main configuration file (edit this!)**
- `alert_config_loader.py` - Loads config from JSON
- `constants.py` - Now imports from config loader
- `alert_parser.py` - Uses config for SPS filtering
- `main_app.py` - Serves config via API endpoint

### Frontend (JavaScript)
- `alert-config.js` - Fetches and caches config from API
- `index.html` - Includes alert-config.js
- Other JS files use the global `alertConfig` object

---

## Backup & Restore

### Backup Location

A complete backup was created at:
```
backups/alert_config_migration/
```

### To Restore Previous Version

If something goes wrong, run:
```
backups\alert_config_migration\RESTORE_BACKUP.bat
```

This will restore all files to their state before the migration.

---

## Support

If you encounter issues:

1. Check the browser console for errors (F12 → Console tab)
2. Check the Python server logs
3. Verify JSON syntax in `alert_types_config.json` (use a JSON validator)
4. Consult this guide

---

## What Changed?

### Before (Old System)
- Alert types hardcoded in **9+ files**
- **25+ locations** needed updates for new alerts
- Required code changes and testing
- Easy to miss a location

### After (New System)
- Alert types in **1 JSON file**
- Edit config, restart server
- Zero code changes needed
- Impossible to miss a location

🎉 **Adding Lake Effect Snow Warning is now as simple as editing one JSON file!**
