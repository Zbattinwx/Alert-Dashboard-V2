document.addEventListener('DOMContentLoaded', () => {
    // --- MAP INITIALIZATION ---
    const map = L.map('map', {
        zoomControl: false,
        attributionControl: false,
    }).setView([40.4, -82.9], 7.5);

    map.dragging.disable();
    map.touchZoom.disable();
    map.doubleClickZoom.disable();
    map.scrollWheelZoom.disable();
    map.boxZoom.disable();
    map.keyboard.disable();

    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_nolabels/{z}/{x}/{y}{r}.png').addTo(map);

    const fipsToLayerMap = {};
    let countyGeoJsonLayer;
    let legendControl; // --- NEW: Variable to hold our legend ---
    earthquakeLayer = L.layerGroup().addTo(map); // Layer group for earthquake markers and range rings

    // --- REFERENCE POINTS ---
    const majorCities = [
        { name: 'Columbus', coords: [40.03, -82.99] },
        { name: 'Cleveland', coords: [41.55, -81.69] },
        { name: 'Cincinnati', coords: [39.10, -84.51] },
        { name: 'Toledo', coords: [41.7, -83.53] },
        { name: 'Akron', coords: [41.12, -81.51] },
        { name: 'Dayton', coords: [39.8, -84.19] }
    ];

    majorCities.forEach(city => {
        const labelIcon = L.divIcon({ className: 'city-label', html: `<span>${city.name}</span>`, iconAnchor: [city.name.length * 4.5, 8] });
        L.marker(city.coords, { icon: labelIcon, pane: 'shadowPane' }).addTo(map);
    });
    
    const defaultStyle = {
        color: '#414868', weight: 1, opacity: 0.8,
        fillColor: '#c0c5d5', fillOpacity: 0.05
    };

    const threatColors = {
        "TO": "#e53e3e",      // Tornado Warning - Red
        "FF": "#38a169",      // Flash Flood Warning - Green
        "SV": "#dd6b20",      // Severe Thunderstorm Warning - Orange
        "SVR": "#dd6b20",     // Severe Thunderstorm Warning (alt) - Orange
        "SS": "#9b2c2c",      // Storm Surge Warning - Dark Red
        "TOA": "#faf089",     // Tornado Watch - Light Yellow
        "SVA": "#DB7093",     // Severe Thunderstorm Watch - Gold
        "FFA": "#48bb78",     // Flash Flood Watch - Light Green
        "WSW": "#FF69B4",     // Winter Storm Warning - Magenta/Pink
        "WSA": "#4682B4",     // Winter Storm Watch - Purple
        "SQW": "#C71585",     // Snow Squall Warning - Hot Pink
        "WW": "#7B68EE",      // Winter Weather Advisory - Light Purple
        "SPS": "#4299e1"      // Special Weather Statement - Blue
    };

    // --- Master list of all possible legend items ---
    const legendInfo = {
        "TO": { color: threatColors.TO, name: "Tornado Warning" },
        "FF": { color: threatColors.FF, name: "Flash Flood Warning" },
        "SV": { color: threatColors.SV, name: "Svr. T-Storm Warning" },
        "SVR": { color: threatColors.SVR, name: "Svr. T-Storm Warning" },
        "SS": { color: threatColors.SS, name: "Storm Surge Warning" },
        "TOA": { color: threatColors.TOA, name: "Tornado Watch" },
        "SVA": { color: threatColors.SVA, name: "Svr. T-Storm Watch" },
        "FFA": { color: threatColors.FFA, name: "Flash Flood Watch" },
        "WSW": { color: threatColors.WSW, name: "Winter Storm Warning" },
        "WSA": { color: threatColors.WSA, name: "Winter Storm Watch" },
        "SQW": { color: threatColors.SQW, name: "Snow Squall Warning" },
        "WW": { color: threatColors.WW, name: "Winter Weather Advisory" },
        "SPS": { color: threatColors.SPS, name: "Special Wx Statement" }
    };

    function updateMapColors(summary) {
        if (!countyGeoJsonLayer) return;

        for (const fips in fipsToLayerMap) {
            fipsToLayerMap[fips].setStyle(defaultStyle);
        }

        for (const fips in summary) {
            const layer = fipsToLayerMap[fips];
            if (layer) {
                const phenomenon = summary[fips];
                const color = threatColors[phenomenon] || '#718096';
                layer.setStyle({ fillColor: color, fillOpacity: 0.6, color: color, weight: 1.5 });
            }
        }
    }

    // --- NEW: Function to create and update the legend ---
    function setupLegend() {
        legendControl = L.control({ position: 'bottomright' });

        legendControl.onAdd = function (map) {
            this._div = L.DomUtil.create('div', 'legend');
            this.update({}); // Initialize with no active alerts
            return this._div;
        };

        // This method updates the legend's content
        legendControl.update = function (summary) {
            const activePhenomena = new Set(Object.values(summary));
            let legendHTML = '<h4>Active Threats</h4>';
            let itemsAdded = 0;

            for (const key in legendInfo) {
                if (activePhenomena.has(key)) {
                    const info = legendInfo[key];
                    legendHTML += `<i style="background:${info.color}"></i> ${info.name}<br>`;
                    itemsAdded++;
                }
            }

            // Hide legend if no items are active, otherwise show it
            this._div.style.display = itemsAdded > 0 ? 'block' : 'none';
            this._div.innerHTML = legendHTML;
        };

        legendControl.addTo(map);
    }


    // --- DATA HANDLING ---
    fetch('counties.geojson')
        .then(response => response.json())
        .then(data => {
            countyGeoJsonLayer = L.geoJSON(data, {
                style: defaultStyle,
                onEachFeature: (feature, layer) => {
                    const fips = feature.properties.GEOID;
                    if (fips) { fipsToLayerMap[fips] = layer; }
                }
            }).addTo(map);

            setupLegend(); // Create the legend after the base layer is ready
            return fetch('ohio_interstates.geojson');
        })
        .then(response => response.json())
        .then(data => {
            L.geoJSON(data, { style: { color: '#5a7da8', weight: 3, opacity: 0.8 }}).addTo(map);
            const highwayLabels = [
                { num: '70', coords: [39.926343564354646, -83.79443023336442] }, // West of Columbus
                { num: '70', coords: [40.03, -81.8] }, // East of Columbus
                { num: '71', coords: [40.94698972762654, -82.08265734473353] }, // South of Akron
                { num: '71', coords: [39.4, -84.25] }, // North of Cincinnati
                { num: '75', coords: [40.7, -84.1] },  // South of Lima
                { num: '75', coords: [39.55, -84.3] }, // North of Dayton
                { num: '90', coords: [41.75, -81.2] },  // West of Cleveland
                { num: '90', coords: [41.36859807204804, -82.95797270116199] }, // West of Akron (Turnpike)
                { num: '77', coords: [40.54982945637981, -81.50307368612263] }, // South of Canton
            ];
            highwayLabels.forEach(label => {
                const shieldIcon = L.divIcon({ className: 'interstate-shield-label', html: `<span>${label.num}</span>`, iconSize: [32, 28] });
                L.marker(label.coords, { icon: shieldIcon }).addTo(map);
            });
        });

    // --- EARTHQUAKE RENDERING ---
    function getMagnitudeColor(magnitude) {
        // Color scale for earthquake magnitude
        if (magnitude >= 7.0) return '#8b0000'; // Dark red - major
        if (magnitude >= 6.0) return '#ff0000'; // Red - strong
        if (magnitude >= 5.0) return '#ff4500'; // Orange-red - moderate
        if (magnitude >= 4.0) return '#ffa500'; // Orange - light
        if (magnitude >= 3.0) return '#ffff00'; // Yellow - minor
        if (magnitude >= 2.0) return '#90ee90'; // Light green - micro
        return '#add8e6'; // Light blue - very small
    }

    function getMagnitudeRadius(magnitude) {
        // Marker size based on magnitude
        if (magnitude >= 7.0) return 20;
        if (magnitude >= 6.0) return 16;
        if (magnitude >= 5.0) return 12;
        if (magnitude >= 4.0) return 10;
        if (magnitude >= 3.0) return 8;
        if (magnitude >= 2.0) return 6;
        return 5;
    }

    function getFeltRadiusKm(magnitude) {
        // Estimate felt radius in kilometers based on magnitude
        if (magnitude < 2.0) return 10;
        if (magnitude < 3.0) return 30;
        if (magnitude < 4.0) return 70;
        if (magnitude < 5.0) return 150;
        if (magnitude < 6.0) return 300;
        if (magnitude < 7.0) return 600;
        return 1200;
    }

    function formatEarthquakeTime(isoTime) {
        try {
            const date = new Date(isoTime);
            const now = new Date();
            const diffMs = now - date;
            const diffMins = Math.floor(diffMs / 60000);
            const diffHours = Math.floor(diffMins / 60);
            const diffDays = Math.floor(diffHours / 24);

            if (diffMins < 60) {
                return `${diffMins} min${diffMins !== 1 ? 's' : ''} ago`;
            } else if (diffHours < 24) {
                return `${diffHours} hr${diffHours !== 1 ? 's' : ''} ago`;
            } else {
                return `${diffDays} day${diffDays !== 1 ? 's' : ''} ago`;
            }
        } catch (e) {
            return 'Unknown time';
        }
    }

    function updateEarthquakes(earthquakeData) {
        // Clear existing earthquake markers
        earthquakeLayer.clearLayers();

        if (!earthquakeData || !earthquakeData.earthquakes) {
            return;
        }

        const earthquakes = earthquakeData.earthquakes;
        console.log(`Rendering ${earthquakes.length} earthquakes on map`);

        earthquakes.forEach(eq => {
            const lat = eq.latitude;
            const lng = eq.longitude;
            const mag = eq.magnitude;
            const place = eq.place;
            const depth = eq.depth_km;
            const timeAgo = formatEarthquakeTime(eq.time);

            // Get colors and sizes
            const color = getMagnitudeColor(mag);
            const radius = getMagnitudeRadius(mag);
            const feltRadiusKm = getFeltRadiusKm(mag);

            // Convert km to meters for Leaflet circle
            const feltRadiusMeters = feltRadiusKm * 1000;

            // Draw felt range ring (semi-transparent)
            const rangeRing = L.circle([lat, lng], {
                radius: feltRadiusMeters,
                color: color,
                weight: 1,
                opacity: 0.3,
                fillColor: color,
                fillOpacity: 0.05
            });
            rangeRing.addTo(earthquakeLayer);

            // Draw epicenter marker
            const epicenterMarker = L.circleMarker([lat, lng], {
                radius: radius,
                fillColor: color,
                color: '#fff',
                weight: 2,
                opacity: 1,
                fillOpacity: 0.8
            });

            // Create popup with earthquake info
            const popupContent = `
                <div style="min-width: 200px; background-color:grey;">
                    <h4 style="margin: 0 0 8px 0; color: ${color};">
                        <i class="fas fa-mountain"></i> M${mag.toFixed(1)} Earthquake
                    </h4>
                    <p style="margin: 4px 0;"><strong>Location:</strong> ${place}</p>
                    <p style="margin: 4px 0;"><strong>Depth:</strong> ${depth.toFixed(1)} km</p>
                    <p style="margin: 4px 0;"><strong>Time:</strong> ${timeAgo}</p>
                    ${eq.felt ? `<p style="margin: 4px 0;"><strong>Felt Reports:</strong> ${eq.felt}</p>` : ''}
                    ${eq.tsunami ? '<p style="margin: 4px 0; color: #ff0000;"><strong>⚠️ TSUNAMI WARNING</strong></p>' : ''}
                    ${eq.alert ? `<p style="margin: 4px 0;"><strong>Alert Level:</strong> <span style="text-transform: uppercase; color: ${getAlertColor(eq.alert)};">${eq.alert}</span></p>` : ''}
                    <p style="margin: 8px 0 0 0; font-size: 0.85em;">
                        <a href="${eq.url}" target="_blank">More details →</a>
                    </p>
                </div>
            `;

            epicenterMarker.bindPopup(popupContent);
            epicenterMarker.addTo(earthquakeLayer);

            // Add magnitude label for significant earthquakes
            if (mag >= 4.0) {
                const label = L.divIcon({
                    className: 'earthquake-label',
                    html: `<span style="color: ${color}; font-weight: bold; text-shadow: 1px 1px 2px black;">M${mag.toFixed(1)}</span>`,
                    iconSize: [40, 20]
                });
                L.marker([lat, lng], { icon: label }).addTo(earthquakeLayer);
            }
        });
    }

    function getAlertColor(alertLevel) {
        const colors = {
            'green': '#38a169',
            'yellow': '#d69e2e',
            'orange': '#dd6b20',
            'red': '#e53e3e'
        };
        return colors[alertLevel] || '#718096';
    }

    // --- WEBSOCKET CONNECTION ---
    function connect() {
        const socket = new WebSocket(CONFIG.websocket_url);
        socket.onopen = () => console.log("State Map connected to WebSocket.");
        socket.onclose = () => setTimeout(connect, 5000);
        socket.onmessage = (event) => {
            const data = JSON.parse(event.data);
            if (data.type === 'update' && data.statewide_summary) {
                updateMapColors(data.statewide_summary);
                // --- NEW: Update the legend whenever we get new data ---
                if (legendControl) {
                    legendControl.update(data.statewide_summary);
                }
                // --- Update earthquakes if data is present ---
                if (data.earthquakes) {
                    updateEarthquakes(data.earthquakes);
                }
            }
        };
    }

    connect();
});