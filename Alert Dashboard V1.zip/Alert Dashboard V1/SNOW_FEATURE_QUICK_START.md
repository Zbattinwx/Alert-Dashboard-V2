# Snow Visualization Quick Start Guide

## What's New?

Snow reports from your local storm report system now display with **snowflake icons** instead of megaphones, and you can visualize snow accumulation patterns with an interactive heatmap!

## How to Use

### Viewing Snow Reports (Default Mode)

1. Navigate to **Local Storm Reports** in the dashboard
2. Snow reports will appear as **purple snowflake icons** (❄️)
3. Each icon shows the reported **snow amount** below it (e.g., "3.5in")
4. Click any icon to see full report details

### Switching to Snow Totals Heatmap

1. Look for the **"Snow Totals"** button in the top-right corner of the map
2. Click it to switch to heatmap mode
3. Snow reports will now appear as:
   - **Colored circles** (purple shades) sized by accumulation
   - **Numeric labels** showing exact amounts in inches
4. **Color guide:**
   - Light purple = Less snow (1-2")
   - Medium purple = Moderate snow (4-6")
   - Dark purple = Heavy snow (8-12")
   - Very dark purple = Extreme snow (12"+)

### Switching Back to Icons

1. The button now reads **"Snow Icons"** and is highlighted in purple
2. Click it to return to the regular snowflake icon view

## Tips

- **Heatmap mode is great for:** Identifying snow bands, lake effect patterns, and accumulation gradients
- **Icon mode is great for:** Precise locations and quick magnitude reference
- **Both modes:** Clicking on markers/circles shows the full report with time, location, and remarks
- **Layer control:** You can still toggle snow reports on/off using the map's layer control

## When to Use Each Mode

| Use **Icon Mode** When: | Use **Heatmap Mode** When: |
|------------------------|----------------------------|
| You need precise locations | You want to see overall patterns |
| Reading individual reports | Comparing accumulation zones |
| Checking specific amounts | Identifying snow bands |
| Working with sparse data | Analyzing widespread events |

## Troubleshooting

**Q: I don't see the Snow Totals button**
- Make sure you're on the Local Storm Reports page
- Refresh the page if needed

**Q: The heatmap shows no circles**
- This means there are no snow reports with magnitude data
- Try switching back to icon mode to see if any snow reports exist

**Q: Snow reports still show megaphone icons**
- Clear your browser cache and refresh (Ctrl+F5 or Cmd+Shift+R)
- Make sure dashboard.js and dashboard.css were properly updated

## Example Scenarios

### During a Lake Effect Event
1. Use **Heatmap Mode** to see the snow band structure
2. Notice how circles get larger and darker near Lake Erie
3. Click individual circles to see exact measurements and timing

### After a Snowstorm
1. Use **Icon Mode** to get precise totals from each location
2. Toggle layers to compare snow reports with warning polygons
3. Export or screenshot for storm summary reports

---

**Enjoy the enhanced snow visualization! ❄️**
