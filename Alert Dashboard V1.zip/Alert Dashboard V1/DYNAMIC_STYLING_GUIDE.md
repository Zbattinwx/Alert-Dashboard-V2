# Dynamic Alert Styling System

## Overview

Your alert system now uses **100% dynamic styling** based on `alert_types_config.json`. You will **NEVER** need to manually update CSS files when adding new alert types!

---

## How It Works

### The Old Way (DEPRECATED) ❌

When you wanted to add a new alert type, you had to:
1. Edit `alert_types_config.json`
2. Manually add CSS rules to `dashboard.css`
3. Manually add CSS rules to `ticker.css`
4. Manually add CSS rules to `ticker-sponsored.css`
5. Manually add CSS rules to `theme-atmospheric.css`
6. Manually add CSS rules to `theme-storm-chaser.css`
7. Manually add CSS rules to `theme-meteorologist.css`
8. Manually add CSS rules to `theme-winter.css`
9. Manually add CSS rules to ALL ticker theme files
10. Hope you didn't miss any files or typo any color codes

**Total: 10+ files to edit manually**

### The New Way (CURRENT) ✅

When you want to add a new alert type:
1. Edit `alert_types_config.json`
2. Restart your Python backend

**That's it!** The colors are automatically applied everywhere.

---

## The Magic Behind It

### [dynamic-alert-styles.js](dynamic-alert-styles.js)

This new JavaScript file:
- Loads after `alert-config.js` has fetched the configuration
- Reads all alert types from the config
- Dynamically generates CSS rules for:
  - Dashboard alert card borders (all themes)
  - Ticker backgrounds (all themes)
  - Dashboard theme-specific styles (Storm Chaser, Atmospheric, etc.)
  - Ticker theme-specific styles (Atmospheric, Classic, etc.)
- Injects the generated CSS into the page
- Automatically creates color gradients for themes that need them

### Load Order

```
1. frontend_config.js      (basic config)
2. alert-config.js          (loads alert types from server)
3. dynamic-alert-styles.js  (generates CSS from alert types)
4. [other scripts]
```

This order is critical - the dynamic styles must load **after** the alert config is available.

---

## Example: Adding a New Alert Type

### Step 1: Edit alert_types_config.json

Add your new alert type to the `alert_types` array:

```json
{
  "phenomenon_code": "DS",
  "nws_event_name": "Dust Storm Warning",
  "display_name": "Dust Storm Warning",
  "short_name": "Dust Storm Warning",
  "priority": 6,
  "high_priority": true,
  "show_on_map": true,
  "show_on_dashboard": true,
  "show_on_ticker": true,
  "icon": "fas fa-smog",
  "colors": {
    "primary": "#D2691E",
    "css_var": "#D2691E",
    "state_map": "#D2691E",
    "daily_recap": "#D2691E"
  },
  "map_style": {
    "color": "#D2691E",
    "weight": 3,
    "fillOpacity": 0.5
  }
}
```

### Step 2: Restart Backend

```bash
# Stop your Python app (Ctrl+C)
# Start it again
python main_app.py
```

### Step 3: Hard Refresh Browser

Press `Ctrl+Shift+R` or `Ctrl+F5`

### Result

The new "DS" alert type will automatically have:
- ✅ Dashboard alert cards with chocolate brown borders (#D2691E)
- ✅ Ticker with chocolate brown background
- ✅ Proper colors in ALL themes (Storm Chaser, Atmospheric, Meteorologist, Winter, Classic)
- ✅ Gradients automatically generated for themes that use them
- ✅ Counter tracking
- ✅ Map polygon styling
- ✅ Everything else configured in the JSON

**No CSS editing required!**

---

## Supported Themes

The dynamic styling system automatically applies colors to:

### Dashboard Themes
- Classic (base dashboard.css)
- Storm Chaser
- Atmospheric
- Meteorologist
- Winter

### Ticker Themes
- Classic
- Atmospheric
- Storm Chaser
- Meteorologist
- Winter

All themes automatically receive:
- Solid colors or gradients (depending on theme style)
- Proper contrast
- Theme-appropriate effects

---

## Technical Details

### CSS Generation

For each alert type, the system generates CSS like this:

```css
/* Dashboard alert card border */
.alert-card.ds { border-color: #D2691E !important; }

/* Base ticker background */
.ticker-container.DS { background-color: #D2691E !important; }

/* Storm Chaser dashboard theme ::before bar */
.theme-storm-chaser .alert-card.ds::before { background: #D2691E !important; }

/* Atmospheric dashboard theme ::before bar with gradient */
.theme-atmospheric .alert-card.ds::before {
  background: linear-gradient(135deg, #D2691E 0%, #A0521A 100%) !important;
}

/* Atmospheric ticker with gradient */
body.ticker-theme-atmospheric .ticker-container.DS {
  background: linear-gradient(135deg, #D2691E 0%, #A0521A 100%) !important;
}

/* ...and so on for all themes */
```

### Gradient Generation

For themes that use gradients (Atmospheric, Winter), the system:
1. Takes the primary color from the config
2. Darkens it by 20% for the gradient end
3. Creates a 135-degree diagonal gradient
4. Applies it to the appropriate theme selectors

### Browser Compatibility

The dynamic styling uses:
- `document.createElement('style')` - Supported in all modern browsers
- CSS custom properties (`!important` overrides) - IE11+
- Linear gradients - All modern browsers

---

## Troubleshooting

### Alert colors not showing up

1. **Check browser console** - Look for:
   ```
   ✅ Applied dynamic styles for 16 alert types
   ```

2. **Verify alert-config.js loaded** - Look for:
   ```
   ✅ Global alert configuration variables initialized
   ```

3. **Hard refresh** - Press Ctrl+Shift+R

4. **Check load order** - In browser DevTools → Network tab, verify:
   - alert-config.js loads before dynamic-alert-styles.js
   - Both load before dashboard.js/ticker.js

### New alert shows default/wrong color

1. **Check the config file** - Verify `colors.primary` is set correctly
2. **Restart backend** - Config is loaded on server startup
3. **Clear browser cache** - Old cached files might interfere

### Gradient looks wrong

The system darkens the primary color by 20% for gradients. If you want a specific gradient:
- Currently not supported - all gradients are auto-generated
- Future enhancement: Add `gradient_end` color to config

---

## Files in the System

### Core Files (DO NOT DELETE)
- `alert_types_config.json` - Master configuration
- `alert_config_loader.py` - Python loader
- `alert-config.js` - JavaScript loader
- `dynamic-alert-styles.js` - **NEW** - Dynamic CSS generator

### Theme Files (NO LONGER NEED MANUAL EDITING)
- `dashboard.css` - Base styles (keeps base CSS variables for fallback)
- `theme-*.css` - Theme stylesheets (keep base structure, colors override dynamically)
- `ticker.css` - Base ticker styles (keeps base styles for fallback)
- `ticker-sponsored.css` - Sponsored ticker (keeps base styles for fallback)
- `theme-*-ticker.css` - Ticker themes (keep base structure, colors override dynamically)

---

## Migration Notes

### What Changed (November 26, 2025)

**Before:**
- Alert colors hardcoded in 10+ CSS files
- Adding an alert required editing all theme files
- Easy to miss files or make typos
- Inconsistent colors across themes

**After:**
- Alert colors in 1 JSON file
- Adding an alert only requires editing JSON + restart
- Impossible to miss a theme
- Consistent colors across all themes
- Automatic gradient generation

**Backward Compatibility:**
- All existing theme CSS files still work
- Dynamic styles use `!important` to override hardcoded values
- Can safely remove hardcoded alert color rules from CSS files later

---

## Future Enhancements

Possible improvements to the dynamic styling system:

1. **Custom Gradients** - Add `colors.gradient_end` to config for precise gradient control
2. **Theme-Specific Colors** - Different colors per theme if needed
3. **Animation Support** - Configure pulse/glow effects per alert type
4. **Accessibility Mode** - High contrast colors for accessibility
5. **Dark Mode Override** - Different colors for dark mode themes

---

## Summary

✅ **One config file to rule them all**
✅ **Zero manual CSS editing**
✅ **All themes automatically updated**
✅ **Gradients automatically generated**
✅ **Add new alerts in seconds**

**You will never need to touch a theme CSS file again when adding alerts!**

---

**Created:** November 26, 2025
**Feature:** Dynamic alert styling from config
**Impact:** 10+ files → 1 file for alert management
