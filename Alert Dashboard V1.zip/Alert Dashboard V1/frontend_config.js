// frontend_config.js

const CONFIG = {
    // Use your public DDNS address here
    //websocket_url: "wss://atmosphericx.ddns.net:8765",
    websocket_url: "ws://localhost:8765",
    odot_api_key:"775df0cb-3d4c-4c66-953c-9e3c8a8ed27c",
    "enable_obs_integration": false,
    "winter_mode_enabled": true,

};