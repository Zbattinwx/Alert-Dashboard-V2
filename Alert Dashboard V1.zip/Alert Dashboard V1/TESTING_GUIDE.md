# 🧪 WeatherWise Alert Testing System

## Overview

The WeatherWise Alert Testing System allows you to inject realistic test alerts into your dashboard without waiting for actual severe weather. This is essential for:

- **Testing alert parsing** for different phenomenon types
- **Verifying map rendering** (polygons, zones, counties)
- **Checking frontend display** (tickers, cards, notifications)
- **Validating data flow** from both Weather Wire (NWWS) and API sources
- **Training and demonstrations**

---

## Quick Start

### 1. Start Your Application

```bash
python main_app.py
```

### 2. Open the Test Panel

Navigate to: **http://localhost:8080/test_panel.html**

### 3. Inject a Test Alert

Click any alert card to inject it into your system. The alert will:
- ✅ Be parsed as if it came from the real source (NWWS or API)
- ✅ Appear on your dashboard and maps
- ✅ Be marked with a `TEST.` prefix in the product ID
- ✅ Follow the same processing pipeline as real alerts

### 4. Clear Test Alerts

Click **"Clear All Test Alerts"** to remove all test alerts from the system.

---

## Test Alert Library

Your `test_alerts.json` file contains the following test scenarios:

### Tornado Warnings (TO)

| Alert Name | Source | Features Tested |
|------------|--------|----------------|
| **Tornado Warning (Text/NWWS)** | NWWS | Basic polygon extraction, VTEC parsing, text format |
| **Tornado Warning - OBSERVED (Text/NWWS)** | NWWS | OBSERVED tag, CATASTROPHIC damage threat, multi-county |
| **Tornado Warning (API/JSON)** | API | API polygon format, JSON parsing, office extraction |

### Severe Thunderstorm Warnings (SV)

| Alert Name | Source | Features Tested |
|------------|--------|----------------|
| **Severe Thunderstorm Warning (Text/NWWS)** | NWWS | Wind/hail parsing, storm motion, LAT...LON polygon |

### Flash Flood Warnings (FF)

| Alert Name | Source | Features Tested |
|------------|--------|----------------|
| **Flash Flood Warning (Text/NWWS)** | NWWS | Flood-specific parsing, multi-county coverage |

### Winter Weather (WW, WSW)

| Alert Name | Source | Features Tested |
|------------|--------|----------------|
| **Winter Weather Advisory (Text/NWWS)** | NWWS | Zone-based alerts, zone geometry fetching, text parsing |
| **Winter Weather Advisory (API/JSON)** | API | Zone-based API alerts, zone geometry from API |

### Special Weather Statements (SPS)

| Alert Name | Source | Features Tested |
|------------|--------|----------------|
| **Special Weather Statement (Text/NWWS)** | NWWS | Multi-zone coverage, expiration time parsing |

### Watches (TOA, SVA)

| Alert Name | Source | Features Tested |
|------------|--------|----------------|
| **Tornado Watch (Text/NWWS)** | NWWS | Watch format, multi-county coverage, county-based rendering |

### Cancellations

| Alert Name | Source | Features Tested |
|------------|--------|----------------|
| **Severe Thunderstorm Warning Cancellation** | NWWS | CAN/EXP action, alert removal from active list |

---

## How It Works

### Architecture

```
┌─────────────────┐
│  Test Panel UI  │
│  (Browser)      │
└────────┬────────┘
         │ WebSocket
         ↓
┌─────────────────────────────────────────┐
│   main_app.py Test Endpoint             │
│   ├→ update_test_alert_timestamps()     │
│   │  (Updates VTEC, UGC times to NOW)   │
│   └→ update_test_alert_json_timestamps()│
└────────┬────────────────────────────────┘
         │
         ├→ NWWS Path: handle_incoming_alert(text)
         │   ├→ alert_parser.py (text parsing)
         │   ├→ populate_fips_codes_from_ugc()
         │   ├→ fetch_zone_geometry() [if needed]
         │   └→ Add to active_alerts
         │
         └→ API Path: parse_alert(json)
             ├→ alert_parser.py (JSON parsing)
             ├→ populate_fips_codes_from_ugc()
             ├→ fetch_zone_geometry() [if needed]
             └→ Add to active_alerts
```

### Timestamp Handling

**Important:** Test alerts in `test_alerts.json` have old dates (April 2025) which would normally be rejected as "expired." The test system automatically updates these timestamps:

- **VTEC strings** (`/O.NEW.KILN.TO.W.0042.YYMMDDTHHMMZ-YYMMDDTHHMMZ/`) → Updated to current time
- **UGC expiration** (`OHC049-DDHHMM-`) → Updated to 1 hour from now
- **API timestamps** (`sent`, `expires`, `effective`) → Updated to current time/+1 hour

This ensures test alerts pass the expiration check and appear on your dashboard!

### WebSocket Commands

#### Inject Test Alert
```json
{
  "type": "inject_test_alert",
  "source": "nwws",  // or "api"
  "alert_data": "..."  // String for NWWS, Object for API
}
```

#### Clear Test Alerts
```json
{
  "type": "clear_test_alerts"
}
```

---

## Testing Checklist

Use this checklist to verify your system is working correctly:

### Alert Parsing ✓

- [ ] **Text format** alerts parse correctly (VTEC, UGC, polygon)
- [ ] **XML/CAP format** alerts parse correctly (tags, geometry)
- [ ] **API JSON format** alerts parse correctly (properties, geocode)
- [ ] **FIPS codes** are extracted and formatted as 5-digit
- [ ] **UGC codes** are extracted from all formats
- [ ] **Storm motion** is extracted and converted to direction/speed
- [ ] **Threat tags** (OBSERVED, CATASTROPHIC, etc.) are detected
- [ ] **Expiration times** are parsed with correct timezone

### Map Rendering ✓

- [ ] **Polygon-based warnings** (TO, SV, FF) draw precise storm polygons
- [ ] **Zone-based advisories** (WW, SPS) fetch and draw zone boundaries
- [ ] **County-based watches** (TOA, SVA) color entire counties
- [ ] **State map** colors counties correctly based on FIPS codes
- [ ] **Multiple alerts** in same county show highest priority color
- [ ] **Storm motion arrows** display on polygons (if applicable)

### Frontend Display ✓

- [ ] **Dashboard** shows alert cards with correct phenomenon icons
- [ ] **Ticker** scrolls through active alerts
- [ ] **Legend** shows only active alert types
- [ ] **Alert expiration** removes alerts automatically after expiry
- [ ] **Cancellations** immediately remove alerts from display

### Data Flow ✓

- [ ] **NWWS source** alerts process through text parser
- [ ] **API source** alerts process through JSON parser
- [ ] **Zone geometry** fetches from NWS API when needed
- [ ] **FIPS population** converts UGC codes to county FIPS
- [ ] **Broadcast** sends updates to all connected clients

---

## Advanced Testing

### Create Custom Test Alerts

You can add your own test alerts to `test_alerts.json`:

```json
{
  "my_custom_alert": {
    "name": "Custom Tornado Warning",
    "type": "text",
    "phenomenon": "TO",
    "source": "nwws",
    "content": "YOUR RAW NWS TEXT PRODUCT HERE..."
  }
}
```

**Tips:**
- Copy real alert text from [Iowa Environmental Mesonet](https://mesonet.agron.iastate.edu/wx/afos/list.phtml)
- Use your own state/county UGC codes
- Adjust coordinates to match your coverage area
- Set expiration times in the future for testing

### Test via Python Console

You can also inject alerts programmatically:

```python
import asyncio
import json
import websockets

async def inject_test():
    uri = "ws://localhost:8765"
    async with websockets.connect(uri) as websocket:
        # Load test alert
        with open('test_alerts.json', 'r') as f:
            alerts = json.load(f)

        # Inject tornado warning
        message = {
            "type": "inject_test_alert",
            "source": alerts["tornado_warning_text"]["source"],
            "alert_data": alerts["tornado_warning_text"]["content"]
        }
        await websocket.send(json.dumps(message))
        print("✅ Test alert injected!")

asyncio.run(inject_test())
```

---

## Troubleshooting

### Test Alert Not Appearing

**Check:**
1. Is the test panel connected? (Green "Connected" status)
2. Are you viewing the correct dashboard page?
3. Check the Python console - look for:
   - `🧪 TEST ALERT INJECTION RECEIVED` (confirms injection started)
   - `🧪 Updating NWWS/API alert timestamps to current time...` (confirms timestamp update)
   - `✅ TEST NWWS/API alert processed` (confirms completion)
   - `Expires: <timestamp>` (should be ~1 hour in future)
   - **NOT** `Ignoring stale, already-expired product` (means timestamps weren't updated)
4. Check the test panel console log for errors
5. Verify the alert phenomenon is in `TARGET_PHENOMENA` in main_app.py (line 85)
6. If you see "Ignoring stale, already-expired product":
   - The timestamp update may have failed
   - Check that `update_test_alert_timestamps()` is being called
   - Verify VTEC regex patterns match your alert format

### Zone Geometry Not Loading

**Check:**
1. Internet connection (zone geometry fetches from NWS API)
2. UGC code exists in `ugc_database.txt`
3. NWS API is accessible: `https://api.weather.gov/zones/forecast/OHZ026`
4. Check Python console for "Fetched zone geometry" messages

### FIPS Codes Not Populating

**Check:**
1. `ugc_to_fips.json` file exists (run `python build_ugc_map.py`)
2. UGC codes are in the correct format (e.g., `OHC049`, `OHZ026`)
3. Check Python console for "Populated X FIPS codes" messages

### Polygon Not Rendering

**Check:**
1. Alert has either `polygon` field or zone codes
2. Polygon coordinates are in `[lat, lon]` format (not `[lon, lat]`)
3. Polygon is stored as array of arrays: `[[coords], [coords]]`
4. dashboard.js `updateMapPolygons()` function is being called

---

## Best Practices

### 1. Always Clear Test Alerts After Testing
Test alerts are marked with `TEST.` prefix but stay in the system until cleared or expired. Always click "Clear All Test Alerts" when done.

### 2. Test One Alert Type at a Time
This makes it easier to identify issues with specific phenomenon types.

### 3. Test Both Sources (NWWS and API)
Ensure your parser handles both text and JSON formats correctly.

### 4. Verify All Data Fields
Don't just check if the alert appears - verify:
- Correct location/county names
- Accurate polygon/zone boundaries
- Proper threat tags (wind, hail, etc.)
- Correct expiration time

### 5. Test on Multiple Browsers
Different browsers may render maps differently. Test on Chrome, Firefox, and Edge.

---

## Production Considerations

### Disabling Test Mode

The test injection endpoint is always available. If you want to disable it for production:

1. **Add authentication** to the test panel
2. **Remove the test endpoint** from `client_handler()` in main_app.py
3. **Firewall the test panel** (don't expose test_panel.html publicly)

### Test Alert Identification

All test alerts are marked with `TEST.` prefix in their product_id. You can add visual indicators:

```javascript
// In dashboard.js
if (alert.product_id.startsWith('TEST.')) {
    alertCard.style.border = '3px dashed orange';
    alertCard.innerHTML += '<div class="test-badge">TEST ALERT</div>';
}
```

---

## Support

For issues or questions:
- Check the Python console for detailed error messages
- Check the browser console (F12) for JavaScript errors
- Review logs in the test panel's console section
- Verify your `test_alerts.json` file is valid JSON

---

## Summary

The WeatherWise Alert Testing System gives you complete control over testing your alert dashboard:

✅ **10+ pre-built test scenarios** covering all major alert types
✅ **Both NWWS and API sources** tested
✅ **Web-based control panel** for easy injection
✅ **Full processing pipeline** - tests parsing, mapping, and rendering
✅ **Easy cleanup** with one-click clear function
✅ **Extensible** - add your own custom test alerts

Use this system regularly to ensure your dashboard is ready for real severe weather events! 🌩️
