import json

INPUT_FILE = "zone_data.txt"
OUTPUT_FILE = "ugc_map.json"

def create_zone_map():
    """
    Reads the raw pipe-delimited zone data and creates a clean
    JSON map where the value includes the state, e.g., "Adams County, OH".
    """
    print(f"Reading data from {INPUT_FILE}...")
    zone_map = {}
    line_number = 0
    
    try:
        with open(INPUT_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                line_number += 1
                parts = [part.strip() for part in line.strip().split('|')]
                
                if len(parts) < 7:
                    continue

                state_abbr = parts[0]
                zone_name = parts[3]
                zone_code = parts[4]
                part5 = parts[5]
                part6 = parts[6]
                
                county_name = ""
                fips_code = ""

                if part5.isdigit() and len(part5) == 5:
                    fips_code = part5
                    county_name = part6
                elif part6.isdigit() and len(part6) == 5:
                    fips_code = part6
                    county_name = part5
                else:
                    county_name = zone_name
                
                if fips_code:
                    ugc_county_code = f"{state_abbr}C{fips_code[-3:]}"
                    # THE FIX: Add the state abbreviation to the value
                    zone_map[ugc_county_code] = f"{county_name} County, {state_abbr}"

                # Also store the Zone UGC code
                zone_map[zone_code] = f"{zone_name}, {state_abbr}"

    except FileNotFoundError:
        print(f"--- FATAL ERROR: {INPUT_FILE} not found! Please create it from the text you provided. ---")
        return

    with open(OUTPUT_FILE, 'w') as f:
        json.dump(zone_map, f, indent=4)
        
    print(f"✅ Success! Generated {OUTPUT_FILE} with {len(zone_map)} entries.")

if __name__ == '__main__':
    create_zone_map()