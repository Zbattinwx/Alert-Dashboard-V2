# build_ugc_map.py
import json

def create_ugc_to_fips_mapping():
    """
    Reads the raw ugc_database.txt and creates a clean JSON file that maps
    UGC codes (both county and zone types) to a list of 5-digit county FIPS codes.
    """
    ugc_map = {}
    
    print("Reading ugc_database.txt...")
    try:
        with open('ugc_database.txt', 'r', encoding='utf-8') as f:
            for line in f:
                parts = line.strip().split('|')
                if len(parts) < 7:
                    continue
                
                state_abbr = parts[0]
                zone_num = parts[1]
                county_fips = parts[6]

                # Create the Zone UGC (e.g., OHZ026)
                zone_ugc = f"{state_abbr}Z{zone_num}"
                # Create the County UGC (e.g., OHC065 from FIPS 39065)
                county_ugc = f"{state_abbr}C{county_fips[2:]}"
                
                # --- Map the Zone UGC to its list of county FIPS ---
                if zone_ugc not in ugc_map:
                    ugc_map[zone_ugc] = []
                # Add FIPS to the zone's list if not already there
                if county_fips not in ugc_map[zone_ugc]:
                    ugc_map[zone_ugc].append(county_fips)

                # --- Map the County UGC directly to its own FIPS in a list ---
                if county_ugc not in ugc_map:
                    ugc_map[county_ugc] = [county_fips]

    except FileNotFoundError:
        print("FATAL: ugc_database.txt not found! Please make sure it's in the same directory.")
        return

    output_filename = 'ugc_to_fips.json'
    print(f"Writing {len(ugc_map)} mappings to {output_filename}...")
    with open(output_filename, 'w', encoding='utf-8') as f:
        json.dump(ugc_map, f, indent=2)
        
    print("Done!")

if __name__ == "__main__":
    create_ugc_to_fips_mapping()