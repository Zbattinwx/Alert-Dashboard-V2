"""
Backfill Daily Stats from IEM Archive CSV
===========================================
This script reads an IEM archive CSV file and backfills daily statistics
for a specific date, tracking all NEW alert issuances.

Usage:
    python backfill_daily_stats.py wwa_202510250000_202510270000.csv 2025-10-26
"""

import csv
import json
import os
from datetime import datetime
from collections import defaultdict
import argparse


def backfill_stats_from_csv(csv_path, target_date):
    """
    Read an IEM CSV and generate daily stats for a specific date.

    Args:
        csv_path: Path to the IEM CSV file
        target_date: Date string in YYYY-MM-DD format

    Returns:
        Dictionary with daily stats
    """
    print(f"[BACKFILL] Backfilling stats for {target_date} from {csv_path}")

    # Track alerts
    alerts_issued = defaultdict(int)
    tracked_product_ids = set()
    tornado_warnings_observed = []
    significant_wind_events = []

    # Read CSV
    with open(csv_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)

        for row in reader:
            # Only process alerts issued on target date with NEW status
            if target_date not in row.get('utc_issue', ''):
                continue

            if row.get('status') != 'NEW':
                continue

            # Extract key fields
            phenomena = row.get('phenomena', '')
            significance = row.get('significance', '')
            wfo = row.get('wfo', '')
            eventid = row.get('eventid', '').zfill(4)

            # Create product_id similar to how the system does it
            # Format: {PHENOM}.{WFO}.{EVENTID}
            product_id = f"{phenomena}.{wfo}.{eventid}"

            # Skip if already tracked
            if product_id in tracked_product_ids:
                continue

            # Count the alert
            tracked_product_ids.add(product_id)
            alerts_issued[phenomena] += 1

            # Check for tornado warnings with observed tag
            if phenomena == 'TO' and significance == 'W':
                tornadotag = row.get('tornadotag', '').strip()
                if 'OBSERVED' in tornadotag.upper():
                    tornado_warnings_observed.append({
                        "product_id": product_id,
                        "location": f"{wfo} County Warning Area",
                        "time": row.get('utc_issue', ''),
                        "issuing_office": wfo
                    })

            # Check for high damage threat tags
            damagetag = row.get('damagetag', '').strip()
            if damagetag in ['CONSIDERABLE', 'CATASTROPHIC']:
                significant_wind_events.append({
                    "location": f"{wfo} County Warning Area",
                    "value": f"{damagetag} DAMAGE THREAT",
                    "time": row.get('utc_issue', ''),
                    "source": "alert",
                    "type": "threat_tag",
                    "product_id": product_id,
                    "phenomenon": phenomena
                })

    # Calculate totals
    total_alerts = sum(alerts_issued.values())

    # Create summary
    summary = {
        "date": target_date,
        "day_of_week": datetime.strptime(target_date, '%Y-%m-%d').strftime('%A'),
        "alerts_issued": dict(alerts_issued),
        "storm_reports": {},  # Not available in CSV
        "notable_events": {
            "tornado_warnings_observed": tornado_warnings_observed,
            "significant_wind_events": significant_wind_events
        },
        "totals": {
            "total_alerts": total_alerts,
            "total_reports": 0,
            "tornado_warnings_observed": len(tornado_warnings_observed),
            "significant_wind_events": len(significant_wind_events)
        }
    }

    print(f"\n[SUCCESS] Backfill complete:")
    print(f"   Total alerts: {total_alerts}")
    print(f"   Breakdown:")
    for phenom, count in sorted(alerts_issued.items(), key=lambda x: x[1], reverse=True):
        print(f"     {phenom}: {count}")

    return summary


def save_summary(summary, output_dir="daily_summaries/daily"):
    """Save the summary to JSON and text files."""
    os.makedirs(output_dir, exist_ok=True)

    date = summary['date']
    json_path = os.path.join(output_dir, f"summary_{date}.json")

    # Save JSON
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(summary, f, indent=2)

    print(f"\n[SAVED] JSON summary: {json_path}")

    # Save text version
    text_path = os.path.join(output_dir, f"summary_{date}.txt")
    with open(text_path, 'w', encoding='utf-8') as f:
        f.write(format_summary_text(summary))

    print(f"[SAVED] Text summary: {text_path}")


def format_summary_text(summary):
    """Format summary as human-readable text."""
    lines = []
    lines.append("=" * 80)
    lines.append(f"DAILY WEATHER SUMMARY - {summary['date']} ({summary['day_of_week']})")
    lines.append("(Backfilled from IEM Archive)")
    lines.append("=" * 80)
    lines.append("")

    # Alerts Issued
    lines.append("ALERTS ISSUED (First Issuance Only):")
    alerts = summary['alerts_issued']
    if alerts:
        alert_names = {
            'TO': 'Tornado Warnings',
            'SV': 'Severe Thunderstorm Warnings',
            'FF': 'Flash Flood Warnings',
            'MA': 'Marine Warnings',
            'FA': 'Areal Flood Warnings',
            'SPS': 'Special Weather Statements',
            'TOA': 'Tornado Watches',
            'SVA': 'Severe Thunderstorm Watches',
            'WSW': 'Winter Storm Warnings',
            'WW': 'Winter Weather Advisories',
            'SS': 'Storm Surge Warnings',
            'SQW': 'Snow Squall Warnings'
        }

        for phenom, count in sorted(alerts.items(), key=lambda x: x[1], reverse=True):
            name = alert_names.get(phenom, phenom)
            lines.append(f"  • {name}: {count}")

        lines.append("  " + "─" * 40)
        lines.append(f"  TOTAL ALERTS: {summary['totals']['total_alerts']}")
    else:
        lines.append("  No alerts issued")

    lines.append("")
    lines.append("=" * 80)

    return "\n".join(lines)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Backfill daily stats from IEM archive CSV')
    parser.add_argument('csv_file', help='Path to IEM CSV file')
    parser.add_argument('date', help='Date to backfill (YYYY-MM-DD)')
    parser.add_argument('--output-dir', default='daily_summaries/daily',
                       help='Output directory for summaries (default: daily_summaries/daily)')

    args = parser.parse_args()

    # Backfill stats
    summary = backfill_stats_from_csv(args.csv_file, args.date)

    # Save to files
    save_summary(summary, args.output_dir)

    print("\n[COMPLETE] Backfill complete!")
    print(f"\nThe corrected summary has been saved. Your daily recap will now show accurate stats.")
