# tests/test_constants.py
# ==================================================================================
# UNIT TESTS FOR CONSTANTS MODULE
# ==================================================================================
# Tests that all constants are properly defined and contain expected data.
# ==================================================================================

import unittest
import sys
import os

# Add parent directory to path so we can import our modules
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from constants import (
    NWS_EVENT_TO_PHENOMENON,
    TARGET_PHENOMENA,
    HIGH_PRIORITY_ALERTS,
    WFO_TIMEZONES,
    STATE_FIPS_MAP,
    TIMEZONE_MAP,
    ALERT_PRIORITY,
    TARGET_AFD_OFFICES
)
from datetime import timezone, timedelta


class TestConstants(unittest.TestCase):
    """Test suite for constants module."""

    def test_nws_event_to_phenomenon_not_empty(self):
        """Test that NWS_EVENT_TO_PHENOMENON mapping is not empty."""
        self.assertTrue(len(NWS_EVENT_TO_PHENOMENON) > 0)
        self.assertIn("Tornado Warning", NWS_EVENT_TO_PHENOMENON)
        self.assertEqual(NWS_EVENT_TO_PHENOMENON["Tornado Warning"], "TO")

    def test_nws_event_to_phenomenon_coverage(self):
        """Test that all expected alert types are mapped."""
        expected_alerts = [
            "Tornado Warning", "Severe Thunderstorm Warning", "Flash Flood Warning",
            "Special Weather Statement", "Tornado Watch", "Severe Thunderstorm Watch",
            "Winter Storm Warning", "Winter Storm Watch", "Snow Squall Warning"
        ]
        for alert_type in expected_alerts:
            self.assertIn(alert_type, NWS_EVENT_TO_PHENOMENON)

    def test_target_phenomena_is_set(self):
        """Test that TARGET_PHENOMENA is a set and contains expected values."""
        self.assertIsInstance(TARGET_PHENOMENA, set)
        self.assertTrue(len(TARGET_PHENOMENA) > 0)
        self.assertIn("TO", TARGET_PHENOMENA)
        self.assertIn("SV", TARGET_PHENOMENA)
        self.assertIn("FF", TARGET_PHENOMENA)

    def test_high_priority_alerts_subset(self):
        """Test that HIGH_PRIORITY_ALERTS is a subset of TARGET_PHENOMENA."""
        self.assertIsInstance(HIGH_PRIORITY_ALERTS, set)
        self.assertTrue(HIGH_PRIORITY_ALERTS.issubset(TARGET_PHENOMENA))

    def test_wfo_timezones_coverage(self):
        """Test that WFO_TIMEZONES has good coverage of US weather offices."""
        self.assertTrue(len(WFO_TIMEZONES) > 50)  # Should have many offices

        # Test some major offices
        major_offices = ["ILN", "CLE", "IWX", "PBZ", "LOT", "OKX"]
        for office in major_offices:
            self.assertIn(office, WFO_TIMEZONES)

        # Test that timezone values are valid IANA timezone strings
        self.assertIn("America/New_York", WFO_TIMEZONES.values())
        self.assertIn("America/Chicago", WFO_TIMEZONES.values())
        self.assertIn("America/Denver", WFO_TIMEZONES.values())
        self.assertIn("America/Los_Angeles", WFO_TIMEZONES.values())

    def test_state_fips_map_complete(self):
        """Test that STATE_FIPS_MAP contains all 50 states + DC."""
        self.assertEqual(len(STATE_FIPS_MAP), 51)  # 50 states + DC

        # Test some specific mappings
        self.assertEqual(STATE_FIPS_MAP["OH"], "39")
        self.assertEqual(STATE_FIPS_MAP["CA"], "06")
        self.assertEqual(STATE_FIPS_MAP["NY"], "36")
        self.assertEqual(STATE_FIPS_MAP["DC"], "11")

    def test_state_fips_values_are_strings(self):
        """Test that all FIPS codes are 2-digit strings."""
        for state, fips in STATE_FIPS_MAP.items():
            self.assertIsInstance(fips, str)
            self.assertEqual(len(fips), 2)
            self.assertTrue(fips.isdigit())

    def test_timezone_map_contains_common_zones(self):
        """Test that TIMEZONE_MAP contains common US timezone abbreviations."""
        expected_zones = ["EST", "EDT", "CST", "CDT", "MST", "MDT", "PST", "PDT", "UTC"]
        for zone in expected_zones:
            self.assertIn(zone, TIMEZONE_MAP)

        # Test that values are timezone objects
        for tz_name, tz_obj in TIMEZONE_MAP.items():
            self.assertIsInstance(tz_obj, timezone)

    def test_timezone_map_offsets_correct(self):
        """Test that timezone offsets are correct."""
        self.assertEqual(TIMEZONE_MAP["EST"], timezone(timedelta(hours=-5)))
        self.assertEqual(TIMEZONE_MAP["EDT"], timezone(timedelta(hours=-4)))
        self.assertEqual(TIMEZONE_MAP["PST"], timezone(timedelta(hours=-8)))
        self.assertEqual(TIMEZONE_MAP["UTC"], timezone.utc)

    def test_alert_priority_has_all_phenomena(self):
        """Test that ALERT_PRIORITY includes all TARGET_PHENOMENA."""
        # Most target phenomena should have priorities
        common_phenomena = {"TO", "SV", "FF", "TOA", "SVA", "SPS", "WSW", "WSA"}
        for phenom in common_phenomena:
            self.assertIn(phenom, ALERT_PRIORITY)

        # Test that priorities are integers
        for phenom, priority in ALERT_PRIORITY.items():
            self.assertIsInstance(priority, int)
            self.assertGreater(priority, 0)

    def test_alert_priority_order(self):
        """Test that alert priorities are in expected order."""
        # Tornado Warning should be highest priority (lowest number)
        self.assertEqual(ALERT_PRIORITY["TO"], 1)

        # Flash Flood Warning should be second
        self.assertEqual(ALERT_PRIORITY["FF"], 2)

        # Watches should be lower priority than warnings
        self.assertLess(ALERT_PRIORITY["TO"], ALERT_PRIORITY["TOA"])
        self.assertLess(ALERT_PRIORITY["SV"], ALERT_PRIORITY["SVA"])

    def test_target_afd_offices_is_set(self):
        """Test that TARGET_AFD_OFFICES is a set with expected offices."""
        self.assertIsInstance(TARGET_AFD_OFFICES, set)
        self.assertTrue(len(TARGET_AFD_OFFICES) > 0)

        # Test for some expected offices
        expected_offices = {"ILN", "CLE", "IWX", "PBZ", "RLX"}
        self.assertEqual(TARGET_AFD_OFFICES, expected_offices)


class TestConstantsConsistency(unittest.TestCase):
    """Test cross-module consistency in constants."""

    def test_phenomenon_codes_consistent(self):
        """Test that phenomenon codes in different constants are consistent."""
        # All NWS_EVENT_TO_PHENOMENON values should be in TARGET_PHENOMENA
        for event, phenom in NWS_EVENT_TO_PHENOMENON.items():
            # Some might have suffixes like "A" for advisories
            base_phenom = phenom.rstrip("A")
            self.assertTrue(
                phenom in TARGET_PHENOMENA or base_phenom in TARGET_PHENOMENA,
                f"Phenomenon {phenom} from {event} not in TARGET_PHENOMENA"
            )

    def test_high_priority_alerts_in_priority_map(self):
        """Test that all high priority alerts have priority values."""
        for phenom in HIGH_PRIORITY_ALERTS:
            self.assertIn(phenom, ALERT_PRIORITY,
                         f"High priority alert {phenom} missing from ALERT_PRIORITY")

    def test_no_duplicate_fips_codes(self):
        """Test that each FIPS code is unique."""
        fips_codes = list(STATE_FIPS_MAP.values())
        self.assertEqual(len(fips_codes), len(set(fips_codes)))


if __name__ == '__main__':
    unittest.main()
