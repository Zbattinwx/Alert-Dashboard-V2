# tests/test_alert_manager.py
# ==================================================================================
# UNIT TESTS FOR ALERT MANAGER
# ==================================================================================
# Tests the AlertManager service for managing alert state.
# ==================================================================================

import unittest
import sys
import os
import tempfile
import json
from datetime import datetime, timezone, timedelta

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from alert_manager import AlertManager
from alert import Alert


class TestAlertManagerBasics(unittest.TestCase):
    """Test basic AlertManager functionality."""

    def setUp(self):
        """Set up test fixtures before each test."""
        self.temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.json')
        self.temp_file.close()
        self.manager = AlertManager(self.temp_file.name)

    def tearDown(self):
        """Clean up after each test."""
        if os.path.exists(self.temp_file.name):
            os.unlink(self.temp_file.name)

    def create_test_alert(self, product_id="TO.CLE.0001", phenomenon="TO"):
        """Helper to create a test alert."""
        alert = Alert("Test tornado warning")
        alert.product_id = product_id
        alert.phenomenon = phenomenon
        alert.expiration_time = datetime.now(timezone.utc) + timedelta(hours=1)
        return alert

    def test_initialization(self):
        """Test AlertManager initializes correctly."""
        self.assertEqual(len(self.manager.active_alerts), 0)
        self.assertEqual(len(self.manager.recent_products), 0)
        self.assertEqual(len(self.manager.latest_afds), 0)
        self.assertEqual(len(self.manager.manual_lsrs), 0)

    def test_add_alert(self):
        """Test adding a new alert."""
        alert = self.create_test_alert()
        result = self.manager.add_alert(alert)

        self.assertTrue(result)
        self.assertEqual(len(self.manager.active_alerts), 1)
        self.assertIn(alert.product_id, self.manager.active_alerts)

    def test_add_duplicate_alert(self):
        """Test that adding duplicate alert returns False."""
        alert = self.create_test_alert()
        self.manager.add_alert(alert)
        result = self.manager.add_alert(alert)

        self.assertFalse(result)
        self.assertEqual(len(self.manager.active_alerts), 1)

    def test_get_alert(self):
        """Test retrieving an alert by product ID."""
        alert = self.create_test_alert()
        self.manager.add_alert(alert)

        retrieved = self.manager.get_alert(alert.product_id)
        self.assertIsNotNone(retrieved)
        self.assertEqual(retrieved.product_id, alert.product_id)

    def test_get_nonexistent_alert(self):
        """Test getting an alert that doesn't exist returns None."""
        result = self.manager.get_alert("NONEXISTENT")
        self.assertIsNone(result)

    def test_update_alert(self):
        """Test updating an existing alert."""
        alert = self.create_test_alert()
        self.manager.add_alert(alert)

        alert.phenomenon = "SV"
        result = self.manager.update_alert(alert)

        self.assertTrue(result)
        updated = self.manager.get_alert(alert.product_id)
        self.assertEqual(updated.phenomenon, "SV")

    def test_remove_alert(self):
        """Test removing an alert."""
        alert = self.create_test_alert()
        self.manager.add_alert(alert)

        result = self.manager.remove_alert(alert.product_id)
        self.assertTrue(result)
        self.assertEqual(len(self.manager.active_alerts), 0)

    def test_remove_nonexistent_alert(self):
        """Test removing non-existent alert returns False."""
        result = self.manager.remove_alert("NONEXISTENT")
        self.assertFalse(result)

    def test_get_alert_count(self):
        """Test getting alert count."""
        self.assertEqual(self.manager.get_alert_count(), 0)

        alert1 = self.create_test_alert("TO.CLE.0001")
        alert2 = self.create_test_alert("SV.CLE.0002", "SV")
        self.manager.add_alert(alert1)
        self.manager.add_alert(alert2)

        self.assertEqual(self.manager.get_alert_count(), 2)

    def test_clear_all_alerts(self):
        """Test clearing all alerts."""
        alert1 = self.create_test_alert("TO.CLE.0001")
        alert2 = self.create_test_alert("SV.CLE.0002", "SV")
        self.manager.add_alert(alert1)
        self.manager.add_alert(alert2)

        count = self.manager.clear_all_alerts()
        self.assertEqual(count, 2)
        self.assertEqual(len(self.manager.active_alerts), 0)


class TestAlertExpiration(unittest.TestCase):
    """Test alert expiration handling."""

    def setUp(self):
        """Set up test fixtures."""
        self.temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.json')
        self.temp_file.close()
        self.manager = AlertManager(self.temp_file.name)

    def tearDown(self):
        """Clean up."""
        if os.path.exists(self.temp_file.name):
            os.unlink(self.temp_file.name)

    def test_clear_expired_alerts(self):
        """Test that expired alerts are removed."""
        # Add expired alert
        expired_alert = Alert("Expired warning")
        expired_alert.product_id = "EXPIRED"
        expired_alert.expiration_time = datetime.now(timezone.utc) - timedelta(hours=1)
        self.manager.add_alert(expired_alert)

        # Add current alert
        current_alert = Alert("Current warning")
        current_alert.product_id = "CURRENT"
        current_alert.expiration_time = datetime.now(timezone.utc) + timedelta(hours=1)
        self.manager.add_alert(current_alert)

        removed = self.manager.clear_expired_alerts()

        self.assertEqual(removed, 1)
        self.assertEqual(len(self.manager.active_alerts), 1)
        self.assertIn("CURRENT", self.manager.active_alerts)
        self.assertNotIn("EXPIRED", self.manager.active_alerts)

    def test_clear_expired_with_no_expiration(self):
        """Test that alerts without expiration time are kept."""
        alert = Alert("No expiration")
        alert.product_id = "NO_EXP"
        alert.expiration_time = None
        self.manager.add_alert(alert)

        removed = self.manager.clear_expired_alerts()

        self.assertEqual(removed, 0)
        self.assertEqual(len(self.manager.active_alerts), 1)


class TestRecentProducts(unittest.TestCase):
    """Test recent products management."""

    def setUp(self):
        """Set up test fixtures."""
        self.manager = AlertManager()

    def test_add_recent_product(self):
        """Test adding recent products."""
        product = {"text": "Test product", "id": "test1"}
        self.manager.add_recent_product(product)

        self.assertEqual(len(self.manager.recent_products), 1)
        self.assertEqual(self.manager.recent_products[0], product)

    def test_recent_products_maxlen(self):
        """Test that recent products is limited to 20."""
        for i in range(25):
            self.manager.add_recent_product({"id": i})

        self.assertEqual(len(self.manager.recent_products), 20)
        # Most recent should be first (added with appendleft)
        self.assertEqual(self.manager.recent_products[0]["id"], 24)


class TestAFDs(unittest.TestCase):
    """Test Area Forecast Discussion management."""

    def setUp(self):
        """Set up test fixtures."""
        self.manager = AlertManager()

    def test_add_afd(self):
        """Test adding an AFD."""
        afd_text = "Test AFD content"
        self.manager.add_afd("CLE", afd_text)

        self.assertEqual(len(self.manager.latest_afds), 1)
        self.assertEqual(self.manager.get_afd("CLE"), afd_text)

    def test_get_nonexistent_afd(self):
        """Test getting AFD that doesn't exist."""
        result = self.manager.get_afd("NONEXISTENT")
        self.assertIsNone(result)


class TestManualLSRs(unittest.TestCase):
    """Test manual Local Storm Report management."""

    def setUp(self):
        """Set up test fixtures."""
        self.manager = AlertManager()

    def test_add_manual_lsr(self):
        """Test adding a manual LSR."""
        lsr = {"lat": 40.0, "lng": -83.0, "type": "TORNADO"}
        self.manager.add_manual_lsr(lsr)

        self.assertEqual(len(self.manager.manual_lsrs), 1)
        self.assertIn(lsr, self.manager.manual_lsrs)

    def test_clear_manual_lsrs(self):
        """Test clearing all manual LSRs."""
        lsr1 = {"lat": 40.0, "lng": -83.0}
        lsr2 = {"lat": 41.0, "lng": -84.0}
        self.manager.add_manual_lsr(lsr1)
        self.manager.add_manual_lsr(lsr2)

        count = self.manager.clear_manual_lsrs()

        self.assertEqual(count, 2)
        self.assertEqual(len(self.manager.manual_lsrs), 0)


class TestTestAlerts(unittest.TestCase):
    """Test test alert management."""

    def setUp(self):
        """Set up test fixtures."""
        self.manager = AlertManager()

    def test_clear_test_alerts(self):
        """Test clearing test alerts."""
        # Add regular alert
        regular = Alert("Regular")
        regular.product_id = "REGULAR"
        regular.is_test = False
        self.manager.add_alert(regular)

        # Add test alert
        test = Alert("Test")
        test.product_id = "TEST"
        test.is_test = True
        self.manager.add_alert(test)

        removed = self.manager.clear_test_alerts()

        self.assertEqual(removed, 1)
        self.assertEqual(len(self.manager.active_alerts), 1)
        self.assertIn("REGULAR", self.manager.active_alerts)
        self.assertNotIn("TEST", self.manager.active_alerts)


class TestPersistence(unittest.TestCase):
    """Test save/load functionality."""

    def setUp(self):
        """Set up test fixtures."""
        self.temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.json')
        self.temp_file.close()
        self.manager = AlertManager(self.temp_file.name)

    def tearDown(self):
        """Clean up."""
        if os.path.exists(self.temp_file.name):
            os.unlink(self.temp_file.name)

    def test_save_and_load(self):
        """Test saving and loading alert state."""
        # Add some data
        alert = Alert("Test alert")
        alert.product_id = "TEST.ALERT"
        alert.phenomenon = "TO"
        alert.expiration_time = datetime.now(timezone.utc) + timedelta(hours=1)
        self.manager.add_alert(alert)

        self.manager.add_recent_product({"id": "prod1"})
        self.manager.add_afd("CLE", "Test AFD")

        # Save
        result = self.manager.save_to_disk()
        self.assertTrue(result)

        # Create new manager and load
        new_manager = AlertManager(self.temp_file.name)
        load_result = new_manager.load_from_disk()
        self.assertTrue(load_result)

        # Verify data
        self.assertEqual(len(new_manager.active_alerts), 1)
        self.assertIn("TEST.ALERT", new_manager.active_alerts)
        self.assertEqual(len(new_manager.recent_products), 1)
        self.assertEqual(new_manager.get_afd("CLE"), "Test AFD")

    def test_load_nonexistent_file(self):
        """Test loading from non-existent file."""
        manager = AlertManager("nonexistent_file.json")
        result = manager.load_from_disk()
        self.assertFalse(result)


class TestStatistics(unittest.TestCase):
    """Test statistics functionality."""

    def setUp(self):
        """Set up test fixtures."""
        self.manager = AlertManager()

    def test_get_stats(self):
        """Test getting statistics."""
        # Add some data
        alert = Alert("Test")
        alert.product_id = "TEST"
        self.manager.add_alert(alert)
        self.manager.add_recent_product({"id": "prod1"})
        self.manager.add_afd("CLE", "AFD")
        self.manager.add_manual_lsr({"lat": 40.0})

        stats = self.manager.get_stats()

        self.assertEqual(stats["active_alerts"], 1)
        self.assertEqual(stats["recent_products"], 1)
        self.assertEqual(stats["afds"], 1)
        self.assertEqual(stats["manual_lsrs"], 1)


if __name__ == '__main__':
    unittest.main()
