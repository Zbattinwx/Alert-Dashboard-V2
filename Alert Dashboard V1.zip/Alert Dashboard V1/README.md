# ONW Alert Dashboard

A comprehensive real-time weather alert monitoring and broadcasting system that connects to the National Weather Service Weather Wire and provides professional streaming integration.

![Dashboard Preview](ONW_Logo.png)

## What is This?

The ONW Alert Dashboard is a full-featured weather alerting system designed for:
- **Weather Enthusiasts**: Monitor real-time weather warnings and watches
- **Storm Chasers**: Track severe weather with interactive maps and reports
- **Broadcasters**: Professional OBS-ready widgets for live streaming
- **Emergency Management**: Situational awareness during weather events
- **Meteorologists**: Comprehensive data feeds and forecast discussions

## Key Features

- Real-time alerts from NWS Weather Wire (NWWS-OI)
- Interactive alert map with warning polygons
- OBS Studio widgets for streaming integration
- Storm report submission and tracking
- Snow accumulation visualization
- SPC outlooks and mesoscale discussions
- ODOT traffic camera feeds
- Daily statistics and recaps
- Multiple visual themes
- Mobile-friendly responsive design

## Getting Started

Choose the guide that matches your use case:

### Option 1: Remote Access (Users)

**Access the hosted dashboard at: https://atmosphericx.ddns.net:8000/**

If you're accessing the dashboard hosted remotely, you don't need to install anything. Just open your browser and go!

**Read the complete guide**: [REMOTE_ACCESS_GUIDE.md](REMOTE_ACCESS_GUIDE.md)

**Quick Start:**
1. Navigate to `https://atmosphericx.ddns.net:8000/index.html`
2. Enter the dashboard password
3. Start monitoring weather alerts

### Option 2: Local Setup (Self-Hosting)

**Host the dashboard on your own PC**

If you want to run your own instance of the dashboard locally, you'll need Python and a few packages.

**Read the complete guide**: [LOCAL_SETUP_GUIDE.md](LOCAL_SETUP_GUIDE.md)

**Quick Start:**
1. Install Python 3.9+
2. Install dependencies: `pip install slixmpp websockets aiohttp aiofiles pytz`
3. Configure `config.json` and `frontend_config.js`
4. Run `python main_app.py` or double-click `start.bat`
5. Open `http://localhost:8080/index.html`

## Documentation

### User Guides
- **[Remote Access Guide](REMOTE_ACCESS_GUIDE.md)** - For users accessing the hosted dashboard
- **[Local Setup Guide](LOCAL_SETUP_GUIDE.md)** - For self-hosting on your PC

### Feature Documentation
- **[Adding New Alert Types](ADDING_NEW_ALERTS_GUIDE.md)** - How to track additional alert types
- **[Storm Report System](STORM_REPORT_FEATURE_SUMMARY.md)** - Storm report features and setup
- **[Snow Visualization](SNOW_FEATURE_QUICK_START.md)** - Snow accumulation mapping
- **[Daily Recap](DAILY_RECAP_IMPLEMENTATION.md)** - Statistics and historical data
- **[User Preferences](USER_PREFERENCE_SYSTEM.md)** - Theme and settings management

### Technical Documentation
- **[Architecture Overview](ARCHITECTURE.md)** - System design and architecture
- **[Testing Guide](TESTING_GUIDE.md)** - How to run tests and validate changes
- **[Dynamic Styling](DYNAMIC_STYLING_GUIDE.md)** - Alert color and style system

## Dashboard Overview

### Main Sections

#### Active Alerts
Real-time display of all active weather warnings and watches, color-coded by severity. Click any alert for full details.

#### Alert Map
Interactive map showing warning polygons, radar overlay, and weather station locations. Zoom and pan to explore.

#### Local Storm Reports
View and submit storm reports with photos. Filter by type (tornado, hail, wind, flooding).

#### Snow Accumulation Map
Visual representation of snow depths across the region with color-coded indicators.

#### ODOT Feeds
Live traffic camera feeds from Ohio Department of Transportation. Search by location and feature cameras in OBS.

#### SPC Outlooks
Storm Prediction Center convective outlooks showing risk areas for severe weather.

#### Mesoscale Discussions
Real-time mesoscale discussions about developing severe weather.

#### Area Forecast Discussions
Detailed meteorologist-written forecasts from NWS offices.

#### Daily Recap
Statistics and visualizations for the day's weather alerts.

#### Director Panel
Control OBS scenes and sources remotely (requires OBS WebSocket plugin).

## OBS Streaming Widgets

The dashboard includes professional broadcast-ready widgets:

### Available Widgets

| Widget | URL | Purpose |
|--------|-----|---------|
| Alert Ticker | `/ticker.html` | Scrolling ticker showing active alerts |
| Sponsored Ticker | `/ticker-sponsored.html` | Ticker with sponsor logo |
| Featured Alert | `/feature.html` | Large graphic for single high-priority alert |
| New Alert Chime | `/new_alert.html` | Audio/visual notification for new warnings |
| Alert Rotator | `/rotator.html` | Cycles through active alert titles |
| Lower Third | `/lower_third.html` | Professional lower third graphic |
| Camera Widget | `/camera_widget.html` | Single ODOT traffic camera |
| Camera Rotator | `/camera_rotator.html` | Multiple cameras on rotation |

**For Local Setup**: Use `http://localhost:8080/[widget].html`
**For Remote Access**: Use `https://atmosphericx.ddns.net:8000/[widget].html`

See the user guides for detailed OBS setup instructions.

## Screenshots

### Dashboard View
The main dashboard shows all active alerts with color-coded cards:
- Red: Tornado Warning
- Orange: Severe Thunderstorm Warning
- Yellow: Flash Flood Warning
- Pink: Winter Storm Warning
- Blue: Watches and Advisories

### Alert Map
Interactive map with warning polygons, radar overlay, and weather stations.

### Storm Reports
Community-submitted storm reports with photos and location data.

## Alert Types Tracked

The system tracks these alert types by default:
- Tornado Warning / Watch
- Severe Thunderstorm Warning / Watch
- Flash Flood Warning / Watch
- Winter Storm Warning / Watch / Advisory
- Lake Effect Snow Warning
- Snow Squall Warning
- Storm Surge Warning
- Special Weather Statement

**Add more alert types easily** - see [ADDING_NEW_ALERTS_GUIDE.md](ADDING_NEW_ALERTS_GUIDE.md)

## Configuration

### Backend Configuration (`config.json`)

```json
{
  "alert_source": "nwws",
  "nwws_credentials": {
    "username": "your_username",
    "password": "your_password"
  },
  "filters": {
    "states": ["OH", "IN", "MI"],
    "offices": [],
    "ugc_codes": []
  },
  "dashboard_password": "YourPassword",
  "ticker_rotation_speed_ms": 10000,
  "send_google_chat_alerts": false,
  "restart_interval_hours": 24
}
```

### Frontend Configuration (`frontend_config.js`)

```javascript
const CONFIG = {
    websocket_url: "ws://localhost:8765", // or remote server
    odot_api_key: "your_odot_api_key",
    "enable_obs_integration": false,
    "winter_mode_enabled": false
};
```

See the setup guides for detailed configuration options.

## Requirements

### For Local Hosting:
- Python 3.9 or higher
- Python packages: `slixmpp`, `websockets`, `aiohttp`, `aiofiles`, `pytz`
- NWWS-OI credentials (free from weather.gov)
- Web browser (Chrome, Firefox, Edge)

### For Remote Access:
- Web browser with internet connection
- Dashboard password (from administrator)

### Optional:
- OBS Studio (for streaming features)
- OBS WebSocket plugin (for remote OBS control)

## How It Works

### Data Flow

1. **Alert Ingestion**: Connects to NWS Weather Wire (XMPP) for real-time alerts
2. **Parsing**: Extracts alert details, locations, and threat information
3. **Enrichment**: Fetches warning polygons from NWS API
4. **Storage**: Maintains active alerts in memory and on disk
5. **Broadcasting**: Pushes updates to connected dashboards via WebSocket
6. **Display**: Dashboard and widgets update in real-time

### Architecture

```
NWS Weather Wire (XMPP) ──┐
                          ├──> Alert Parser ──> Alert Manager ──> WebSocket ──> Dashboards
NWS API (HTTP) ───────────┘                                                  └──> OBS Widgets
```

For detailed architecture information, see [ARCHITECTURE.md](ARCHITECTURE.md)

## Themes

The dashboard supports multiple visual themes:
- **Classic**: Traditional weather dashboard
- **Atmospheric**: Modern gradient design
- **Storm Chaser**: High-contrast field use
- **Meteorologist**: Professional broadcast style
- **Winter**: Ice blue winter theme

Change themes from the settings menu (gear icon) in the dashboard.

## Storm Report Submission

Anyone can submit storm reports:

1. Navigate to `/submit_report.html`
2. Allow location access or enter manually
3. Select report type (tornado, hail, wind, etc.)
4. Add description and photos
5. Complete reCAPTCHA
6. Submit

Reports appear immediately on the dashboard.

## Google Chat Integration

Optionally send alerts to Google Chat:

1. Set `"send_google_chat_alerts": true`
2. Add webhook URL to `config.json`
3. Restart server

## Advanced Features

### Zone Geometry Caching
Warning polygons are cached to reduce API calls and improve performance.

### Auto-Expiration
Alerts automatically expire when their time window ends.

### Multi-Source Support
Ingest alerts from NWWS-OI (XMPP) or NWS API (HTTP polling).

### UGC Code Parsing
Converts UGC codes to human-readable county/zone names.

### Persistence
Active alerts persist across server restarts.

### Daily Statistics
Tracks daily alert counts and generates recaps.

### IP Blocking
Admin can block IPs from submitting storm reports to prevent spam.

## Troubleshooting

### Common Issues:

**Dashboard won't load**: Check if server is running and URL is correct

**No alerts appearing**: Verify NWWS credentials and state filters in config

**OBS widgets frozen**: Check WebSocket URL in frontend_config.js and refresh

**SSL certificate warning**: Normal for self-signed certs - click "Proceed"

See the user guides for detailed troubleshooting steps.

## File Structure

```
ONWAlertDashboard/
├── README.md                       # This file
├── LOCAL_SETUP_GUIDE.md            # Local hosting guide
├── REMOTE_ACCESS_GUIDE.md          # Remote access guide
├── main_app.py                     # Main backend server
├── config.json                     # Backend configuration
├── frontend_config.js              # Frontend configuration
├── alert_types_config.json         # Alert type definitions
├── index.html                      # Main dashboard
├── dashboard.js / .css             # Dashboard logic and styles
├── ticker.html                     # OBS ticker widget
├── feature.html                    # OBS featured alert widget
├── submit_report.html              # Storm report form
├── snow_map.html                   # Snow accumulation map
├── alert_parser.py                 # Alert parsing logic
├── alert_manager.py                # State management
├── zone_geometry_service.py        # Geographic data
├── message_broker.py               # WebSocket communication
└── [Additional files...]
```

## Contributing

### Adding Features:

This dashboard is designed to be extensible:
- Add new alert types in `alert_types_config.json`
- Create new OBS widgets by copying existing widget HTML
- Extend the dashboard by adding sections to `index.html` and `dashboard.js`
- Add new data sources by creating service modules

### Testing:

Run the test suite:
```bash
python run_tests.py
```

See [TESTING_GUIDE.md](TESTING_GUIDE.md) for details.

## Credits

- **Weather Data**: National Weather Service
- **Maps**: Leaflet, OpenStreetMap
- **Icons**: Font Awesome
- **Camera Feeds**: Ohio Department of Transportation

## License

This project is for personal/educational use. Weather data provided by the National Weather Service is in the public domain.

## Support

### For Users:
- Read the [Remote Access Guide](REMOTE_ACCESS_GUIDE.md)
- Contact the dashboard administrator

### For Self-Hosters:
- Read the [Local Setup Guide](LOCAL_SETUP_GUIDE.md)
- Check technical documentation
- Review server logs for errors

## NWWS-OI Credentials

To receive real-time alerts, you need NWWS-OI credentials:

1. Visit [https://www.weather.gov/nwws/](https://www.weather.gov/nwws/)
2. Request an account
3. Wait for approval (1-2 business days)
4. Add credentials to `config.json`

## Disclaimer

This dashboard is a tool for weather monitoring and situational awareness. It is NOT a replacement for official National Weather Service products and should not be used as the sole source for life-safety decisions.

**Always follow official NWS warnings and guidance from local emergency management during severe weather events.**

For emergencies, dial 911.

---

## Quick Links

- **[Remote Access Guide](REMOTE_ACCESS_GUIDE.md)** - Using the hosted dashboard
- **[Local Setup Guide](LOCAL_SETUP_GUIDE.md)** - Self-hosting instructions
- **[Alert Configuration](ADDING_NEW_ALERTS_GUIDE.md)** - Adding new alert types
- **[Architecture](ARCHITECTURE.md)** - Technical design documentation
- **[Storm Reports](STORM_REPORT_FEATURE_SUMMARY.md)** - Report system details

---

**Happy Weather Monitoring! Stay Safe!**
