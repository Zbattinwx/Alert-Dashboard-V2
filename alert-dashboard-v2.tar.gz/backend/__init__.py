"""
Alert Dashboard V2 Backend
A weather alert monitoring and broadcasting system.
"""

__version__ = "2.0.0"
